from cryptography.fernet import Fernet
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

def generate_key(password, security_level):
    if security_level == 'standard':
        return Fernet.generate_key()
    elif security_level == 'average':
        return password.encode()[:16].ljust(16, b'\0')  # AES-128
    else:
        return password.encode()[:32].ljust(32, b'\0')  # AES-256

def encrypt_file(filepath, password, security_level):
    key = generate_key(password, security_level)  # bytes
    output_path = filepath + '.enc'

    if security_level == 'standard':
        fernet = Fernet(key)
        with open(filepath, 'rb') as f:
            data = f.read()
        encrypted_data = fernet.encrypt(data)
    else:
        cipher = AES.new(key, AES.MODE_CBC)
        with open(filepath, 'rb') as f:
            data = f.read()
        encrypted_data = cipher.iv + cipher.encrypt(pad(data, AES.block_size))

    with open(output_path, 'wb') as f:
        f.write(encrypted_data)

    return output_path, key  # Always return key bytes


def decrypt_file(filepath, password):
    output_path = filepath.replace('.enc', '.dec')
    with open(filepath, 'rb') as f:
        data = f.read()
    try:
        fernet = Fernet(generate_key(password, 'standard'))
        decrypted_data = fernet.decrypt(data)
    except:
        iv = data[:16]
        ciphertext = data[16:]
        try:
            cipher = AES.new(generate_key(password, 'average'), AES.MODE_CBC, iv)
            decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
        except:
            cipher = AES.new(generate_key(password, 'high'), AES.MODE_CBC, iv)
            decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
    with open(output_path, 'wb') as f:
        f.write(decrypted_data)
    return output_path

def encrypt_text(text, password, security_level):
    key = generate_key(password, security_level)
    if security_level == 'standard':
        fernet = Fernet(key)
        return fernet.encrypt(text.encode()).decode()
    else:
        cipher = AES.new(key, AES.MODE_CBC)
        encrypted_data = cipher.iv + cipher.encrypt(pad(text.encode(), AES.block_size))
        return encrypted_data.hex()

def decrypt_text(text, password):
    try:
        fernet = Fernet(generate_key(password, 'standard'))
        return fernet.decrypt(text.encode()).decode()
    except:
        data = bytes.fromhex(text)
        iv = data[:16]
        ciphertext = data[16:]
        try:
            cipher = AES.new(generate_key(password, 'average'), AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ciphertext), AES.block_size).decode()
        except:
            cipher = AES.new(generate_key(password, 'high'), AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ciphertext), AES.block_size).decode()

def encrypt_image(filepath, password, security_level):
    return encrypt_file(filepath, password, security_level)

def decrypt_image(filepath, password):
    return decrypt_file(filepath, password)
