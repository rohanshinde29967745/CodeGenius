# CryptoVault - Secure File Encryption System

## 📋 PROJECT ABSTRACT

### Overview

**CryptoVault** is a comprehensive, production-ready web application designed for secure file encryption, decryption, and storage. Built with a modern client-server architecture, it provides military-grade encryption capabilities with an intuitive user interface. The system features a unique "Secure Vault" for encrypted file storage with two-factor authentication (2FA), tiered storage plans, and premium subscription management.

### Problem Statement

In today's digital age, data security is paramount. Users need a reliable, easy-to-use solution to:
- Encrypt sensitive files before storage or transmission
- Securely store encrypted files with restricted access
- Manage encryption keys and passwords effectively
- Access their encrypted data across devices

### Solution

CryptoVault addresses these challenges by providing:
- Multiple encryption algorithms (Fernet, AES-128, AES-256)
- Secure vault with OTP-based two-factor authentication
- Premium subscription for unlimited storage and session time
- Complete file, text, and image encryption capabilities
- History tracking and security monitoring

---

## 🏗️ SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT (React + Vite)                        │
│  ┌─────────┐  ┌──────────┐  ┌─────────┐  ┌─────────┐  ┌──────────┐ │
│  │  Login  │  │Dashboard │  │ Encrypt │  │ Decrypt │  │  Vault   │ │
│  └────┬────┘  └────┬─────┘  └────┬────┘  └────┬────┘  └────┬─────┘ │
│       │            │             │            │            │        │
│  ┌────┴────────────┴─────────────┴────────────┴────────────┴────┐  │
│  │                    API Service (Axios)                        │  │
│  │              JWT Auth Interceptors + Token Refresh            │  │
│  └───────────────────────────┬───────────────────────────────────┘  │
└──────────────────────────────┼──────────────────────────────────────┘
                               │ HTTP/REST
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│                        SERVER (Flask REST API)                        │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────────────┐ │
│  │  Auth Module   │  │ Encryption Mod │  │   Vault Module         │ │
│  │  - Login       │  │ - File Encrypt │  │  - OTP Generation      │ │
│  │  - Register    │  │ - File Decrypt │  │  - Session Management  │ │
│  │  - JWT Tokens  │  │ - Text Encrypt │  │  - File Storage        │ │
│  │  - Bcrypt Hash │  │ - Image Encrypt│  │  - Premium Features    │ │
│  └───────┬────────┘  └───────┬────────┘  └───────────┬────────────┘ │
│          │                   │                       │              │
│  ┌───────┴───────────────────┴───────────────────────┴────────────┐ │
│  │                      Core Services                              │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │ │
│  │  │ Email Service│  │Payment Service│  │  Encryption Utils   │  │ │
│  │  │    (SMTP)    │  │  (Razorpay)  │  │ (Fernet/AES/Bcrypt) │  │ │
│  │  └──────────────┘  └──────────────┘  └──────────────────────┘  │ │
│  └────────────────────────────┬───────────────────────────────────┘ │
│                               │                                      │
│  ┌────────────────────────────┴───────────────────────────────────┐ │
│  │                    SQLite Database                              │ │
│  │  Tables: users, encryption_history, user_settings,             │ │
│  │          vault_files, vault_otp, vault_sessions,               │ │
│  │          vault_lockouts, storage_limits, payment_orders        │ │
│  └─────────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ TECHNOLOGY STACK

### Frontend Technologies

| Technology | Version | Purpose |
|------------|---------|---------|
| **React** | 18.x | UI Component Library |
| **Vite** | 5.x | Build Tool & Dev Server |
| **React Router DOM** | 6.x | Client-side Routing |
| **Axios** | 1.x | HTTP Client |
| **React Icons** | 5.x | Icon Library (Feather Icons) |
| **React Hot Toast** | 2.x | Toast Notifications |

### Backend Technologies

| Technology | Version | Purpose |
|------------|---------|---------|
| **Python** | 3.8+ | Programming Language |
| **Flask** | 3.x | Web Framework |
| **Flask-CORS** | 4.x | Cross-Origin Resource Sharing |
| **SQLite** | 3.x | Database |
| **PyJWT** | 2.x | JSON Web Token Authentication |
| **Bcrypt** | 4.x | Password Hashing |
| **Cryptography** | 41.x | Fernet Encryption |
| **PyCryptodome** | 3.x | AES Encryption |
| **Pillow** | 10.x | Image Processing |

### Security Libraries

| Library | Purpose |
|---------|---------|
| **Fernet** | Symmetric encryption (standard level) |
| **AES-CBC** | Advanced Encryption Standard (128/256-bit) |
| **PBKDF2/SHA256** | Key Derivation |
| **Bcrypt** | Password Hashing with Salt |
| **HMAC-SHA256** | Payment Signature Verification |

### External Services (Optional)

| Service | Purpose |
|---------|---------|
| **SMTP (Gmail/SendGrid)** | Email OTP Delivery |
| **Razorpay** | Payment Processing |

---

## 📦 PROJECT STRUCTURE

```
file_encryption_system/
│
├── 📁 server/                    # Backend (Flask API)
│   ├── app.py                    # Main Flask application
│   ├── config.py                 # Configuration settings
│   ├── database.py               # Database initialization & queries
│   ├── encryption_utils.py       # Core encryption/decryption logic
│   ├── vault_utils.py            # Vault OTP & session management
│   ├── vault_routes.py           # Vault API endpoints (Blueprint)
│   ├── email_service.py          # SMTP email service
│   ├── payment_service.py        # Razorpay payment integration
│   ├── requirements.txt          # Python dependencies
│   ├── database.db               # SQLite database file
│   ├── uploads/                  # Temporary file storage
│   └── secure_vault/             # Encrypted vault files
│       └── {user_id}/            # Per-user vault folders
│
├── 📁 client/                    # Frontend (React + Vite)
│   ├── index.html                # HTML entry point
│   ├── package.json              # Node.js dependencies
│   ├── vite.config.js            # Vite configuration
│   └── src/
│       ├── main.jsx              # React entry point
│       ├── App.jsx               # Main app with routing
│       ├── App.css               # Global styles
│       │
│       ├── 📁 components/        # Reusable components
│       │   ├── Layout.jsx        # Protected layout wrapper
│       │   ├── Sidebar.jsx       # Navigation sidebar
│       │   └── *.css             # Component styles
│       │
│       ├── 📁 pages/             # Page components
│       │   ├── Login.jsx         # Login/Register page
│       │   ├── Dashboard.jsx     # Home dashboard
│       │   ├── FileEncrypt.jsx   # File encryption page
│       │   ├── FileDecrypt.jsx   # File decryption page
│       │   ├── Vault.jsx         # Secure vault page
│       │   ├── History.jsx       # Encryption history
│       │   ├── Settings.jsx      # User settings
│       │   └── *.css             # Page styles
│       │
│       ├── 📁 context/           # React contexts
│       │   ├── AuthContext.jsx   # Authentication state
│       │   └── ThemeContext.jsx  # Theme management
│       │
│       └── 📁 services/          # API services
│           └── api.js            # Axios API client
│
├── 📁 venv/                      # Python virtual environment
├── requirements.txt              # Root requirements
└── README.md                     # Project documentation
```

---

## 🔐 CORE FEATURES

### 1. User Authentication

**Registration:**
- Username, email, and password input
- Password hashing with Bcrypt (12 rounds)
- Unique username/email validation
- Automatic account creation with default settings

**Login:**
- Username/password authentication
- JWT access token (15 min expiry)
- JWT refresh token (7 days expiry)
- Automatic token refresh on expiry

**Security Measures:**
- Bcrypt password hashing with random salt
- JWT tokens with HS256 algorithm
- HTTP-only considerations for production
- CORS configuration for allowed origins

---

### 2. File Encryption

**Supported Algorithms:**

| Level | Algorithm | Key Size | Use Case |
|-------|-----------|----------|----------|
| Standard | Fernet | 256-bit | General use, good balance |
| AES-128 | AES-CBC | 128-bit | Faster, moderate security |
| AES-256 | AES-CBC | 256-bit | Maximum security |

**Encryption Process:**
```
1. User uploads file + password + security level
2. Key derivation: SHA256(password) → encryption key
3. For AES: Generate random 16-byte IV
4. Encrypt file content with chosen algorithm
5. Prepend IV to encrypted data (for AES)
6. Save encrypted file with .enc extension
7. Return download link to user
```

**Decryption Process:**
```
1. User uploads encrypted file + password
2. Auto-detect encryption method (Fernet/AES-128/AES-256)
3. Extract IV (first 16 bytes for AES)
4. Derive key from password
5. Decrypt file content
6. Restore original file extension
7. Return decrypted file for download
```

---

### 3. Text Encryption

- Direct text input encryption
- Same algorithms as file encryption
- Base64 encoded output for easy sharing
- Copy-to-clipboard functionality

---

### 4. Image Encryption

- Supports common image formats (JPG, PNG, GIF, etc.)
- Pixel-level encryption
- Maintains image metadata
- Preview before/after encryption

---

### 5. Secure Vault (2FA Protected)

**Access Flow:**
```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ User clicks  │────▶│ Request OTP  │────▶│ OTP sent to  │
│ Secure Vault │     │   button     │     │ user's email │
└──────────────┘     └──────────────┘     └──────────────┘
                                                 │
                                                 ▼
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Vault Access │◀────│ Session token│◀────│ User enters  │
│   Granted    │     │   created    │     │  6-digit OTP │
└──────────────┘     └──────────────┘     └──────────────┘
```

**Session Management:**

| User Type | Session Duration | Lockout on Expiry |
|-----------|------------------|-------------------|
| Free User | 10 minutes | 24 hours lockout |
| Premium User | Unlimited (365 days) | No lockout |

**Vault Features:**
- Upload files with encryption password
- Files encrypted before storage
- Download and decrypt directly from vault
- Delete files from vault
- Storage usage tracking

---

### 6. Storage Tiers

| Feature | Free Tier | Premium Tier |
|---------|-----------|--------------|
| Max Files | 7 | Unlimited |
| Max Storage | 50 MB | Unlimited |
| Session Time | 10 minutes | Unlimited |
| Lockout | 24 hours | Never |
| Price | Free | ₹299/month |

---

### 7. Premium Subscription

**Payment Flow (Razorpay):**
```
1. User selects subscription plan
2. Frontend creates order via API
3. Backend creates Razorpay order
4. Razorpay checkout opens
5. User completes payment
6. Razorpay sends payment ID + signature
7. Backend verifies HMAC signature
8. Premium activated for user
9. Welcome email sent
```

**Demo Mode:**
- When Razorpay not configured, toggle button activates premium
- 30-day demo premium for testing

---

## 🗄️ DATABASE SCHEMA

```sql
-- Users Table
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_premium BOOLEAN DEFAULT 0,
    premium_expires_at TIMESTAMP,
    storage_used INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Encryption History
CREATE TABLE encryption_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,           -- 'encrypt' or 'decrypt'
    file_type TEXT NOT NULL,        -- 'file', 'text', 'image'
    filename TEXT,
    security_level TEXT,
    status TEXT DEFAULT 'success',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- User Settings
CREATE TABLE user_settings (
    user_id INTEGER PRIMARY KEY,
    default_security_level TEXT DEFAULT 'aes-256',
    auto_delete_after_download BOOLEAN DEFAULT 1,
    theme TEXT DEFAULT 'dark',
    notifications_enabled BOOLEAN DEFAULT 1,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Vault Files
CREATE TABLE vault_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    original_filename TEXT NOT NULL,
    encrypted_filename TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    encryption_password_hash TEXT NOT NULL,
    security_level TEXT DEFAULT 'aes-256',
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Vault OTP
CREATE TABLE vault_otp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    otp_code TEXT NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    attempts INTEGER DEFAULT 0,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Vault Sessions
CREATE TABLE vault_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    session_token TEXT UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Vault Lockouts
CREATE TABLE vault_lockouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    unlocks_at TIMESTAMP NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Storage Limits
CREATE TABLE storage_limits (
    user_type TEXT PRIMARY KEY,     -- 'normal' or 'premium'
    max_files INTEGER,              -- -1 for unlimited
    max_storage_bytes INTEGER       -- -1 for unlimited
);

-- Payment Orders
CREATE TABLE payment_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    order_id TEXT UNIQUE NOT NULL,
    payment_id TEXT,
    signature TEXT,
    amount INTEGER NOT NULL,
    status TEXT DEFAULT 'created',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Refresh Tokens
CREATE TABLE refresh_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token TEXT UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
```

---

## 🔌 API ENDPOINTS

### Authentication APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/refresh` | Refresh JWT token |
| GET | `/api/auth/me` | Get current user |

### Encryption APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/encrypt/file` | Encrypt file |
| POST | `/api/decrypt/file` | Decrypt file |
| POST | `/api/encrypt/text` | Encrypt text |
| POST | `/api/decrypt/text` | Decrypt text |
| POST | `/api/encrypt/image` | Encrypt image |
| POST | `/api/decrypt/image` | Decrypt image |
| GET | `/api/download/{filename}` | Download file |

### History APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/history` | Get encryption history |
| DELETE | `/api/history` | Clear history |

### Settings APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/settings` | Get user settings |
| PUT | `/api/settings` | Update settings |
| PUT | `/api/settings/password` | Change password |

### Vault APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/vault/request-otp` | Request OTP for vault |
| POST | `/api/vault/verify-otp` | Verify OTP, get session |
| POST | `/api/vault/lock` | Lock vault manually |
| GET | `/api/vault/status` | Get vault status |
| GET | `/api/vault/storage` | Get storage info |
| GET | `/api/vault/files` | List vault files |
| POST | `/api/vault/upload` | Upload to vault |
| POST | `/api/vault/decrypt/{id}` | Decrypt vault file |
| GET | `/api/vault/download/{file}` | Download decrypted |
| DELETE | `/api/vault/delete/{id}` | Delete vault file |

### Premium APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/vault/premium/status` | Get premium status |
| GET | `/api/vault/premium/plans` | Get subscription plans |
| POST | `/api/vault/premium/toggle` | Toggle premium (demo) |
| POST | `/api/vault/premium/create-order` | Create Razorpay order |
| POST | `/api/vault/premium/verify-payment` | Verify payment |
| POST | `/api/vault/premium/activate-demo` | Activate demo premium |
| POST | `/api/vault/premium/deactivate` | Cancel subscription |

---

## 🔒 SECURITY MEASURES

### Authentication Security
- Bcrypt password hashing with 12 rounds
- JWT tokens with short expiry (15 min access, 7 days refresh)
- Secure token refresh mechanism
- Session invalidation on logout

### Encryption Security
- Industry-standard algorithms (Fernet, AES-CBC)
- Unique salts/IVs for each encryption
- Key derivation using SHA-256
- No plain-text password storage

### Vault Security
- Two-factor authentication (OTP)
- Time-limited sessions (10 min for free, unlimited for premium)
- 24-hour lockout after session expiry (free users)
- Encrypted file storage
- Password verification for decryption

### API Security
- JWT authentication for all protected routes
- CORS configuration for allowed origins
- Input validation and sanitization
- Rate limiting considerations

### Payment Security
- HMAC-SHA256 signature verification
- Server-side payment validation
- No sensitive data in client

---

## 🚀 INSTALLATION & SETUP

### Prerequisites
- Python 3.8+
- Node.js 18+
- npm or yarn

### Backend Setup

```bash
# Navigate to project root
cd file_encryption_system

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
cd server
pip install -r requirements.txt

# Run server
python app.py
```

### Frontend Setup

```bash
# Navigate to client
cd client

# Install dependencies
npm install

# Run development server
npm run dev
```

### Environment Variables (Production)

```bash
# Security
SECRET_KEY=your-super-secret-key
JWT_SECRET_KEY=your-jwt-secret-key

# Email Service (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SENDER_EMAIL=noreply@cryptovault.com
SENDER_NAME=CryptoVault

# Payment Service (Razorpay)
RAZORPAY_KEY_ID=rzp_live_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
PREMIUM_PRICE=299
PREMIUM_DURATION_DAYS=30
```

---

## 📱 USER INTERFACE

### Pages

1. **Login/Register** - User authentication
2. **Dashboard** - Overview, quick actions, stats
3. **Encrypt File** - Upload and encrypt files
4. **Decrypt File** - Upload and decrypt files
5. **Secure Vault** - 2FA protected file storage
6. **History** - Encryption/decryption logs
7. **Settings** - User preferences, password change

### Design Features
- Dark theme with modern aesthetics
- Glassmorphism effects
- Smooth animations
- Responsive design (mobile-friendly)
- Toast notifications
- Loading states
- Error handling

---

## 📊 WORKFLOW DIAGRAMS

### File Encryption Workflow

```
User                    Frontend                    Backend
  │                         │                           │
  │─── Select File ────────▶│                           │
  │─── Enter Password ─────▶│                           │
  │─── Choose Security ────▶│                           │
  │─── Click Encrypt ──────▶│                           │
  │                         │─── POST /encrypt/file ───▶│
  │                         │                           │─── Validate Input
  │                         │                           │─── Derive Key
  │                         │                           │─── Encrypt File
  │                         │                           │─── Save History
  │                         │◀── Download URL ─────────│
  │◀── Download Prompt ─────│                           │
  │─── Download File ──────▶│                           │
```

### Vault Access Workflow

```
User                    Frontend                    Backend
  │                         │                           │
  │─── Click Vault ────────▶│                           │
  │                         │─── GET /vault/status ────▶│
  │                         │◀── Status: locked ────────│
  │─── Request OTP ────────▶│                           │
  │                         │─── POST /request-otp ────▶│
  │                         │                           │─── Generate OTP
  │                         │                           │─── Send Email/Demo
  │                         │◀── OTP sent ──────────────│
  │─── Enter OTP ──────────▶│                           │
  │                         │─── POST /verify-otp ─────▶│
  │                         │                           │─── Verify OTP
  │                         │                           │─── Create Session
  │                         │◀── Session Token ─────────│
  │◀── Vault Unlocked ──────│                           │
  │                         │─── GET /files ───────────▶│
  │◀── File List ───────────│◀── Files ────────────────│
```

---

## 🎯 FUTURE ENHANCEMENTS

1. **Password Strength Meter** - Visual feedback on encryption passwords
2. **Folder Encryption** - Encrypt entire folders
3. **File Sharing** - Share encrypted files with other users
4. **Recovery Options** - Account recovery mechanisms
5. **Audit Logs** - Detailed security audit logging
6. **Mobile App** - React Native mobile application
7. **Cloud Integration** - AWS S3/Google Cloud storage
8. **Hardware Key Support** - YubiKey/FIDO2 integration

---

## 👨‍💻 DEVELOPMENT TEAM

**Project:** CryptoVault - Secure File Encryption System
**Type:** Full-Stack Web Application
**Architecture:** Client-Server (React + Flask)
**Status:** Production-Ready

---

## 📄 LICENSE

This project is developed for educational and practical use. All encryption implementations use industry-standard libraries and algorithms.

---

**Document Version:** 1.0
**Last Updated:** December 2025
