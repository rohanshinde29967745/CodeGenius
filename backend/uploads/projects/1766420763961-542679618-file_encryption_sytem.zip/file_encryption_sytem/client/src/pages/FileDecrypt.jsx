/**
 * File Decrypt Page
 * Upload and decrypt encrypted files
 * Supports: Single file, Batch files, and Folder decryption
 */
import { useState, useRef } from 'react';
import { encryptionAPI } from '../services/api';
import {
    FiUnlock,
    FiUpload,
    FiFile,
    FiX,
    FiDownload,
    FiCheck,
    FiFolder,
    FiLayers,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './FileDecrypt.css';

const FileDecrypt = () => {
    // Mode: 'single', 'batch', 'folder'
    const [mode, setMode] = useState('single');

    // Single file state
    const [file, setFile] = useState(null);
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState(null);

    // Batch files state
    const [batchFiles, setBatchFiles] = useState([]);
    const [batchProgress, setBatchProgress] = useState({});
    const [batchResults, setBatchResults] = useState([]);
    const [isBatchProcessing, setIsBatchProcessing] = useState(false);

    // Folder state
    const [folderFiles, setFolderFiles] = useState([]);
    const [folderName, setFolderName] = useState('');
    const [folderProgress, setFolderProgress] = useState({});
    const [folderResults, setFolderResults] = useState([]);
    const [isFolderProcessing, setIsFolderProcessing] = useState(false);

    const fileInputRef = useRef(null);
    const batchInputRef = useRef(null);
    const folderInputRef = useRef(null);

    // Single file handlers
    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
            setResult(null);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const droppedFile = e.dataTransfer.files[0];
        if (droppedFile) {
            setFile(droppedFile);
            setResult(null);
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
    };

    const removeFile = () => {
        setFile(null);
        setResult(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    // Batch file handlers
    const handleBatchFileChange = (e) => {
        const files = Array.from(e.target.files).filter(f => f.name.endsWith('.enc'));
        if (files.length === 0) {
            toast.error('Please select .enc encrypted files');
            return;
        }
        setBatchFiles(prev => [...prev, ...files]);
        setBatchResults([]);
    };

    const removeBatchFile = (index) => {
        setBatchFiles(prev => prev.filter((_, i) => i !== index));
    };

    const clearBatchFiles = () => {
        setBatchFiles([]);
        setBatchResults([]);
        setBatchProgress({});
    };

    // Folder handlers
    const handleFolderChange = (e) => {
        const files = Array.from(e.target.files).filter(f => f.name.endsWith('.enc'));
        if (files.length > 0) {
            const firstPath = files[0].webkitRelativePath;
            const folderNameExtract = firstPath.split('/')[0];
            setFolderName(folderNameExtract);
            setFolderFiles(files);
            setFolderResults([]);
        } else {
            toast.error('No .enc files found in the folder');
        }
    };

    const clearFolder = () => {
        setFolderFiles([]);
        setFolderName('');
        setFolderResults([]);
        setFolderProgress({});
    };

    // Single file submit
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!file) {
            toast.error('Please select an encrypted file');
            return;
        }

        if (!password) {
            toast.error('Password is required');
            return;
        }

        setIsLoading(true);

        try {
            const data = await encryptionAPI.decryptFile(file, password);
            setResult(data);
            toast.success('File decrypted successfully! 🔓');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Decryption failed. Check your password.');
        } finally {
            setIsLoading(false);
        }
    };

    // Batch decryption submit
    const handleBatchSubmit = async (e) => {
        e.preventDefault();

        if (batchFiles.length === 0) {
            toast.error('Please select encrypted files');
            return;
        }

        if (!password) {
            toast.error('Password is required');
            return;
        }

        setIsBatchProcessing(true);
        const results = [];
        const progress = {};

        for (let i = 0; i < batchFiles.length; i++) {
            const f = batchFiles[i];
            progress[i] = { status: 'processing', percent: 0 };
            setBatchProgress({ ...progress });

            try {
                progress[i] = { status: 'processing', percent: 50 };
                setBatchProgress({ ...progress });

                const data = await encryptionAPI.decryptFile(f, password);
                results.push({ file: f.name, success: true, data });
                progress[i] = { status: 'complete', percent: 100 };
            } catch (error) {
                results.push({ file: f.name, success: false, error: error.response?.data?.error || 'Failed' });
                progress[i] = { status: 'error', percent: 100 };
            }
            setBatchProgress({ ...progress });
        }

        setBatchResults(results);
        setIsBatchProcessing(false);

        const successCount = results.filter(r => r.success).length;
        toast.success(`Decrypted ${successCount}/${batchFiles.length} files! 🔓`);
    };

    // Folder decryption submit
    const handleFolderSubmit = async (e) => {
        e.preventDefault();

        if (folderFiles.length === 0) {
            toast.error('Please select a folder with encrypted files');
            return;
        }

        if (!password) {
            toast.error('Password is required');
            return;
        }

        setIsFolderProcessing(true);
        const results = [];
        const progress = {};

        for (let i = 0; i < folderFiles.length; i++) {
            const f = folderFiles[i];
            progress[i] = { status: 'processing', percent: 0 };
            setFolderProgress({ ...progress });

            try {
                progress[i] = { status: 'processing', percent: 50 };
                setFolderProgress({ ...progress });

                const data = await encryptionAPI.decryptFile(f, password);
                results.push({
                    file: f.name,
                    path: f.webkitRelativePath,
                    success: true,
                    data
                });
                progress[i] = { status: 'complete', percent: 100 };
            } catch (error) {
                results.push({
                    file: f.name,
                    path: f.webkitRelativePath,
                    success: false,
                    error: error.response?.data?.error || 'Failed'
                });
                progress[i] = { status: 'error', percent: 100 };
            }
            setFolderProgress({ ...progress });
        }

        setFolderResults(results);
        setIsFolderProcessing(false);

        const successCount = results.filter(r => r.success).length;
        toast.success(`Decrypted ${successCount}/${folderFiles.length} files from folder! 🔓`);
    };

    const downloadFile = async (decryptedFile) => {
        try {
            const blob = await encryptionAPI.downloadFile(decryptedFile);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;

            let cleanFilename = decryptedFile;
            const uuidPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}_/i;
            if (uuidPattern.test(cleanFilename)) {
                cleanFilename = cleanFilename.replace(uuidPattern, '');
            }
            cleanFilename = cleanFilename.replace(/\.dec$/, '').replace(/\.enc$/, '');

            a.download = cleanFilename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
            toast.success(`Downloaded: ${cleanFilename}`);
        } catch (error) {
            toast.error('Download failed');
        }
    };

    const downloadAllBatchFiles = async () => {
        const successResults = batchResults.filter(r => r.success);
        for (const r of successResults) {
            await downloadFile(r.data.decrypted_file);
        }
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    return (
        <div className="file-decrypt-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="page-header">
                <div className="header-icon decrypt">
                    <FiUnlock />
                </div>
                <div>
                    <h1>Decrypt Files</h1>
                    <p>Recover your encrypted files with your password</p>
                </div>
            </div>

            {/* Mode Tabs */}
            <div className="mode-tabs">
                <button
                    className={`mode-tab ${mode === 'single' ? 'active' : ''}`}
                    onClick={() => setMode('single')}
                >
                    <FiFile /> Single File
                </button>
                <button
                    className={`mode-tab ${mode === 'batch' ? 'active' : ''}`}
                    onClick={() => setMode('batch')}
                >
                    <FiLayers /> Batch Files
                </button>
                <button
                    className={`mode-tab ${mode === 'folder' ? 'active' : ''}`}
                    onClick={() => setMode('folder')}
                >
                    <FiFolder /> Folder
                </button>
            </div>

            {/* Main Content */}
            <div className="decrypt-content">
                {/* Single File Mode */}
                {mode === 'single' && (
                    <form onSubmit={handleSubmit} className="decrypt-form">
                        {/* File Upload Zone */}
                        <div
                            className={`upload-zone ${file ? 'has-file' : ''}`}
                            onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            onClick={() => !file && fileInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                accept=".enc"
                                hidden
                            />

                            {file ? (
                                <div className="file-preview">
                                    <div className="file-icon decrypt">
                                        <FiFile />
                                    </div>
                                    <div className="file-info">
                                        <span className="file-name">{file.name}</span>
                                        <span className="file-size">{formatFileSize(file.size)}</span>
                                    </div>
                                    <button
                                        type="button"
                                        className="remove-file"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            removeFile();
                                        }}
                                    >
                                        <FiX />
                                    </button>
                                </div>
                            ) : (
                                <div className="upload-content">
                                    <div className="upload-icon decrypt">
                                        <FiUpload />
                                    </div>
                                    <p>Drop your encrypted file here</p>
                                    <span>or click to browse</span>
                                    <small>Select a .enc file to decrypt</small>
                                </div>
                            )}
                        </div>

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Decryption Password</label>
                            <div className="password-input">
                                <FiUnlock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter the password used during encryption"
                                />
                            </div>
                            <small>Use the same password that was used to encrypt the file</small>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="decrypt-btn"
                            disabled={isLoading || !file || !password}
                        >
                            {isLoading ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Decrypting...
                                </>
                            ) : (
                                <>
                                    <FiUnlock /> Decrypt File
                                </>
                            )}
                        </button>
                    </form>
                )}

                {/* Batch Files Mode */}
                {mode === 'batch' && (
                    <form onSubmit={handleBatchSubmit} className="decrypt-form">
                        {/* Batch Upload Zone */}
                        <div
                            className="upload-zone batch-zone"
                            onClick={() => batchInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={batchInputRef}
                                onChange={handleBatchFileChange}
                                accept=".enc"
                                multiple
                                hidden
                            />
                            <div className="upload-content">
                                <div className="upload-icon decrypt">
                                    <FiLayers />
                                </div>
                                <p>Select multiple encrypted files</p>
                                <span>Click to browse .enc files</span>
                                <small>All files will be decrypted with the same password</small>
                            </div>
                        </div>

                        {/* Batch Files List */}
                        {batchFiles.length > 0 && (
                            <div className="batch-files-list">
                                <div className="batch-header">
                                    <span>{batchFiles.length} files selected</span>
                                    <button type="button" className="clear-btn" onClick={clearBatchFiles}>
                                        Clear All
                                    </button>
                                </div>
                                <div className="files-scroll">
                                    {batchFiles.map((f, index) => (
                                        <div key={index} className="batch-file-item">
                                            <FiFile className="batch-file-icon" />
                                            <div className="batch-file-info">
                                                <span className="batch-file-name">{f.name}</span>
                                                <span className="batch-file-size">{formatFileSize(f.size)}</span>
                                            </div>
                                            {batchProgress[index] && (
                                                <div className="file-progress">
                                                    <div
                                                        className={`progress-bar ${batchProgress[index].status}`}
                                                        style={{ width: `${batchProgress[index].percent}%` }}
                                                    ></div>
                                                </div>
                                            )}
                                            {!isBatchProcessing && (
                                                <button
                                                    type="button"
                                                    className="remove-batch-file"
                                                    onClick={() => removeBatchFile(index)}
                                                >
                                                    <FiX />
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Decryption Password (same for all files)</label>
                            <div className="password-input">
                                <FiUnlock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter the password used during encryption"
                                />
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="decrypt-btn"
                            disabled={isBatchProcessing || batchFiles.length === 0 || !password}
                        >
                            {isBatchProcessing ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Decrypting Files...
                                </>
                            ) : (
                                <>
                                    <FiUnlock /> Decrypt All Files
                                </>
                            )}
                        </button>

                        {/* Batch Results */}
                        {batchResults.length > 0 && (
                            <div className="batch-results">
                                <div className="result-header">
                                    <FiCheck className="success-check" />
                                    <h3>Batch Decryption Complete!</h3>
                                </div>
                                <div className="result-summary">
                                    <span className="success-count">
                                        {batchResults.filter(r => r.success).length} succeeded
                                    </span>
                                    {batchResults.some(r => !r.success) && (
                                        <span className="error-count">
                                            {batchResults.filter(r => !r.success).length} failed
                                        </span>
                                    )}
                                </div>
                                <button
                                    type="button"
                                    className="download-all-btn"
                                    onClick={downloadAllBatchFiles}
                                >
                                    <FiDownload /> Download All Decrypted Files
                                </button>
                            </div>
                        )}
                    </form>
                )}

                {/* Folder Mode */}
                {mode === 'folder' && (
                    <form onSubmit={handleFolderSubmit} className="decrypt-form">
                        {/* Folder Upload Zone */}
                        <div
                            className="upload-zone folder-zone"
                            onClick={() => folderInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={folderInputRef}
                                onChange={handleFolderChange}
                                webkitdirectory=""
                                directory=""
                                hidden
                            />
                            <div className="upload-content">
                                <div className="upload-icon folder-icon">
                                    <FiFolder />
                                </div>
                                <p>Select a folder with encrypted files</p>
                                <span>Only .enc files will be decrypted</span>
                                <small>Original folder structure will be maintained</small>
                            </div>
                        </div>

                        {/* Folder Files List */}
                        {folderFiles.length > 0 && (
                            <div className="folder-files-list">
                                <div className="folder-header">
                                    <div className="folder-info">
                                        <FiFolder className="folder-main-icon" />
                                        <span className="folder-path">{folderName}</span>
                                    </div>
                                    <span>{folderFiles.length} encrypted files</span>
                                    <button type="button" className="clear-btn" onClick={clearFolder}>
                                        Clear
                                    </button>
                                </div>
                                <div className="files-scroll">
                                    {folderFiles.slice(0, 10).map((f, index) => (
                                        <div key={index} className="folder-file-item">
                                            <FiFile className="folder-file-icon" />
                                            <div className="folder-file-info">
                                                <span className="folder-file-path">{f.webkitRelativePath}</span>
                                                <span className="folder-file-size">{formatFileSize(f.size)}</span>
                                            </div>
                                            {folderProgress[index] && (
                                                <div className="file-progress">
                                                    <div
                                                        className={`progress-bar ${folderProgress[index].status}`}
                                                        style={{ width: `${folderProgress[index].percent}%` }}
                                                    ></div>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                    {folderFiles.length > 10 && (
                                        <div className="more-files">
                                            ... and {folderFiles.length - 10} more files
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Decryption Password (same for all files)</label>
                            <div className="password-input">
                                <FiUnlock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter the password used during encryption"
                                />
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="decrypt-btn"
                            disabled={isFolderProcessing || folderFiles.length === 0 || !password}
                        >
                            {isFolderProcessing ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Decrypting Folder...
                                </>
                            ) : (
                                <>
                                    <FiFolder /> Decrypt Folder
                                </>
                            )}
                        </button>

                        {/* Folder Results */}
                        {folderResults.length > 0 && (
                            <div className="batch-results">
                                <div className="result-header">
                                    <FiCheck className="success-check" />
                                    <h3>Folder Decryption Complete!</h3>
                                </div>
                                <div className="result-summary">
                                    <span className="success-count">
                                        {folderResults.filter(r => r.success).length} files decrypted
                                    </span>
                                    {folderResults.some(r => !r.success) && (
                                        <span className="error-count">
                                            {folderResults.filter(r => !r.success).length} failed
                                        </span>
                                    )}
                                </div>
                            </div>
                        )}
                    </form>
                )}

                {/* Single File Result Section */}
                {mode === 'single' && result && (
                    <div className="result-section success">
                        <div className="result-header">
                            <div className="success-icon">
                                <FiCheck />
                            </div>
                            <h3>Decryption Complete!</h3>
                        </div>

                        <div className="result-details">
                            <div className="detail-row">
                                <span className="detail-label">Decrypted File:</span>
                                <span className="detail-value">{result.decrypted_file}</span>
                            </div>
                        </div>

                        <div className="result-actions">
                            <button className="download-btn" onClick={() => downloadFile(result.decrypted_file)}>
                                <FiDownload /> Download Decrypted File
                            </button>
                        </div>
                    </div>
                )}

                {/* Info Section */}
                <div className="info-box">
                    <h3>🔐 Decryption Tips</h3>
                    <ul>
                        <li>Make sure you're using the correct password</li>
                        <li>The file must be encrypted with .enc extension</li>
                        <li>If decryption fails, verify the file isn't corrupted</li>
                        <li>Decrypted files will have their original format restored</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default FileDecrypt;
