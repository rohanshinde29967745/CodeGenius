/**
 * Login/Register Page
 * Beautiful animated login form with toggle between login and register
 */
import { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FiUser, FiMail, FiLock, FiShield, FiArrowRight } from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './Login.css';

const Login = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
    });

    const { login, register, isAuthenticated } = useAuth();
    const navigate = useNavigate();

    if (isAuthenticated) {
        return <Navigate to="/dashboard" replace />;
    }

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            if (isLogin) {
                const result = await login(formData.username, formData.password);
                if (result.success) {
                    toast.success('Welcome back! 🎉');
                    navigate('/dashboard');
                } else {
                    toast.error(result.error);
                }
            } else {
                const result = await register(
                    formData.username,
                    formData.email,
                    formData.password
                );
                if (result.success) {
                    toast.success('Account created successfully! 🚀');
                    navigate('/dashboard');
                } else {
                    toast.error(result.error);
                }
            }
        } catch (error) {
            toast.error('Something went wrong');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="login-page">
            <Toaster position="top-right" />

            {/* Background Effects */}
            <div className="login-bg">
                <div className="gradient-orb orb-1"></div>
                <div className="gradient-orb orb-2"></div>
                <div className="gradient-orb orb-3"></div>
            </div>

            <div className={`login-container ${!isLogin ? 'register-mode' : ''}`}>
                {/* Form Section */}
                <div className="form-section">
                    <div className="form-header">
                        <div className="logo">
                            <FiShield />
                        </div>
                        <h1>{isLogin ? 'Welcome Back' : 'Create Account'}</h1>
                        <p>
                            {isLogin
                                ? 'Enter your credentials to access your account'
                                : 'Fill in your details to get started'}
                        </p>
                    </div>

                    <form onSubmit={handleSubmit} className="auth-form">
                        <div className="input-group">
                            <FiUser className="input-icon" />
                            <input
                                type="text"
                                name="username"
                                placeholder="Username"
                                value={formData.username}
                                onChange={handleChange}
                                required
                                minLength={3}
                            />
                        </div>

                        {!isLogin && (
                            <div className="input-group">
                                <FiMail className="input-icon" />
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="Email Address"
                                    value={formData.email}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        )}

                        <div className="input-group">
                            <FiLock className="input-icon" />
                            <input
                                type="password"
                                name="password"
                                placeholder="Password"
                                value={formData.password}
                                onChange={handleChange}
                                required
                                minLength={6}
                            />
                        </div>

                        {isLogin && (
                            <div className="forgot-password">
                                <a href="#">Forgot Password?</a>
                            </div>
                        )}

                        <button
                            type="submit"
                            className="submit-btn"
                            disabled={isLoading}
                        >
                            {isLoading ? (
                                <span className="btn-loader"></span>
                            ) : (
                                <>
                                    {isLogin ? 'Sign In' : 'Create Account'}
                                    <FiArrowRight />
                                </>
                            )}
                        </button>
                    </form>

                    <div className="form-footer">
                        <p>
                            {isLogin ? "Don't have an account?" : 'Already have an account?'}
                        </p>
                        <button
                            type="button"
                            className="toggle-btn"
                            onClick={() => setIsLogin(!isLogin)}
                        >
                            {isLogin ? 'Register' : 'Login'}
                        </button>
                    </div>
                </div>

                {/* Info Section */}
                <div className="info-section">
                    <div className="info-content">
                        <h2>Secure File Encryption</h2>
                        <p>
                            Protect your sensitive files with military-grade AES encryption.
                            Fast, secure, and easy to use.
                        </p>

                        <div className="features-list">
                            <div className="feature-item">
                                <span className="feature-icon">🔐</span>
                                <span>AES-256 Encryption</span>
                            </div>
                            <div className="feature-item">
                                <span className="feature-icon">⚡</span>
                                <span>Lightning Fast</span>
                            </div>
                            <div className="feature-item">
                                <span className="feature-icon">🛡️</span>
                                <span>Zero Knowledge</span>
                            </div>
                            <div className="feature-item">
                                <span className="feature-icon">📱</span>
                                <span>Cross Platform</span>
                            </div>
                        </div>
                    </div>

                    <div className="info-graphic">
                        <div className="shield-icon">
                            <FiShield />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
