/**
 * Secure Vault Page
 * Two-factor authentication protected file storage
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { vaultAPI } from '../services/api';
import {
    FiLock,
    FiUnlock,
    FiShield,
    FiUpload,
    FiFile,
    FiTrash2,
    FiDownload,
    FiClock,
    FiAlertCircle,
    FiStar,
    FiX,
    FiCheck,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './Vault.css';

const Vault = () => {
    // Vault status states
    const [vaultStatus, setVaultStatus] = useState('loading'); // loading, locked, unlocked, locked_out
    const [lockoutInfo, setLockoutInfo] = useState(null);
    const [sessionRemaining, setSessionRemaining] = useState(null);

    // OTP states
    const [otpSent, setOtpSent] = useState(false);
    const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);
    const [demoOtp, setDemoOtp] = useState('');
    const [otpLoading, setOtpLoading] = useState(false);

    // Storage states
    const [storageInfo, setStorageInfo] = useState(null);
    const [files, setFiles] = useState([]);
    const [filesLoading, setFilesLoading] = useState(false);

    // Upload modal states
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [uploadFile, setUploadFile] = useState(null);
    const [uploadPassword, setUploadPassword] = useState('');
    const [uploadSecurityLevel, setUploadSecurityLevel] = useState('aes-256');
    const [uploading, setUploading] = useState(false);

    // Decrypt modal states
    const [showDecryptModal, setShowDecryptModal] = useState(false);
    const [decryptingFile, setDecryptingFile] = useState(null);
    const [decryptPassword, setDecryptPassword] = useState('');
    const [decrypting, setDecrypting] = useState(false);

    // Premium
    const [isPremium, setIsPremium] = useState(false);
    const [togglingPremium, setTogglingPremium] = useState(false);

    // Refs
    const otpInputRefs = useRef([]);
    const timerRef = useRef(null);

    // Check vault status on mount
    useEffect(() => {
        checkVaultStatus();
        fetchStorageInfo();
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, []);

    // Start session timer when unlocked (only for non-premium users)
    useEffect(() => {
        // Only start timer if sessionRemaining is a positive number (not -1 for unlimited)
        if (vaultStatus === 'unlocked' && sessionRemaining > 0) {
            timerRef.current = setInterval(() => {
                setSessionRemaining(prev => {
                    if (prev <= 1) {
                        clearInterval(timerRef.current);
                        // Only lockout non-premium users
                        if (!isPremium) {
                            setVaultStatus('locked_out');
                            toast.error('Session expired! Vault locked for 24 hours.');
                        } else {
                            setVaultStatus('locked');
                            toast.info('Session expired. Please unlock vault again.');
                        }
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        }
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, [vaultStatus, isPremium]);

    const checkVaultStatus = async () => {
        try {
            const status = await vaultAPI.getStatus();

            if (status.status === 'locked_out') {
                setVaultStatus('locked_out');
                setLockoutInfo({
                    remaining: status.remaining_time,
                    unlocks_at: status.unlocks_at
                });
            } else if (status.status === 'unlocked') {
                setVaultStatus('unlocked');
                setSessionRemaining(status.remaining_seconds);
                fetchFiles();
            } else {
                setVaultStatus('locked');
            }
        } catch (error) {
            setVaultStatus('locked');
        }
    };

    const fetchStorageInfo = async () => {
        try {
            const info = await vaultAPI.getStorageInfo();
            setStorageInfo(info);
            setIsPremium(info.is_premium);
        } catch (error) {
            console.error('Failed to fetch storage info');
        }
    };

    const fetchFiles = async () => {
        setFilesLoading(true);
        try {
            const result = await vaultAPI.listFiles();
            setFiles(result.files || []);
        } catch (error) {
            if (error.response?.data?.vault_locked) {
                setVaultStatus('locked');
            }
        } finally {
            setFilesLoading(false);
        }
    };

    // OTP Handlers
    const handleRequestOTP = async () => {
        setOtpLoading(true);
        try {
            const result = await vaultAPI.requestOTP();
            setOtpSent(true);
            // Only show demo OTP if email is not configured
            if (result.demo_otp) {
                setDemoOtp(result.demo_otp);
                toast.success('Demo OTP generated (email not configured)');
            } else if (result.email_sent) {
                toast.success('OTP sent to your email!');
            }
        } catch (error) {
            if (error.response?.data?.locked_out) {
                setVaultStatus('locked_out');
                setLockoutInfo({ remaining: error.response.data.remaining_time });
            } else {
                toast.error(error.response?.data?.error || 'Failed to send OTP');
            }
        } finally {
            setOtpLoading(false);
        }
    };

    const handleOtpChange = (index, value) => {
        if (!/^\d*$/.test(value)) return;

        const newOtp = [...otpCode];
        newOtp[index] = value;
        setOtpCode(newOtp);

        // Auto-focus next input
        if (value && index < 5) {
            otpInputRefs.current[index + 1]?.focus();
        }
    };

    const handleOtpKeyDown = (index, e) => {
        if (e.key === 'Backspace' && !otpCode[index] && index > 0) {
            otpInputRefs.current[index - 1]?.focus();
        }
    };

    const handleVerifyOTP = async () => {
        const code = otpCode.join('');
        if (code.length !== 6) {
            toast.error('Please enter complete OTP');
            return;
        }

        setOtpLoading(true);
        try {
            const result = await vaultAPI.verifyOTP(code);
            setVaultStatus('unlocked');

            // Check if premium user (unlimited session)
            if (result.session_type === 'unlimited' || result.is_premium) {
                setSessionRemaining(-1); // -1 indicates unlimited
                setIsPremium(true);
                toast.success('Vault unlocked! (Unlimited session) 🔓⭐');
            } else {
                setSessionRemaining(600); // 10 minutes for free users
                toast.success('Vault unlocked! (10 min session) 🔓');
            }

            fetchFiles();
            fetchStorageInfo();
        } catch (error) {
            toast.error(error.response?.data?.error || 'Invalid OTP');
        } finally {
            setOtpLoading(false);
        }
    };

    const handleLockVault = async () => {
        try {
            await vaultAPI.lockVault();
            setVaultStatus('locked');
            setOtpSent(false);
            setOtpCode(['', '', '', '', '', '']);
            setFiles([]);
            toast.success('Vault locked');
        } catch (error) {
            toast.error('Failed to lock vault');
        }
    };

    // File Upload
    const handleUpload = async (e) => {
        e.preventDefault();
        if (!uploadFile || !uploadPassword) {
            toast.error('Please select a file and enter password');
            return;
        }

        setUploading(true);
        try {
            await vaultAPI.uploadFile(uploadFile, uploadPassword, uploadSecurityLevel);
            toast.success('File encrypted and stored! 🔐');
            setShowUploadModal(false);
            setUploadFile(null);
            setUploadPassword('');
            fetchFiles();
            fetchStorageInfo();
        } catch (error) {
            toast.error(error.response?.data?.error || 'Upload failed');
        } finally {
            setUploading(false);
        }
    };

    // File Decrypt
    const handleDecrypt = async (e) => {
        e.preventDefault();
        if (!decryptPassword) {
            toast.error('Please enter password');
            return;
        }

        setDecrypting(true);
        try {
            const result = await vaultAPI.decryptFile(decryptingFile.id, decryptPassword);

            // Download the decrypted file
            const blob = await vaultAPI.downloadDecryptedFile(result.download_path);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = result.original_filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();

            toast.success('File decrypted and downloaded! 📥');
            setShowDecryptModal(false);
            setDecryptingFile(null);
            setDecryptPassword('');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Decryption failed');
        } finally {
            setDecrypting(false);
        }
    };

    // File Delete
    const handleDelete = async (fileId) => {
        if (!window.confirm('Are you sure you want to delete this file?')) return;

        try {
            await vaultAPI.deleteFile(fileId);
            toast.success('File deleted');
            fetchFiles();
            fetchStorageInfo();
        } catch (error) {
            toast.error('Delete failed');
        }
    };

    // Premium Toggle
    const handleTogglePremium = async () => {
        setTogglingPremium(true);
        try {
            const result = await vaultAPI.togglePremium();
            setIsPremium(result.is_premium);
            toast.success(result.message);
            fetchStorageInfo();
        } catch (error) {
            toast.error('Failed to toggle premium');
        } finally {
            setTogglingPremium(false);
        }
    };

    // Format time remaining
    const formatTime = (seconds) => {
        if (seconds === -1) return 'Unlimited';
        if (seconds <= 0) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    // Format file size
    const formatSize = (bytes) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    };

    return (
        <div className="vault-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="page-header">
                <div className="header-icon vault">
                    <FiShield />
                </div>
                <div className="header-content">
                    <h1>Secure Vault</h1>
                    <p>Two-factor authenticated encrypted file storage</p>
                </div>

                {/* Premium Badge */}
                <button
                    className={`premium-btn ${isPremium ? 'active' : ''}`}
                    onClick={handleTogglePremium}
                    disabled={togglingPremium}
                >
                    <FiStar />
                    {isPremium ? 'Premium' : 'Go Premium'}
                </button>
            </div>

            {/* Storage Info */}
            {storageInfo && (
                <div className="storage-bar">
                    <div className="storage-info">
                        <span>
                            Storage: {storageInfo.storage_used_mb} MB /
                            {storageInfo.max_storage_mb > 0 ? ` ${storageInfo.max_storage_mb} MB` : ' Unlimited'}
                        </span>
                        <span>
                            Files: {storageInfo.file_count} /
                            {storageInfo.max_files > 0 ? ` ${storageInfo.max_files}` : ' Unlimited'}
                        </span>
                    </div>
                    {storageInfo.max_storage > 0 && (
                        <div className="progress-bar">
                            <div
                                className="progress-fill"
                                style={{ width: `${(storageInfo.storage_used / storageInfo.max_storage) * 100}%` }}
                            />
                        </div>
                    )}
                </div>
            )}

            {/* Main Content */}
            <div className="vault-content">
                {/* Loading */}
                {vaultStatus === 'loading' && (
                    <div className="vault-loading">
                        <div className="loader"></div>
                        <p>Checking vault status...</p>
                    </div>
                )}

                {/* Locked Out */}
                {vaultStatus === 'locked_out' && (
                    <div className="vault-locked-out">
                        <div className="lockout-icon">
                            <FiAlertCircle />
                        </div>
                        <h2>Vault Temporarily Locked</h2>
                        <p>Your vault session expired. For security, the vault is locked for 24 hours.</p>
                        <div className="lockout-timer">
                            <FiClock />
                            <span>Unlocks in: {lockoutInfo?.remaining || '24h 0m'}</span>
                        </div>
                    </div>
                )}

                {/* Locked - OTP Entry */}
                {vaultStatus === 'locked' && (
                    <div className="vault-locked">
                        <div className="lock-icon">
                            <FiLock />
                        </div>
                        <h2>Vault is Locked</h2>
                        <p>Enter your OTP to unlock the secure vault</p>

                        {!otpSent ? (
                            <button
                                className="request-otp-btn"
                                onClick={handleRequestOTP}
                                disabled={otpLoading}
                            >
                                {otpLoading ? 'Sending...' : 'Request OTP'}
                            </button>
                        ) : (
                            <div className="otp-section">
                                {/* Demo OTP Display - Remove in production! */}
                                {demoOtp && (
                                    <div className="demo-otp">
                                        <strong>Demo OTP:</strong> {demoOtp}
                                    </div>
                                )}

                                <div className="otp-inputs">
                                    {otpCode.map((digit, index) => (
                                        <input
                                            key={index}
                                            ref={el => otpInputRefs.current[index] = el}
                                            type="text"
                                            maxLength={1}
                                            value={digit}
                                            onChange={(e) => handleOtpChange(index, e.target.value)}
                                            onKeyDown={(e) => handleOtpKeyDown(index, e)}
                                            className="otp-input"
                                        />
                                    ))}
                                </div>

                                <button
                                    className="verify-otp-btn"
                                    onClick={handleVerifyOTP}
                                    disabled={otpLoading || otpCode.join('').length !== 6}
                                >
                                    {otpLoading ? 'Verifying...' : 'Unlock Vault'}
                                </button>

                                <button
                                    className="resend-btn"
                                    onClick={handleRequestOTP}
                                    disabled={otpLoading}
                                >
                                    Resend OTP
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* Unlocked - File List */}
                {vaultStatus === 'unlocked' && (
                    <div className="vault-unlocked">
                        {/* Session Timer */}
                        <div className={`session-timer ${isPremium ? 'premium' : ''}`}>
                            <div className="timer-info">
                                {isPremium ? (
                                    <>
                                        <FiStar />
                                        <span>Premium Session (Unlimited)</span>
                                    </>
                                ) : (
                                    <>
                                        <FiClock />
                                        <span>Session expires in: {formatTime(sessionRemaining)}</span>
                                    </>
                                )}
                            </div>
                            <button className="lock-btn" onClick={handleLockVault}>
                                <FiLock /> Lock Vault
                            </button>
                        </div>

                        {/* Actions */}
                        <div className="vault-actions">
                            <button
                                className="upload-btn"
                                onClick={() => setShowUploadModal(true)}
                            >
                                <FiUpload /> Upload File
                            </button>
                        </div>

                        {/* Files List */}
                        {filesLoading ? (
                            <div className="files-loading">
                                <div className="loader small"></div>
                            </div>
                        ) : files.length === 0 ? (
                            <div className="no-files">
                                <FiFile />
                                <p>No files in vault</p>
                                <span>Upload your first encrypted file!</span>
                            </div>
                        ) : (
                            <div className="files-list">
                                {files.map(file => (
                                    <div key={file.id} className="file-card">
                                        <div className="file-icon">
                                            <FiFile />
                                        </div>
                                        <div className="file-info">
                                            <h4>{file.original_filename}</h4>
                                            <div className="file-meta">
                                                <span>{formatSize(file.file_size)}</span>
                                                <span className="security-tag">{file.security_level.toUpperCase()}</span>
                                            </div>
                                        </div>
                                        <div className="file-actions">
                                            <button
                                                className="decrypt-btn"
                                                onClick={() => {
                                                    setDecryptingFile(file);
                                                    setShowDecryptModal(true);
                                                }}
                                            >
                                                <FiDownload />
                                            </button>
                                            <button
                                                className="delete-btn"
                                                onClick={() => handleDelete(file.id)}
                                            >
                                                <FiTrash2 />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Upload Modal */}
            {showUploadModal && (
                <div className="modal-overlay" onClick={() => setShowUploadModal(false)}>
                    <div className="modal" onClick={e => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3><FiUpload /> Upload to Vault</h3>
                            <button className="close-btn" onClick={() => setShowUploadModal(false)}>
                                <FiX />
                            </button>
                        </div>
                        <form onSubmit={handleUpload}>
                            <div className="form-group">
                                <label>Select File</label>
                                <input
                                    type="file"
                                    onChange={(e) => setUploadFile(e.target.files[0])}
                                    required
                                />
                                {uploadFile && (
                                    <small>{uploadFile.name} ({formatSize(uploadFile.size)})</small>
                                )}
                            </div>
                            <div className="form-group">
                                <label>Encryption Password</label>
                                <input
                                    type="password"
                                    value={uploadPassword}
                                    onChange={(e) => setUploadPassword(e.target.value)}
                                    placeholder="Min 6 characters"
                                    minLength={6}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Security Level</label>
                                <select
                                    value={uploadSecurityLevel}
                                    onChange={(e) => setUploadSecurityLevel(e.target.value)}
                                >
                                    <option value="standard">Standard (Fernet)</option>
                                    <option value="aes-128">AES-128</option>
                                    <option value="aes-256">AES-256 (Recommended)</option>
                                </select>
                            </div>
                            <button type="submit" className="submit-btn" disabled={uploading}>
                                {uploading ? 'Encrypting...' : 'Encrypt & Upload'}
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* Decrypt Modal */}
            {showDecryptModal && decryptingFile && (
                <div className="modal-overlay" onClick={() => setShowDecryptModal(false)}>
                    <div className="modal" onClick={e => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3><FiUnlock /> Decrypt File</h3>
                            <button className="close-btn" onClick={() => setShowDecryptModal(false)}>
                                <FiX />
                            </button>
                        </div>
                        <form onSubmit={handleDecrypt}>
                            <div className="file-to-decrypt">
                                <FiFile />
                                <span>{decryptingFile.original_filename}</span>
                            </div>
                            <div className="form-group">
                                <label>Decryption Password</label>
                                <input
                                    type="password"
                                    value={decryptPassword}
                                    onChange={(e) => setDecryptPassword(e.target.value)}
                                    placeholder="Enter the password used during upload"
                                    required
                                />
                            </div>
                            <button type="submit" className="submit-btn decrypt" disabled={decrypting}>
                                {decrypting ? 'Decrypting...' : 'Decrypt & Download'}
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Vault;
