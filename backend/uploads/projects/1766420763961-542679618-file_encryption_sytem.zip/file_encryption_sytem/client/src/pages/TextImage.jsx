/**
 * Text & Image Encryption Page
 * Encrypt and decrypt text messages and images
 */
import { useState, useRef } from 'react';
import { encryptionAPI } from '../services/api';
import {
    FiFileText,
    FiImage,
    FiLock,
    FiUnlock,
    FiCopy,
    FiCheck,
    FiUpload,
    FiX,
    FiDownload,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './TextImage.css';

const TextImage = () => {
    const [activeTab, setActiveTab] = useState('text');

    // Text state
    const [text, setText] = useState('');
    const [textPassword, setTextPassword] = useState('');
    const [textSecurityLevel, setTextSecurityLevel] = useState('aes-256');
    const [textResult, setTextResult] = useState(null);
    const [textLoading, setTextLoading] = useState(false);
    const [textMode, setTextMode] = useState('encrypt');
    const [copied, setCopied] = useState(false);

    // Image state
    const [image, setImage] = useState(null);
    const [imagePassword, setImagePassword] = useState('');
    const [imageSecurityLevel, setImageSecurityLevel] = useState('aes-256');
    const [imageResult, setImageResult] = useState(null);
    const [imageLoading, setImageLoading] = useState(false);
    const [imageMode, setImageMode] = useState('encrypt');

    const imageInputRef = useRef(null);

    // Text Handlers
    const handleTextEncrypt = async () => {
        if (!text) {
            toast.error('Please enter text to encrypt');
            return;
        }
        if (!textPassword || textPassword.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setTextLoading(true);
        try {
            const data = await encryptionAPI.encryptText(text, textPassword, textSecurityLevel);
            setTextResult({ type: 'encrypt', ...data });
            toast.success('Text encrypted! 🔐');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Encryption failed');
        } finally {
            setTextLoading(false);
        }
    };

    const handleTextDecrypt = async () => {
        if (!text) {
            toast.error('Please enter encrypted text');
            return;
        }
        if (!textPassword) {
            toast.error('Password is required');
            return;
        }

        setTextLoading(true);
        try {
            const data = await encryptionAPI.decryptText(text, textPassword);
            setTextResult({ type: 'decrypt', ...data });
            toast.success('Text decrypted! 🔓');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Decryption failed');
        } finally {
            setTextLoading(false);
        }
    };

    const copyToClipboard = async (content) => {
        await navigator.clipboard.writeText(content);
        setCopied(true);
        toast.success('Copied to clipboard');
        setTimeout(() => setCopied(false), 2000);
    };

    // Image Handlers
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImage(file);
            setImageResult(null);
        }
    };

    const handleImageEncrypt = async () => {
        if (!image) {
            toast.error('Please select an image');
            return;
        }
        if (!imagePassword || imagePassword.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setImageLoading(true);
        try {
            const data = await encryptionAPI.encryptImage(image, imagePassword, imageSecurityLevel);
            setImageResult({ type: 'encrypt', ...data });
            toast.success('Image encrypted! 🔐');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Encryption failed');
        } finally {
            setImageLoading(false);
        }
    };

    const handleImageDecrypt = async () => {
        if (!image) {
            toast.error('Please select an encrypted image');
            return;
        }
        if (!imagePassword) {
            toast.error('Password is required');
            return;
        }

        setImageLoading(true);
        try {
            const data = await encryptionAPI.decryptImage(image, imagePassword);
            setImageResult({ type: 'decrypt', ...data });
            toast.success('Image decrypted! 🔓');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Decryption failed');
        } finally {
            setImageLoading(false);
        }
    };

    const downloadEncryptedImage = async () => {
        const filename = imageResult?.encrypted_file || imageResult?.decrypted_file;
        if (filename) {
            try {
                const blob = await encryptionAPI.downloadFile(filename);
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;

                // Clean up filename - remove UUID prefix for better user experience
                let cleanFilename = filename;
                // Check if filename has UUID pattern (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx_)
                const uuidPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}_/i;
                if (uuidPattern.test(cleanFilename)) {
                    cleanFilename = cleanFilename.replace(uuidPattern, '');
                }
                // For decrypted images, remove .enc extension if present
                if (imageResult?.decrypted_file) {
                    cleanFilename = cleanFilename.replace(/\.enc$/, '');
                }

                a.download = cleanFilename;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
                toast.success(`File downloaded to your Downloads folder: ${cleanFilename}`);
            } catch (error) {
                toast.error('Download failed');
            }
        }
    };

    return (
        <div className="text-image-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="page-header">
                <div className="header-icon text-image">
                    <FiFileText />
                </div>
                <div>
                    <h1>Text & Image Encryption</h1>
                    <p>Securely encrypt text messages and images</p>
                </div>
            </div>

            {/* Tab Navigation */}
            <div className="tab-navigation">
                <button
                    className={`tab-btn ${activeTab === 'text' ? 'active' : ''}`}
                    onClick={() => setActiveTab('text')}
                >
                    <FiFileText /> Text Encryption
                </button>
                <button
                    className={`tab-btn ${activeTab === 'image' ? 'active' : ''}`}
                    onClick={() => setActiveTab('image')}
                >
                    <FiImage /> Image Encryption
                </button>
            </div>

            {/* Text Tab */}
            {activeTab === 'text' && (
                <div className="tab-content">
                    <div className="mode-toggle">
                        <button
                            className={`mode-btn ${textMode === 'encrypt' ? 'active' : ''}`}
                            onClick={() => { setTextMode('encrypt'); setTextResult(null); }}
                        >
                            <FiLock /> Encrypt
                        </button>
                        <button
                            className={`mode-btn ${textMode === 'decrypt' ? 'active' : ''}`}
                            onClick={() => { setTextMode('decrypt'); setTextResult(null); }}
                        >
                            <FiUnlock /> Decrypt
                        </button>
                    </div>

                    <div className="form-group">
                        <label>{textMode === 'encrypt' ? 'Enter Text' : 'Enter Encrypted Text'}</label>
                        <textarea
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            placeholder={textMode === 'encrypt'
                                ? 'Enter the text you want to encrypt...'
                                : 'Paste the encrypted text here...'}
                            rows={6}
                        />
                    </div>

                    <div className="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            value={textPassword}
                            onChange={(e) => setTextPassword(e.target.value)}
                            placeholder={textMode === 'encrypt'
                                ? 'Enter encryption password (min 6 chars)'
                                : 'Enter decryption password'}
                        />
                    </div>

                    {textMode === 'encrypt' && (
                        <div className="form-group">
                            <label>Security Level</label>
                            <select
                                value={textSecurityLevel}
                                onChange={(e) => setTextSecurityLevel(e.target.value)}
                            >
                                <option value="standard">Standard (Fernet)</option>
                                <option value="aes-128">AES-128</option>
                                <option value="aes-256">AES-256 (Recommended)</option>
                            </select>
                        </div>
                    )}

                    <button
                        className={`action-btn ${textMode}`}
                        onClick={textMode === 'encrypt' ? handleTextEncrypt : handleTextDecrypt}
                        disabled={textLoading}
                    >
                        {textLoading ? (
                            <span className="btn-loader"></span>
                        ) : (
                            <>
                                {textMode === 'encrypt' ? <FiLock /> : <FiUnlock />}
                                {textMode === 'encrypt' ? 'Encrypt Text' : 'Decrypt Text'}
                            </>
                        )}
                    </button>

                    {/* Text Result */}
                    {textResult && (
                        <div className="result-box">
                            <div className="result-header">
                                {textResult.type === 'encrypt' ? (
                                    <>
                                        <FiLock /> Encrypted Text
                                    </>
                                ) : (
                                    <>
                                        <FiUnlock /> Decrypted Text
                                    </>
                                )}
                            </div>
                            <div className="result-content">
                                <code>
                                    {textResult.encrypted_text || textResult.decrypted_text}
                                </code>
                                <button
                                    className="copy-btn"
                                    onClick={() => copyToClipboard(textResult.encrypted_text || textResult.decrypted_text)}
                                >
                                    {copied ? <FiCheck /> : <FiCopy />}
                                </button>
                            </div>
                            {textResult.key && (
                                <div className="key-info">
                                    <span>Key:</span>
                                    <code>{textResult.key.substring(0, 32)}...</code>
                                    <button
                                        className="copy-btn small"
                                        onClick={() => copyToClipboard(textResult.key)}
                                    >
                                        <FiCopy />
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* Image Tab */}
            {activeTab === 'image' && (
                <div className="tab-content">
                    <div className="mode-toggle">
                        <button
                            className={`mode-btn ${imageMode === 'encrypt' ? 'active' : ''}`}
                            onClick={() => { setImageMode('encrypt'); setImageResult(null); setImage(null); }}
                        >
                            <FiLock /> Encrypt
                        </button>
                        <button
                            className={`mode-btn ${imageMode === 'decrypt' ? 'active' : ''}`}
                            onClick={() => { setImageMode('decrypt'); setImageResult(null); setImage(null); }}
                        >
                            <FiUnlock /> Decrypt
                        </button>
                    </div>

                    <div
                        className={`upload-zone ${image ? 'has-file' : ''}`}
                        onClick={() => imageInputRef.current?.click()}
                    >
                        <input
                            type="file"
                            ref={imageInputRef}
                            onChange={handleImageChange}
                            accept={imageMode === 'encrypt' ? 'image/*' : '.enc'}
                            hidden
                        />

                        {image ? (
                            <div className="file-preview">
                                <div className="file-icon">
                                    <FiImage />
                                </div>
                                <div className="file-info">
                                    <span className="file-name">{image.name}</span>
                                    <span className="file-size">
                                        {(image.size / 1024).toFixed(2)} KB
                                    </span>
                                </div>
                                <button
                                    type="button"
                                    className="remove-file"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setImage(null);
                                        setImageResult(null);
                                    }}
                                >
                                    <FiX />
                                </button>
                            </div>
                        ) : (
                            <div className="upload-content">
                                <div className="upload-icon">
                                    <FiUpload />
                                </div>
                                <p>
                                    {imageMode === 'encrypt'
                                        ? 'Drop your image here'
                                        : 'Drop encrypted image (.enc)'}
                                </p>
                                <span>or click to browse</span>
                            </div>
                        )}
                    </div>

                    <div className="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            value={imagePassword}
                            onChange={(e) => setImagePassword(e.target.value)}
                            placeholder="Enter password"
                        />
                    </div>

                    {imageMode === 'encrypt' && (
                        <div className="form-group">
                            <label>Security Level</label>
                            <select
                                value={imageSecurityLevel}
                                onChange={(e) => setImageSecurityLevel(e.target.value)}
                            >
                                <option value="standard">Standard (Fernet)</option>
                                <option value="aes-128">AES-128</option>
                                <option value="aes-256">AES-256 (Recommended)</option>
                            </select>
                        </div>
                    )}

                    <button
                        className={`action-btn ${imageMode}`}
                        onClick={imageMode === 'encrypt' ? handleImageEncrypt : handleImageDecrypt}
                        disabled={imageLoading}
                    >
                        {imageLoading ? (
                            <span className="btn-loader"></span>
                        ) : (
                            <>
                                {imageMode === 'encrypt' ? <FiLock /> : <FiUnlock />}
                                {imageMode === 'encrypt' ? 'Encrypt Image' : 'Decrypt Image'}
                            </>
                        )}
                    </button>

                    {/* Image Result */}
                    {imageResult && (
                        <div className="result-box">
                            <div className="result-header">
                                <FiCheck /> {imageResult.type === 'encrypt' ? 'Image Encrypted!' : 'Image Decrypted!'}
                            </div>
                            <button className="download-btn" onClick={downloadEncryptedImage}>
                                <FiDownload /> Download {imageResult.type === 'encrypt' ? 'Encrypted' : 'Decrypted'} Image
                            </button>
                            {imageResult.key && (
                                <div className="key-info">
                                    <span>Key:</span>
                                    <code>{imageResult.key.substring(0, 32)}...</code>
                                    <button
                                        className="copy-btn small"
                                        onClick={() => copyToClipboard(imageResult.key)}
                                    >
                                        <FiCopy />
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default TextImage;
