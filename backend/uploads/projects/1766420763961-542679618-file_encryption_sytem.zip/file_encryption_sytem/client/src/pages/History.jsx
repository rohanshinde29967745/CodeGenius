/**
 * History Page
 * Display user's encryption/decryption activity history
 */
import { useState, useEffect } from 'react';
import { historyAPI } from '../services/api';
import {
    FiClock,
    FiLock,
    FiUnlock,
    FiTrash2,
    FiRefreshCw,
    FiFileText,
    FiImage,
    FiAlertCircle,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './History.css';

const History = () => {
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [clearing, setClearing] = useState(false);

    useEffect(() => {
        fetchHistory();
    }, []);

    const fetchHistory = async () => {
        setLoading(true);
        try {
            const data = await historyAPI.getHistory();
            setHistory(data.history || []);
        } catch (error) {
            toast.error('Failed to load history');
        } finally {
            setLoading(false);
        }
    };

    const clearHistory = async () => {
        if (!window.confirm('Are you sure you want to clear all history?')) {
            return;
        }

        setClearing(true);
        try {
            await historyAPI.clearHistory();
            setHistory([]);
            toast.success('History cleared successfully');
        } catch (error) {
            toast.error('Failed to clear history');
        } finally {
            setClearing(false);
        }
    };

    const getActionIcon = (action) => {
        if (action.includes('encrypt')) {
            if (action.includes('image')) return <FiImage />;
            if (action.includes('text')) return <FiFileText />;
            return <FiLock />;
        }
        return <FiUnlock />;
    };

    const getActionLabel = (action) => {
        switch (action) {
            case 'encrypt': return 'File Encrypt';
            case 'decrypt': return 'File Decrypt';
            case 'encrypt_text': return 'Text Encrypt';
            case 'decrypt_text': return 'Text Decrypt';
            case 'encrypt_image': return 'Image Encrypt';
            case 'decrypt_image': return 'Image Decrypt';
            default: return action;
        }
    };

    const formatDate = (timestamp) => {
        if (!timestamp) return 'Unknown';
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });
    };

    return (
        <div className="history-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="page-header">
                <div className="header-icon history">
                    <FiClock />
                </div>
                <div className="header-content">
                    <h1>Encryption History</h1>
                    <p>View your recent encryption and decryption activity</p>
                </div>
                <div className="header-actions">
                    <button className="refresh-btn" onClick={fetchHistory} disabled={loading}>
                        <FiRefreshCw className={loading ? 'spinning' : ''} />
                    </button>
                    {history.length > 0 && (
                        <button className="clear-btn" onClick={clearHistory} disabled={clearing}>
                            <FiTrash2 /> Clear All
                        </button>
                    )}
                </div>
            </div>

            {/* History Content */}
            <div className="history-content">
                {loading ? (
                    <div className="loading-state">
                        <div className="loader"></div>
                        <p>Loading history...</p>
                    </div>
                ) : history.length === 0 ? (
                    <div className="empty-state">
                        <div className="empty-icon">
                            <FiAlertCircle />
                        </div>
                        <h3>No History Yet</h3>
                        <p>Your encryption and decryption activity will appear here</p>
                    </div>
                ) : (
                    <div className="history-table-container">
                        <table className="history-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                    <th>Security</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {history.map((item, index) => (
                                    <tr key={item.id || index}>
                                        <td className="cell-num">{index + 1}</td>
                                        <td className="cell-action">
                                            <div className={`action-badge ${item.action.includes('encrypt') ? 'encrypt' : 'decrypt'}`}>
                                                {getActionIcon(item.action)}
                                                <span>{getActionLabel(item.action)}</span>
                                            </div>
                                        </td>
                                        <td className="cell-details">
                                            {item.file_name || item.file_path?.split('/').pop() ||
                                                item.text_content?.substring(0, 30) + '...' ||
                                                item.image_path?.split('/').pop() || 'N/A'}
                                        </td>
                                        <td className="cell-security">
                                            <span className="security-tag">
                                                {item.security_level?.toUpperCase() || 'N/A'}
                                            </span>
                                        </td>
                                        <td className="cell-status">
                                            <span className={`status-badge ${item.status || 'success'}`}>
                                                {item.status === 'success' ? '✓ Success' : '✗ Failed'}
                                            </span>
                                        </td>
                                        <td className="cell-date">
                                            {formatDate(item.timestamp)}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};

export default History;
