/**
 * File Encrypt Page
 * Upload and encrypt files with password protection
 * Supports: Single file, Batch files, and Folder encryption
 */
import { useState, useRef } from 'react';
import { encryptionAPI } from '../services/api';
import {
    FiLock,
    FiUpload,
    FiFile,
    FiX,
    FiCopy,
    FiDownload,
    FiCheck,
    FiFolder,
    FiLayers,
    FiFileText,
    FiImage,
    FiFilm,
    FiMusic,
    FiArchive,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import './FileEncrypt.css';

const FileEncrypt = () => {
    // Mode: 'single', 'batch', 'folder'
    const [mode, setMode] = useState('single');

    // File format filter
    const [fileFormat, setFileFormat] = useState('all');

    // Single file state
    const [file, setFile] = useState(null);
    const [password, setPassword] = useState('');
    const [securityLevel, setSecurityLevel] = useState('aes-256');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState(null);
    const [copied, setCopied] = useState(false);

    // Batch files state
    const [batchFiles, setBatchFiles] = useState([]);
    const [batchProgress, setBatchProgress] = useState({});
    const [batchResults, setBatchResults] = useState([]);
    const [isBatchProcessing, setIsBatchProcessing] = useState(false);

    // Folder state
    const [folderFiles, setFolderFiles] = useState([]);
    const [folderName, setFolderName] = useState('');
    const [folderProgress, setFolderProgress] = useState({});
    const [folderResults, setFolderResults] = useState([]);
    const [isFolderProcessing, setIsFolderProcessing] = useState(false);

    const fileInputRef = useRef(null);
    const batchInputRef = useRef(null);
    const folderInputRef = useRef(null);

    // File format options
    const fileFormats = [
        { value: 'all', label: 'All Files', icon: <FiFile />, accept: '*' },
        { value: 'documents', label: 'Documents', icon: <FiFileText />, accept: '.pdf,.doc,.docx,.txt,.xls,.xlsx,.ppt,.pptx' },
        { value: 'images', label: 'Images', icon: <FiImage />, accept: '.jpg,.jpeg,.png,.gif,.bmp,.svg,.webp' },
        { value: 'videos', label: 'Videos', icon: <FiFilm />, accept: '.mp4,.avi,.mov,.mkv,.wmv,.flv' },
        { value: 'audio', label: 'Audio', icon: <FiMusic />, accept: '.mp3,.wav,.aac,.flac,.ogg,.wma' },
        { value: 'archives', label: 'Archives', icon: <FiArchive />, accept: '.zip,.rar,.7z,.tar,.gz' },
    ];

    const getAcceptedFormats = () => {
        const format = fileFormats.find(f => f.value === fileFormat);
        return format?.accept || '*';
    };

    // Single file handlers
    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            if (selectedFile.size > 50 * 1024 * 1024) {
                toast.error('File size must be less than 50MB');
                return;
            }
            setFile(selectedFile);
            setResult(null);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const droppedFile = e.dataTransfer.files[0];
        if (droppedFile) {
            if (droppedFile.size > 50 * 1024 * 1024) {
                toast.error('File size must be less than 50MB');
                return;
            }
            setFile(droppedFile);
            setResult(null);
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
    };

    const removeFile = () => {
        setFile(null);
        setResult(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    // Batch file handlers
    const handleBatchFileChange = (e) => {
        const files = Array.from(e.target.files);
        const validFiles = files.filter(f => f.size <= 50 * 1024 * 1024);
        if (validFiles.length < files.length) {
            toast.error(`${files.length - validFiles.length} files skipped (over 50MB)`);
        }
        setBatchFiles(prev => [...prev, ...validFiles]);
        setBatchResults([]);
    };

    const removeBatchFile = (index) => {
        setBatchFiles(prev => prev.filter((_, i) => i !== index));
    };

    const clearBatchFiles = () => {
        setBatchFiles([]);
        setBatchResults([]);
        setBatchProgress({});
    };

    // Folder handlers
    const handleFolderChange = (e) => {
        const files = Array.from(e.target.files);
        const validFiles = files.filter(f => f.size <= 50 * 1024 * 1024);
        if (validFiles.length > 0) {
            // Get folder name from first file path
            const firstPath = validFiles[0].webkitRelativePath;
            const folderNameExtract = firstPath.split('/')[0];
            setFolderName(folderNameExtract);
            setFolderFiles(validFiles);
            setFolderResults([]);
        }
    };

    const clearFolder = () => {
        setFolderFiles([]);
        setFolderName('');
        setFolderResults([]);
        setFolderProgress({});
    };

    // Single file submit
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!file) {
            toast.error('Please select a file');
            return;
        }

        if (!password || password.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setIsLoading(true);

        try {
            const data = await encryptionAPI.encryptFile(file, password, securityLevel);
            setResult(data);
            toast.success('File encrypted successfully! 🔐');
        } catch (error) {
            toast.error(error.response?.data?.error || 'Encryption failed');
        } finally {
            setIsLoading(false);
        }
    };

    // Batch encryption submit
    const handleBatchSubmit = async (e) => {
        e.preventDefault();

        if (batchFiles.length === 0) {
            toast.error('Please select files');
            return;
        }

        if (!password || password.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setIsBatchProcessing(true);
        const results = [];
        const progress = {};

        for (let i = 0; i < batchFiles.length; i++) {
            const f = batchFiles[i];
            progress[i] = { status: 'processing', percent: 0 };
            setBatchProgress({ ...progress });

            try {
                // Simulate progress
                progress[i] = { status: 'processing', percent: 50 };
                setBatchProgress({ ...progress });

                const data = await encryptionAPI.encryptFile(f, password, securityLevel);
                results.push({ file: f.name, success: true, data });
                progress[i] = { status: 'complete', percent: 100 };
            } catch (error) {
                results.push({ file: f.name, success: false, error: error.response?.data?.error || 'Failed' });
                progress[i] = { status: 'error', percent: 100 };
            }
            setBatchProgress({ ...progress });
        }

        setBatchResults(results);
        setIsBatchProcessing(false);

        const successCount = results.filter(r => r.success).length;
        toast.success(`Encrypted ${successCount}/${batchFiles.length} files! 🔐`);
    };

    // Folder encryption submit
    const handleFolderSubmit = async (e) => {
        e.preventDefault();

        if (folderFiles.length === 0) {
            toast.error('Please select a folder');
            return;
        }

        if (!password || password.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setIsFolderProcessing(true);
        const results = [];
        const progress = {};

        for (let i = 0; i < folderFiles.length; i++) {
            const f = folderFiles[i];
            progress[i] = { status: 'processing', percent: 0 };
            setFolderProgress({ ...progress });

            try {
                progress[i] = { status: 'processing', percent: 50 };
                setFolderProgress({ ...progress });

                const data = await encryptionAPI.encryptFile(f, password, securityLevel);
                results.push({
                    file: f.name,
                    path: f.webkitRelativePath,
                    success: true,
                    data
                });
                progress[i] = { status: 'complete', percent: 100 };
            } catch (error) {
                results.push({
                    file: f.name,
                    path: f.webkitRelativePath,
                    success: false,
                    error: error.response?.data?.error || 'Failed'
                });
                progress[i] = { status: 'error', percent: 100 };
            }
            setFolderProgress({ ...progress });
        }

        setFolderResults(results);
        setIsFolderProcessing(false);

        const successCount = results.filter(r => r.success).length;
        toast.success(`Encrypted ${successCount}/${folderFiles.length} files from folder! 🔐`);
    };

    const copyKey = async () => {
        if (result?.key) {
            await navigator.clipboard.writeText(result.key);
            setCopied(true);
            toast.success('Key copied to clipboard');
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const downloadFile = async (encryptedFile) => {
        try {
            const blob = await encryptionAPI.downloadFile(encryptedFile);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;

            let cleanFilename = encryptedFile;
            const uuidPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}_/i;
            if (uuidPattern.test(cleanFilename)) {
                cleanFilename = cleanFilename.replace(uuidPattern, '');
            }
            if (!cleanFilename.endsWith('.enc')) {
                cleanFilename += '.enc';
            }

            a.download = cleanFilename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
            toast.success(`Downloaded: ${cleanFilename}`);
        } catch (error) {
            toast.error('Download failed');
        }
    };

    const downloadAllBatchFiles = async () => {
        const successResults = batchResults.filter(r => r.success);
        for (const r of successResults) {
            await downloadFile(r.data.encrypted_file);
        }
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    return (
        <div className="file-encrypt-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="page-header">
                <div className="header-icon">
                    <FiLock />
                </div>
                <div>
                    <h1>Encrypt Files</h1>
                    <p>Secure your files with military-grade encryption</p>
                </div>
            </div>

            {/* Mode Tabs */}
            <div className="mode-tabs">
                <button
                    className={`mode-tab ${mode === 'single' ? 'active' : ''}`}
                    onClick={() => setMode('single')}
                >
                    <FiFile /> Single File
                </button>
                <button
                    className={`mode-tab ${mode === 'batch' ? 'active' : ''}`}
                    onClick={() => setMode('batch')}
                >
                    <FiLayers /> Batch Files
                </button>
                <button
                    className={`mode-tab ${mode === 'folder' ? 'active' : ''}`}
                    onClick={() => setMode('folder')}
                >
                    <FiFolder /> Folder
                </button>
            </div>

            {/* Main Content */}
            <div className="encrypt-content">
                {/* File Format Selection */}
                <div className="format-selection">
                    <label>Select File Type:</label>
                    <div className="format-options">
                        {fileFormats.map((format) => (
                            <button
                                key={format.value}
                                className={`format-btn ${fileFormat === format.value ? 'active' : ''}`}
                                onClick={() => setFileFormat(format.value)}
                                type="button"
                            >
                                {format.icon}
                                <span>{format.label}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Single File Mode */}
                {mode === 'single' && (
                    <form onSubmit={handleSubmit} className="encrypt-form">
                        {/* File Upload Zone */}
                        <div
                            className={`upload-zone ${file ? 'has-file' : ''}`}
                            onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            onClick={() => !file && fileInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                accept={getAcceptedFormats()}
                                hidden
                            />

                            {file ? (
                                <div className="file-preview">
                                    <div className="file-icon">
                                        <FiFile />
                                    </div>
                                    <div className="file-info">
                                        <span className="file-name">{file.name}</span>
                                        <span className="file-size">{formatFileSize(file.size)}</span>
                                    </div>
                                    <button
                                        type="button"
                                        className="remove-file"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            removeFile();
                                        }}
                                    >
                                        <FiX />
                                    </button>
                                </div>
                            ) : (
                                <div className="upload-content">
                                    <div className="upload-icon">
                                        <FiUpload />
                                    </div>
                                    <p>Drag & drop your file here</p>
                                    <span>or click to browse</span>
                                    <small>Maximum file size: 50MB</small>
                                </div>
                            )}
                        </div>

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Encryption Password</label>
                            <div className="password-input">
                                <FiLock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter a strong password (min 6 characters)"
                                    minLength={6}
                                />
                            </div>
                            <small>Remember this password - you'll need it to decrypt!</small>
                        </div>

                        {/* Security Level */}
                        <div className="form-group">
                            <label>Security Level</label>
                            <div className="security-levels">
                                {[
                                    { value: 'standard', label: 'Standard', desc: 'Fernet Encryption' },
                                    { value: 'aes-128', label: 'AES-128', desc: '128-bit AES' },
                                    { value: 'aes-256', label: 'AES-256', desc: '256-bit AES (Recommended)' },
                                ].map((level) => (
                                    <label
                                        key={level.value}
                                        className={`security-option ${securityLevel === level.value ? 'selected' : ''}`}
                                    >
                                        <input
                                            type="radio"
                                            name="security"
                                            value={level.value}
                                            checked={securityLevel === level.value}
                                            onChange={(e) => setSecurityLevel(e.target.value)}
                                        />
                                        <div className="option-content">
                                            <span className="option-label">{level.label}</span>
                                            <span className="option-desc">{level.desc}</span>
                                        </div>
                                    </label>
                                ))}
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="encrypt-btn"
                            disabled={isLoading || !file || !password}
                        >
                            {isLoading ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Encrypting...
                                </>
                            ) : (
                                <>
                                    <FiLock /> Encrypt File
                                </>
                            )}
                        </button>
                    </form>
                )}

                {/* Batch Files Mode */}
                {mode === 'batch' && (
                    <form onSubmit={handleBatchSubmit} className="encrypt-form">
                        {/* Batch Upload Zone */}
                        <div
                            className="upload-zone batch-zone"
                            onClick={() => batchInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={batchInputRef}
                                onChange={handleBatchFileChange}
                                accept={getAcceptedFormats()}
                                multiple
                                hidden
                            />
                            <div className="upload-content">
                                <div className="upload-icon">
                                    <FiLayers />
                                </div>
                                <p>Select multiple files</p>
                                <span>Click to browse or add more files</span>
                                <small>Maximum 50MB per file</small>
                            </div>
                        </div>

                        {/* Batch Files List */}
                        {batchFiles.length > 0 && (
                            <div className="batch-files-list">
                                <div className="batch-header">
                                    <span>{batchFiles.length} files selected</span>
                                    <button type="button" className="clear-btn" onClick={clearBatchFiles}>
                                        Clear All
                                    </button>
                                </div>
                                <div className="files-scroll">
                                    {batchFiles.map((f, index) => (
                                        <div key={index} className="batch-file-item">
                                            <FiFile className="batch-file-icon" />
                                            <div className="batch-file-info">
                                                <span className="batch-file-name">{f.name}</span>
                                                <span className="batch-file-size">{formatFileSize(f.size)}</span>
                                            </div>
                                            {batchProgress[index] && (
                                                <div className="file-progress">
                                                    <div
                                                        className={`progress-bar ${batchProgress[index].status}`}
                                                        style={{ width: `${batchProgress[index].percent}%` }}
                                                    ></div>
                                                </div>
                                            )}
                                            {!isBatchProcessing && (
                                                <button
                                                    type="button"
                                                    className="remove-batch-file"
                                                    onClick={() => removeBatchFile(index)}
                                                >
                                                    <FiX />
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Encryption Password (same for all files)</label>
                            <div className="password-input">
                                <FiLock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter a strong password (min 6 characters)"
                                    minLength={6}
                                />
                            </div>
                        </div>

                        {/* Security Level */}
                        <div className="form-group">
                            <label>Security Level</label>
                            <div className="security-levels">
                                {[
                                    { value: 'standard', label: 'Standard', desc: 'Fernet' },
                                    { value: 'aes-128', label: 'AES-128', desc: '128-bit' },
                                    { value: 'aes-256', label: 'AES-256', desc: '256-bit' },
                                ].map((level) => (
                                    <label
                                        key={level.value}
                                        className={`security-option ${securityLevel === level.value ? 'selected' : ''}`}
                                    >
                                        <input
                                            type="radio"
                                            name="security-batch"
                                            value={level.value}
                                            checked={securityLevel === level.value}
                                            onChange={(e) => setSecurityLevel(e.target.value)}
                                        />
                                        <div className="option-content">
                                            <span className="option-label">{level.label}</span>
                                            <span className="option-desc">{level.desc}</span>
                                        </div>
                                    </label>
                                ))}
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="encrypt-btn"
                            disabled={isBatchProcessing || batchFiles.length === 0 || !password}
                        >
                            {isBatchProcessing ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Encrypting Files...
                                </>
                            ) : (
                                <>
                                    <FiLock /> Encrypt All Files
                                </>
                            )}
                        </button>

                        {/* Batch Results */}
                        {batchResults.length > 0 && (
                            <div className="batch-results">
                                <div className="result-header">
                                    <FiCheck className="success-check" />
                                    <h3>Batch Encryption Complete!</h3>
                                </div>
                                <div className="result-summary">
                                    <span className="success-count">
                                        {batchResults.filter(r => r.success).length} succeeded
                                    </span>
                                    {batchResults.some(r => !r.success) && (
                                        <span className="error-count">
                                            {batchResults.filter(r => !r.success).length} failed
                                        </span>
                                    )}
                                </div>
                                <button
                                    type="button"
                                    className="download-all-btn"
                                    onClick={downloadAllBatchFiles}
                                >
                                    <FiDownload /> Download All Encrypted Files
                                </button>
                            </div>
                        )}
                    </form>
                )}

                {/* Folder Mode */}
                {mode === 'folder' && (
                    <form onSubmit={handleFolderSubmit} className="encrypt-form">
                        {/* Folder Upload Zone */}
                        <div
                            className="upload-zone folder-zone"
                            onClick={() => folderInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={folderInputRef}
                                onChange={handleFolderChange}
                                webkitdirectory=""
                                directory=""
                                hidden
                            />
                            <div className="upload-content">
                                <div className="upload-icon folder-icon">
                                    <FiFolder />
                                </div>
                                <p>Select a folder to encrypt</p>
                                <span>All files in the folder will be encrypted</span>
                                <small>Folder structure will be preserved</small>
                            </div>
                        </div>

                        {/* Folder Files List */}
                        {folderFiles.length > 0 && (
                            <div className="folder-files-list">
                                <div className="folder-header">
                                    <div className="folder-info">
                                        <FiFolder className="folder-main-icon" />
                                        <span className="folder-path">{folderName}</span>
                                    </div>
                                    <span>{folderFiles.length} files</span>
                                    <button type="button" className="clear-btn" onClick={clearFolder}>
                                        Clear
                                    </button>
                                </div>
                                <div className="files-scroll">
                                    {folderFiles.slice(0, 10).map((f, index) => (
                                        <div key={index} className="folder-file-item">
                                            <FiFile className="folder-file-icon" />
                                            <div className="folder-file-info">
                                                <span className="folder-file-path">{f.webkitRelativePath}</span>
                                                <span className="folder-file-size">{formatFileSize(f.size)}</span>
                                            </div>
                                            {folderProgress[index] && (
                                                <div className="file-progress">
                                                    <div
                                                        className={`progress-bar ${folderProgress[index].status}`}
                                                        style={{ width: `${folderProgress[index].percent}%` }}
                                                    ></div>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                    {folderFiles.length > 10 && (
                                        <div className="more-files">
                                            ... and {folderFiles.length - 10} more files
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Password Input */}
                        <div className="form-group">
                            <label>Encryption Password (same for all files)</label>
                            <div className="password-input">
                                <FiLock className="input-icon" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter a strong password (min 6 characters)"
                                    minLength={6}
                                />
                            </div>
                        </div>

                        {/* Security Level */}
                        <div className="form-group">
                            <label>Security Level</label>
                            <div className="security-levels">
                                {[
                                    { value: 'standard', label: 'Standard', desc: 'Fernet' },
                                    { value: 'aes-128', label: 'AES-128', desc: '128-bit' },
                                    { value: 'aes-256', label: 'AES-256', desc: '256-bit' },
                                ].map((level) => (
                                    <label
                                        key={level.value}
                                        className={`security-option ${securityLevel === level.value ? 'selected' : ''}`}
                                    >
                                        <input
                                            type="radio"
                                            name="security-folder"
                                            value={level.value}
                                            checked={securityLevel === level.value}
                                            onChange={(e) => setSecurityLevel(e.target.value)}
                                        />
                                        <div className="option-content">
                                            <span className="option-label">{level.label}</span>
                                            <span className="option-desc">{level.desc}</span>
                                        </div>
                                    </label>
                                ))}
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            className="encrypt-btn"
                            disabled={isFolderProcessing || folderFiles.length === 0 || !password}
                        >
                            {isFolderProcessing ? (
                                <>
                                    <span className="btn-loader"></span>
                                    Encrypting Folder...
                                </>
                            ) : (
                                <>
                                    <FiFolder /> Encrypt Folder
                                </>
                            )}
                        </button>

                        {/* Folder Results */}
                        {folderResults.length > 0 && (
                            <div className="batch-results">
                                <div className="result-header">
                                    <FiCheck className="success-check" />
                                    <h3>Folder Encryption Complete!</h3>
                                </div>
                                <div className="result-summary">
                                    <span className="success-count">
                                        {folderResults.filter(r => r.success).length} files encrypted
                                    </span>
                                    {folderResults.some(r => !r.success) && (
                                        <span className="error-count">
                                            {folderResults.filter(r => !r.success).length} failed
                                        </span>
                                    )}
                                </div>
                            </div>
                        )}
                    </form>
                )}

                {/* Single File Result Section */}
                {mode === 'single' && result && (
                    <div className="result-section">
                        <div className="result-header">
                            <div className="success-icon">
                                <FiCheck />
                            </div>
                            <h3>Encryption Complete!</h3>
                        </div>

                        <div className="result-details">
                            <div className="detail-row">
                                <span className="detail-label">Encrypted File:</span>
                                <span className="detail-value">{result.encrypted_file}</span>
                            </div>
                            <div className="detail-row">
                                <span className="detail-label">Security Level:</span>
                                <span className="detail-value tag">{result.security_level.toUpperCase()}</span>
                            </div>
                            <div className="detail-row">
                                <span className="detail-label">Encryption Key:</span>
                                <div className="key-container">
                                    <code className="key-value">{result.key?.substring(0, 32)}...</code>
                                    <button
                                        type="button"
                                        className="copy-btn"
                                        onClick={copyKey}
                                    >
                                        {copied ? <FiCheck /> : <FiCopy />}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="result-actions">
                            <button className="download-btn" onClick={() => downloadFile(result.encrypted_file)}>
                                <FiDownload /> Download Encrypted File
                            </button>
                        </div>

                        <div className="warning-box">
                            <strong>⚠️ Important:</strong> Save your encryption key in a safe place.
                            You will need both the password and this key to decrypt your file.
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default FileEncrypt;
