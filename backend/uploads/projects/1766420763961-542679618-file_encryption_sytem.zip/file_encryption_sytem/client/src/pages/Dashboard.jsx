/**
 * Dashboard (Home) Page
 * Main landing page after login with quick actions and security score
 */
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import {
    FiLock,
    FiUnlock,
    FiClock,
    FiShield,
    FiZap,
    FiCheckCircle,
} from 'react-icons/fi';
import SecurityScore from '../components/SecurityScore';
import './Dashboard.css';

const Dashboard = () => {
    const { user } = useAuth();

    const quickActions = [
        {
            title: 'Encrypt File',
            description: 'Secure your files with AES encryption',
            icon: <FiLock />,
            path: '/encrypt',
            gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        },
        {
            title: 'Decrypt File',
            description: 'Recover your encrypted files',
            icon: <FiUnlock />,
            path: '/decrypt',
            gradient: 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)',
        },
        {
            title: 'History',
            description: 'View your encryption activity',
            icon: <FiClock />,
            path: '/history',
            gradient: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
        },
    ];

    const features = [
        {
            icon: <FiZap />,
            title: 'Lightning Fast',
            description: 'Encrypt large files in seconds with optimized algorithms',
        },
        {
            icon: <FiShield />,
            title: 'Military Grade',
            description: 'AES-256 encryption used by governments worldwide',
        },
        {
            icon: <FiCheckCircle />,
            title: 'Zero Knowledge',
            description: 'Your files are encrypted locally, we never see them',
        },
    ];

    return (
        <div className="dashboard">
            {/* Hero Section */}
            <section className="dashboard-hero">
                <div className="hero-content">
                    <div className="hero-badge">
                        <FiShield /> Secure Encryption Platform
                    </div>
                    <h1>
                        Welcome back, <span className="highlight">{user?.username}</span>!
                    </h1>
                    <p>
                        Protect your sensitive files with military-grade encryption. Fast,
                        secure, and easy to use. Your data never leaves your device
                        unencrypted.
                    </p>
                    <div className="hero-actions">
                        <Link to="/encrypt" className="btn btn-primary">
                            <FiLock /> Encrypt Now
                        </Link>
                        <Link to="/decrypt" className="btn btn-secondary">
                            <FiUnlock /> Decrypt File
                        </Link>
                    </div>
                </div>
                <div className="hero-visual">
                    <div className="shield-container">
                        <div className="shield-glow"></div>
                        <FiShield className="shield-icon" />
                    </div>
                </div>
            </section>

            {/* Security Score Section */}
            <section className="security-score-section">
                <SecurityScore />
            </section>

            {/* Quick Actions */}
            <section className="quick-actions">
                <h2>Quick Actions</h2>
                <div className="actions-grid">
                    {quickActions.map((action, index) => (
                        <Link
                            key={index}
                            to={action.path}
                            className="action-card"
                            style={{ '--gradient': action.gradient }}
                        >
                            <div className="action-icon">{action.icon}</div>
                            <div className="action-content">
                                <h3>{action.title}</h3>
                                <p>{action.description}</p>
                            </div>
                            <div className="action-arrow">→</div>
                        </Link>
                    ))}
                </div>
            </section>

            {/* Features Section */}
            <section className="features-section">
                <h2>Why Choose CryptoVault?</h2>
                <div className="features-grid">
                    {features.map((feature, index) => (
                        <div key={index} className="feature-card">
                            <div className="feature-icon">{feature.icon}</div>
                            <h3>{feature.title}</h3>
                            <p>{feature.description}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Security Info */}
            <section className="security-info">
                <div className="info-card">
                    <h3>🔐 How It Works</h3>
                    <div className="steps">
                        <div className="step">
                            <span className="step-number">1</span>
                            <span>Upload your file</span>
                        </div>
                        <div className="step">
                            <span className="step-number">2</span>
                            <span>Enter a strong password</span>
                        </div>
                        <div className="step">
                            <span className="step-number">3</span>
                            <span>Choose encryption level</span>
                        </div>
                        <div className="step">
                            <span className="step-number">4</span>
                            <span>Download encrypted file</span>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Dashboard;
