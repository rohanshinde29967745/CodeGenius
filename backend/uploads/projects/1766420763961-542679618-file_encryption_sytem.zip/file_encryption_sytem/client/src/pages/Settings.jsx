/**
 * Settings Page - Meta Style
 * Clean list-based layout with expandable sections
 */
import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { settingsAPI } from '../services/api';
import {
    FiMoon,
    FiVolume2,
    FiGlobe,
    FiDownload,
    FiEye,
    FiLock,
    FiLogOut,
    FiChevronRight,
    FiChevronDown,
    FiUser,
    FiSettings,
} from 'react-icons/fi';
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import './Settings.css';

const Settings = () => {
    const { user, logout } = useAuth();
    const { setTheme } = useTheme();
    const navigate = useNavigate();

    const [expandedSection, setExpandedSection] = useState(null);

    const [settings, setSettings] = useState({
        dark_mode: true,
        sound_enabled: true,
        language: 'English',
        auto_save: true,
        show_history: true,
    });

    const [passwords, setPasswords] = useState({
        old_password: '',
        new_password: '',
        confirm_password: '',
    });

    const [passwordLoading, setPasswordLoading] = useState(false);

    useEffect(() => {
        fetchSettings();
    }, []);

    const fetchSettings = async () => {
        try {
            const data = await settingsAPI.getSettings();
            setSettings(data);
        } catch (error) {
            console.error('Failed to load settings');
        }
    };

    const toggleSection = (section) => {
        setExpandedSection(expandedSection === section ? null : section);
    };

    // Auto-save settings when they change
    const handleSettingChange = async (key, value) => {
        const newSettings = { ...settings, [key]: value };
        setSettings(newSettings);

        // Apply theme change immediately when dark_mode is toggled
        if (key === 'dark_mode') {
            setTheme(value);
        }

        // Auto-save to backend
        try {
            await settingsAPI.updateSettings(newSettings);
            toast.success('Updated!', { duration: 1500, icon: '✓' });
        } catch (error) {
            toast.error('Failed to save');
        }
    };

    const changePassword = async (e) => {
        e.preventDefault();

        if (passwords.new_password !== passwords.confirm_password) {
            toast.error('Passwords do not match');
            return;
        }

        if (passwords.new_password.length < 6) {
            toast.error('Password must be at least 6 characters');
            return;
        }

        setPasswordLoading(true);
        try {
            await settingsAPI.changePassword(passwords.old_password, passwords.new_password);
            toast.success('Password changed successfully! 🔐');
            setPasswords({ old_password: '', new_password: '', confirm_password: '' });
            setExpandedSection(null);
        } catch (error) {
            toast.error(error.response?.data?.error || 'Failed to change password');
        } finally {
            setPasswordLoading(false);
        }
    };

    const handleLogout = () => {
        logout();
        navigate('/login');
        toast.success('Logged out successfully');
    };

    const languages = ['English', 'Hindi', 'Marathi', 'French', 'Spanish', 'German'];

    return (
        <div className="settings-page">
            <Toaster position="top-right" />

            {/* Header */}
            <div className="settings-header">
                <h1>Settings</h1>
            </div>

            {/* Main Settings Menu */}
            <div className="settings-section main-section">
                {/* Password and Security */}
                <div className="menu-item-container">
                    <div
                        className={`menu-item ${expandedSection === 'password' ? 'expanded' : ''}`}
                        onClick={() => toggleSection('password')}
                    >
                        <FiLock className="menu-icon" />
                        <span className="menu-label">Password and security</span>
                        {expandedSection === 'password' ?
                            <FiChevronDown className="menu-arrow" /> :
                            <FiChevronRight className="menu-arrow" />
                        }
                    </div>
                    {expandedSection === 'password' && (
                        <div className="menu-content">
                            <form onSubmit={changePassword} className="password-form">
                                <div className="form-group">
                                    <label>Current Password</label>
                                    <input
                                        type="password"
                                        value={passwords.old_password}
                                        onChange={(e) => setPasswords(p => ({ ...p, old_password: e.target.value }))}
                                        placeholder="Enter current password"
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>New Password</label>
                                    <input
                                        type="password"
                                        value={passwords.new_password}
                                        onChange={(e) => setPasswords(p => ({ ...p, new_password: e.target.value }))}
                                        placeholder="Enter new password (min 6 chars)"
                                        minLength={6}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Confirm New Password</label>
                                    <input
                                        type="password"
                                        value={passwords.confirm_password}
                                        onChange={(e) => setPasswords(p => ({ ...p, confirm_password: e.target.value }))}
                                        placeholder="Confirm new password"
                                        required
                                    />
                                </div>
                                <button
                                    type="submit"
                                    className="submit-btn"
                                    disabled={passwordLoading}
                                >
                                    {passwordLoading ? (
                                        <span className="btn-loader"></span>
                                    ) : (
                                        'Update Password'
                                    )}
                                </button>
                            </form>
                        </div>
                    )}
                </div>

                {/* Preferences */}
                <div className="menu-item-container">
                    <div
                        className={`menu-item ${expandedSection === 'preferences' ? 'expanded' : ''}`}
                        onClick={() => toggleSection('preferences')}
                    >
                        <FiSettings className="menu-icon" />
                        <span className="menu-label">Preferences</span>
                        {expandedSection === 'preferences' ?
                            <FiChevronDown className="menu-arrow" /> :
                            <FiChevronRight className="menu-arrow" />
                        }
                    </div>
                    {expandedSection === 'preferences' && (
                        <div className="menu-content">
                            <div className="preference-item">
                                <div className="preference-info">
                                    <FiMoon className="preference-icon" />
                                    <div>
                                        <span className="preference-label">Dark Mode</span>
                                        <span className="preference-desc">Enable dark theme</span>
                                    </div>
                                </div>
                                <label className="toggle">
                                    <input
                                        type="checkbox"
                                        checked={settings.dark_mode}
                                        onChange={(e) => handleSettingChange('dark_mode', e.target.checked)}
                                    />
                                    <span className="toggle-slider"></span>
                                </label>
                            </div>

                            <div className="preference-item">
                                <div className="preference-info">
                                    <FiVolume2 className="preference-icon" />
                                    <div>
                                        <span className="preference-label">Sound Notifications</span>
                                        <span className="preference-desc">Play sounds for actions</span>
                                    </div>
                                </div>
                                <label className="toggle">
                                    <input
                                        type="checkbox"
                                        checked={settings.sound_enabled}
                                        onChange={(e) => handleSettingChange('sound_enabled', e.target.checked)}
                                    />
                                    <span className="toggle-slider"></span>
                                </label>
                            </div>

                            <div className="preference-item">
                                <div className="preference-info">
                                    <FiDownload className="preference-icon" />
                                    <div>
                                        <span className="preference-label">Auto-Save Files</span>
                                        <span className="preference-desc">Automatically save encrypted files</span>
                                    </div>
                                </div>
                                <label className="toggle">
                                    <input
                                        type="checkbox"
                                        checked={settings.auto_save}
                                        onChange={(e) => handleSettingChange('auto_save', e.target.checked)}
                                    />
                                    <span className="toggle-slider"></span>
                                </label>
                            </div>

                            <div className="preference-item">
                                <div className="preference-info">
                                    <FiEye className="preference-icon" />
                                    <div>
                                        <span className="preference-label">Show History</span>
                                        <span className="preference-desc">Display encryption history</span>
                                    </div>
                                </div>
                                <label className="toggle">
                                    <input
                                        type="checkbox"
                                        checked={settings.show_history}
                                        onChange={(e) => handleSettingChange('show_history', e.target.checked)}
                                    />
                                    <span className="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    )}
                </div>

                {/* Language & Region */}
                <div className="menu-item-container">
                    <div
                        className={`menu-item ${expandedSection === 'language' ? 'expanded' : ''}`}
                        onClick={() => toggleSection('language')}
                    >
                        <FiGlobe className="menu-icon" />
                        <span className="menu-label">Language & Region</span>
                        {expandedSection === 'language' ?
                            <FiChevronDown className="menu-arrow" /> :
                            <FiChevronRight className="menu-arrow" />
                        }
                    </div>
                    {expandedSection === 'language' && (
                        <div className="menu-content">
                            <div className="preference-item">
                                <div className="preference-info">
                                    <FiGlobe className="preference-icon" />
                                    <div>
                                        <span className="preference-label">Interface Language</span>
                                        <span className="preference-desc">Select your preferred language</span>
                                    </div>
                                </div>
                                <select
                                    value={settings.language}
                                    onChange={(e) => handleSettingChange('language', e.target.value)}
                                    className="language-select"
                                >
                                    {languages.map(lang => (
                                        <option key={lang} value={lang}>{lang}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Manage Account Section */}
            <div className="settings-section">
                <div className="menu-item" onClick={handleLogout}>
                    <FiLogOut className="menu-icon logout-icon" />
                    <span className="menu-label logout-text">Log out</span>
                    <FiChevronRight className="menu-arrow" />
                </div>
            </div>
        </div>
    );
};

export default Settings;
