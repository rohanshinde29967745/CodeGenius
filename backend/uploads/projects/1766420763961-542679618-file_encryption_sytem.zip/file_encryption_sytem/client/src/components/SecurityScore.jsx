/**
 * Security Score Component
 * Displays an animated circular progress ring with security score
 */
import { useState, useEffect } from 'react';
import { securityAPI } from '../services/api';
import {
    FiShield,
    FiTrendingUp,
    FiAlertCircle,
    FiCheckCircle,
    FiLock,
    FiUnlock,
    FiActivity,
} from 'react-icons/fi';
import './SecurityScore.css';

const SecurityScore = () => {
    const [scoreData, setScoreData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [animatedScore, setAnimatedScore] = useState(0);

    useEffect(() => {
        fetchSecurityScore();
    }, []);

    useEffect(() => {
        if (scoreData) {
            // Animate the score from 0 to actual value
            const duration = 1500;
            const steps = 60;
            const increment = scoreData.score / steps;
            let current = 0;

            const timer = setInterval(() => {
                current += increment;
                if (current >= scoreData.score) {
                    setAnimatedScore(scoreData.score);
                    clearInterval(timer);
                } else {
                    setAnimatedScore(Math.floor(current));
                }
            }, duration / steps);

            return () => clearInterval(timer);
        }
    }, [scoreData]);

    const fetchSecurityScore = async () => {
        try {
            const data = await securityAPI.getSecurityScore();
            setScoreData(data);
        } catch (error) {
            console.error('Failed to fetch security score:', error);
        } finally {
            setLoading(false);
        }
    };

    const getScoreColor = (score) => {
        if (score >= 80) return '#38ef7d';
        if (score >= 60) return '#ffc107';
        if (score >= 40) return '#ff9800';
        return '#f44336';
    };

    const getGradient = (score) => {
        if (score >= 80) return 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)';
        if (score >= 60) return 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)';
        if (score >= 40) return 'linear-gradient(135deg, #ff9800 0%, #ff5722 100%)';
        return 'linear-gradient(135deg, #f44336 0%, #e91e63 100%)';
    };

    if (loading) {
        return (
            <div className="security-score-card loading">
                <div className="score-loading">
                    <div className="loader"></div>
                    <span>Calculating your security score...</span>
                </div>
            </div>
        );
    }

    if (!scoreData) {
        return null;
    }

    const circumference = 2 * Math.PI * 54;
    const strokeDashoffset = circumference - (animatedScore / 100) * circumference;

    return (
        <div className="security-score-card">
            <div className="score-header">
                <div className="score-title">
                    <FiShield className="title-icon" />
                    <span>Security Score</span>
                </div>
                <span className="score-grade" style={{ background: getGradient(scoreData.score) }}>
                    {scoreData.grade}
                </span>
            </div>

            <div className="score-main">
                <div className="score-ring-container">
                    <svg className="score-ring" viewBox="0 0 120 120">
                        {/* Background circle */}
                        <circle
                            className="ring-bg"
                            cx="60"
                            cy="60"
                            r="54"
                            fill="none"
                            strokeWidth="8"
                        />
                        {/* Progress circle */}
                        <circle
                            className="ring-progress"
                            cx="60"
                            cy="60"
                            r="54"
                            fill="none"
                            strokeWidth="8"
                            strokeLinecap="round"
                            style={{
                                stroke: getScoreColor(scoreData.score),
                                strokeDasharray: circumference,
                                strokeDashoffset: strokeDashoffset,
                            }}
                        />
                    </svg>
                    <div className="score-value">
                        <span className="score-number">{animatedScore}</span>
                        <span className="score-max">/100</span>
                    </div>
                </div>

                <div className="score-info">
                    <h3 className="grade-text">{scoreData.gradeText}</h3>
                    <div className="stats-row">
                        <div className="stat-item">
                            <FiLock className="stat-icon encrypt" />
                            <span className="stat-value">{scoreData.stats.totalEncryptions}</span>
                            <span className="stat-label">Encrypted</span>
                        </div>
                        <div className="stat-item">
                            <FiUnlock className="stat-icon decrypt" />
                            <span className="stat-value">{scoreData.stats.totalDecryptions}</span>
                            <span className="stat-label">Decrypted</span>
                        </div>
                        <div className="stat-item">
                            <FiActivity className="stat-icon activity" />
                            <span className="stat-value">{scoreData.stats.recentActivity}</span>
                            <span className="stat-label">This Month</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Score Breakdown */}
            <div className="score-breakdown">
                <h4>Score Breakdown</h4>
                <div className="breakdown-list">
                    {scoreData.breakdown.map((item, index) => (
                        <div key={index} className="breakdown-item">
                            <div className="breakdown-header">
                                <span className="breakdown-label">{item.label}</span>
                                <span className="breakdown-score">{item.score}/{item.maxScore}</span>
                            </div>
                            <div className="breakdown-bar">
                                <div
                                    className="breakdown-fill"
                                    style={{
                                        width: `${(item.score / item.maxScore) * 100}%`,
                                        background: getGradient(item.score * 4)
                                    }}
                                ></div>
                            </div>
                            <span className="breakdown-desc">{item.description}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Tips Section */}
            {scoreData.tips.length > 0 && (
                <div className="score-tips">
                    <h4>
                        <FiTrendingUp /> How to Improve
                    </h4>
                    <div className="tips-list">
                        {scoreData.tips.map((tip, index) => (
                            <div key={index} className="tip-item">
                                <FiAlertCircle className="tip-icon" />
                                <span>{tip}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default SecurityScore;
