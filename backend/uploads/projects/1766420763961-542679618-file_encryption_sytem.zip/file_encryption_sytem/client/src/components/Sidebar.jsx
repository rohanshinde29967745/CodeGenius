/**
 * Sidebar Component
 * Collapsible navigation sidebar with smooth animations
 */
import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
    FiHome,
    FiLock,
    FiUnlock,
    FiFileText,
    FiClock,
    FiSettings,
    FiLogOut,
    FiMenu,
    FiX,
    FiShield,
} from 'react-icons/fi';
import './Sidebar.css';

const Sidebar = () => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const { logout, user } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const toggleSidebar = () => {
        setIsMobileOpen(!isMobileOpen);
    };

    const navItems = [
        { path: '/dashboard', icon: <FiHome />, label: 'Home' },
        { path: '/encrypt', icon: <FiLock />, label: 'Encrypt File' },
        { path: '/decrypt', icon: <FiUnlock />, label: 'Decrypt File' },
        { path: '/vault', icon: <FiShield />, label: 'Secure Vault' },
        { path: '/history', icon: <FiClock />, label: 'History' },
        { path: '/settings', icon: <FiSettings />, label: 'Settings' },
    ];

    return (
        <>
            {/* Mobile Toggle Button */}
            <button className="mobile-toggle" onClick={toggleSidebar}>
                {isMobileOpen ? <FiX /> : <FiMenu />}
            </button>

            {/* Overlay for mobile */}
            {isMobileOpen && (
                <div className="sidebar-overlay" onClick={toggleSidebar}></div>
            )}

            {/* Sidebar */}
            <aside
                className={`sidebar ${isExpanded ? 'expanded' : ''} ${isMobileOpen ? 'mobile-open' : ''}`}
                onMouseEnter={() => setIsExpanded(true)}
                onMouseLeave={() => setIsExpanded(false)}
            >
                {/* Logo Section */}
                <div className="sidebar-logo">
                    <div className="logo-icon">
                        <FiShield />
                    </div>
                    <span className="logo-text">CryptoVault</span>
                </div>

                {/* User Info */}
                <div className="sidebar-user">
                    <div className="user-avatar">
                        {user?.username?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <span className="user-name">{user?.username || 'User'}</span>
                </div>

                {/* Navigation Links */}
                <nav className="sidebar-nav">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) =>
                                `nav-link ${isActive ? 'active' : ''}`
                            }
                            onClick={() => setIsMobileOpen(false)}
                        >
                            <span className="nav-icon">{item.icon}</span>
                            <span className="nav-label">{item.label}</span>
                        </NavLink>
                    ))}
                </nav>

                {/* Logout Button */}
                <button className="logout-btn" onClick={handleLogout}>
                    <span className="nav-icon">
                        <FiLogOut />
                    </span>
                    <span className="nav-label">Logout</span>
                </button>
            </aside>
        </>
    );
};

export default Sidebar;
