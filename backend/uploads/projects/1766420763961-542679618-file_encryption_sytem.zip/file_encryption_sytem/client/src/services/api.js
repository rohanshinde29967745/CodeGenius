/**
 * API Service for File Encryption System
 * Handles all HTTP requests to the backend
 */
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

// Create axios instance with default config
const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('access_token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
    (response) => response,
    async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;

            try {
                const refreshToken = localStorage.getItem('refresh_token');
                if (refreshToken) {
                    const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
                        refresh_token: refreshToken,
                    });

                    const { access_token, refresh_token: newRefreshToken } = response.data;
                    localStorage.setItem('access_token', access_token);
                    localStorage.setItem('refresh_token', newRefreshToken);

                    originalRequest.headers.Authorization = `Bearer ${access_token}`;
                    return api(originalRequest);
                }
            } catch (refreshError) {
                localStorage.removeItem('access_token');
                localStorage.removeItem('refresh_token');
                window.location.href = '/login';
            }
        }

        return Promise.reject(error);
    }
);

// ==================== Auth API ====================

export const authAPI = {
    login: async (username, password) => {
        const response = await api.post('/auth/login', { username, password });
        return response.data;
    },

    register: async (username, email, password) => {
        const response = await api.post('/auth/register', { username, email, password });
        return response.data;
    },

    getCurrentUser: async () => {
        const response = await api.get('/auth/me');
        return response.data;
    },

    logout: () => {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
    },
};

// ==================== Encryption API ====================

export const encryptionAPI = {
    encryptFile: async (file, password, securityLevel) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('password', password);
        formData.append('security_level', securityLevel);

        const response = await api.post('/encrypt/file', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    },

    decryptFile: async (file, password) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('password', password);

        const response = await api.post('/decrypt/file', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    },

    encryptText: async (text, password, securityLevel) => {
        const response = await api.post('/encrypt/text', {
            text,
            password,
            security_level: securityLevel,
        });
        return response.data;
    },

    decryptText: async (encryptedText, password) => {
        const response = await api.post('/decrypt/text', {
            encrypted_text: encryptedText,
            password,
        });
        return response.data;
    },

    encryptImage: async (image, password, securityLevel) => {
        const formData = new FormData();
        formData.append('image', image);
        formData.append('password', password);
        formData.append('security_level', securityLevel);

        const response = await api.post('/encrypt/image', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    },

    decryptImage: async (image, password) => {
        const formData = new FormData();
        formData.append('image', image);
        formData.append('password', password);

        const response = await api.post('/decrypt/image', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    },

    downloadFile: async (filename) => {
        const response = await api.get(`/download/${filename}`, {
            responseType: 'blob',
        });
        return response.data;
    },
};

// ==================== History API ====================

export const historyAPI = {
    getHistory: async () => {
        const response = await api.get('/history');
        return response.data;
    },

    clearHistory: async () => {
        const response = await api.delete('/history');
        return response.data;
    },
};

// ==================== Settings API ====================

export const settingsAPI = {
    getSettings: async () => {
        const response = await api.get('/settings');
        return response.data;
    },

    updateSettings: async (settings) => {
        const response = await api.put('/settings', settings);
        return response.data;
    },

    changePassword: async (oldPassword, newPassword) => {
        const response = await api.put('/settings/password', {
            old_password: oldPassword,
            new_password: newPassword,
        });
        return response.data;
    },
};

// ==================== Security API ====================

export const securityAPI = {
    getSecurityScore: async () => {
        const response = await api.get('/security-score');
        return response.data;
    },
};

// ==================== Vault API ====================

// Helper to get vault token
const getVaultToken = () => localStorage.getItem('vault_token');

export const vaultAPI = {
    // OTP & Session Management
    requestOTP: async () => {
        const response = await api.post('/vault/request-otp');
        return response.data;
    },

    verifyOTP: async (otpCode) => {
        const response = await api.post('/vault/verify-otp', { otp_code: otpCode });
        if (response.data.session_token) {
            localStorage.setItem('vault_token', response.data.session_token);
        }
        return response.data;
    },

    lockVault: async () => {
        localStorage.removeItem('vault_token');
        const response = await api.post('/vault/lock');
        return response.data;
    },

    getStatus: async () => {
        const vaultToken = getVaultToken();
        const response = await api.get('/vault/status', {
            headers: vaultToken ? { 'X-Vault-Token': vaultToken } : {},
        });
        return response.data;
    },

    // Storage Info
    getStorageInfo: async () => {
        const response = await api.get('/vault/storage');
        return response.data;
    },

    // File Operations (require vault session)
    listFiles: async () => {
        const response = await api.get('/vault/files', {
            headers: { 'X-Vault-Token': getVaultToken() },
        });
        return response.data;
    },

    uploadFile: async (file, password, securityLevel) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('password', password);
        formData.append('security_level', securityLevel);

        const response = await api.post('/vault/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                'X-Vault-Token': getVaultToken(),
            },
        });
        return response.data;
    },

    decryptFile: async (fileId, password) => {
        const response = await api.post(`/vault/decrypt/${fileId}`,
            { password },
            { headers: { 'X-Vault-Token': getVaultToken() } }
        );
        return response.data;
    },

    downloadDecryptedFile: async (filename) => {
        const response = await api.get(`/vault/download/${filename}`, {
            responseType: 'blob',
            headers: { 'X-Vault-Token': getVaultToken() },
        });
        return response.data;
    },

    deleteFile: async (fileId) => {
        const response = await api.delete(`/vault/delete/${fileId}`, {
            headers: { 'X-Vault-Token': getVaultToken() },
        });
        return response.data;
    },

    // Premium
    togglePremium: async () => {
        const response = await api.post('/vault/premium/toggle');
        return response.data;
    },

    getPremiumStatus: async () => {
        const response = await api.get('/vault/premium/status');
        return response.data;
    },

    getPlans: async () => {
        const response = await api.get('/vault/premium/plans');
        return response.data;
    },

    createOrder: async (planId) => {
        const response = await api.post('/vault/premium/create-order', { plan_id: planId });
        return response.data;
    },

    verifyPayment: async (orderId, paymentId, signature) => {
        const response = await api.post('/vault/premium/verify-payment', {
            order_id: orderId,
            payment_id: paymentId,
            signature: signature,
        });
        return response.data;
    },

    activateDemoPremium: async () => {
        const response = await api.post('/vault/premium/activate-demo');
        return response.data;
    },

    deactivatePremium: async () => {
        const response = await api.post('/vault/premium/deactivate');
        return response.data;
    },

    // Clear vault session on logout
    clearSession: () => {
        localStorage.removeItem('vault_token');
    },
};

export default api;
