/**
 * Theme Context Provider
 * Manages dark/light mode theme across the app
 */
import { createContext, useContext, useState, useEffect } from 'react';
import { settingsAPI } from '../services/api';

const ThemeContext = createContext(null);

export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
};

export const ThemeProvider = ({ children }) => {
    const [isDarkMode, setIsDarkMode] = useState(true);
    const [loading, setLoading] = useState(true);

    // Fetch theme preference from API on mount
    useEffect(() => {
        fetchThemePreference();
    }, []);

    // Apply theme to document body whenever it changes
    useEffect(() => {
        if (isDarkMode) {
            document.body.classList.remove('light-mode');
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
            document.body.classList.add('light-mode');
        }
    }, [isDarkMode]);

    const fetchThemePreference = async () => {
        try {
            const token = localStorage.getItem('access_token');
            if (token) {
                const data = await settingsAPI.getSettings();
                setIsDarkMode(data.dark_mode);
            }
        } catch (error) {
            console.error('Failed to fetch theme preference:', error);
        } finally {
            setLoading(false);
        }
    };

    const toggleTheme = () => {
        setIsDarkMode(prev => !prev);
    };

    const setTheme = (darkMode) => {
        setIsDarkMode(darkMode);
    };

    const value = {
        isDarkMode,
        toggleTheme,
        setTheme,
        loading,
        refreshTheme: fetchThemePreference,
    };

    return (
        <ThemeContext.Provider value={value}>
            {children}
        </ThemeContext.Provider>
    );
};

export default ThemeContext;
