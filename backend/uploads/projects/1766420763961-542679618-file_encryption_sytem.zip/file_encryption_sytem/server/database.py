"""
Database utilities for SQLite operations.
"""
import sqlite3
from config import Config


def get_db_connection():
    """Get a database connection with row factory."""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_database():
    """Initialize the database with required tables."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password BLOB NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create encryption history table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS encryption_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            file_name TEXT,
            file_path TEXT,
            text_content TEXT,
            image_path TEXT,
            security_level TEXT,
            status TEXT DEFAULT 'success',
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create user settings table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_settings (
            user_id INTEGER PRIMARY KEY,
            dark_mode BOOLEAN DEFAULT 0,
            sound_enabled BOOLEAN DEFAULT 1,
            language TEXT DEFAULT 'English',
            auto_save BOOLEAN DEFAULT 1,
            show_history BOOLEAN DEFAULT 1,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create refresh tokens table for JWT
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS refresh_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token TEXT NOT NULL UNIQUE,
            expires_at TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # ==================== SECURE VAULT TABLES ====================
    
    # Add premium columns to users table (using separate ALTER statements for SQLite compatibility)
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN is_premium BOOLEAN DEFAULT 0')
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN storage_used INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    # Create vault_files table - stores encrypted files in secure vault
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vault_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            original_filename TEXT NOT NULL,
            encrypted_filename TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            encryption_password_hash TEXT NOT NULL,
            security_level TEXT DEFAULT 'aes-256',
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_accessed TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create vault_otp table - stores OTP codes for vault access
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vault_otp (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            otp_code TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL,
            attempts INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create vault_sessions table - tracks vault unlock sessions
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vault_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            session_token TEXT NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL,
            is_active BOOLEAN DEFAULT 1,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create vault_lockouts table - tracks 24-hour lockouts after session expiry
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vault_lockouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            unlocks_at TIMESTAMP NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    # Create storage_limits table with default values
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS storage_limits (
            user_type TEXT PRIMARY KEY,
            max_files INTEGER,
            max_storage_bytes INTEGER
        )
    ''')
    
    # Insert default storage limits (ignore if already exists)
    cursor.execute('''
        INSERT OR IGNORE INTO storage_limits (user_type, max_files, max_storage_bytes) 
        VALUES ('normal', 7, 52428800)
    ''')  # 7 files, 50MB
    
    cursor.execute('''
        INSERT OR IGNORE INTO storage_limits (user_type, max_files, max_storage_bytes) 
        VALUES ('premium', -1, -1)
    ''')  # Unlimited (-1)
    
    # Add premium_expires_at column to users table
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN premium_expires_at TIMESTAMP')
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    # Create payment_orders table for Razorpay integration
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payment_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            order_id TEXT NOT NULL UNIQUE,
            payment_id TEXT,
            signature TEXT,
            amount INTEGER NOT NULL,
            status TEXT DEFAULT 'created',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            paid_at TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully!")


if __name__ == "__main__":
    init_database()
