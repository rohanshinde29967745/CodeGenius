"""
Encryption utilities for file, text, and image encryption/decryption.
Supports AES-128, AES-256, and Fernet encryption.
"""
from cryptography.fernet import Fernet, InvalidToken
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import hashlib
import os


class EncryptionError(Exception):
    """Custom exception for encryption errors."""
    pass


class DecryptionError(Exception):
    """Custom exception for decryption errors."""
    pass


def generate_key(password: str, security_level: str) -> bytes:
    """
    Generate encryption key based on password and security level.
    
    Args:
        password: User's password string
        security_level: 'standard' (Fernet), 'aes-128', or 'aes-256'
    
    Returns:
        Encryption key as bytes
    """
    if security_level == 'standard':
        # Fernet requires a URL-safe base64-encoded 32-byte key
        # We derive it from the password using SHA256
        key_material = hashlib.sha256(password.encode()).digest()
        import base64
        return base64.urlsafe_b64encode(key_material)
    elif security_level == 'aes-128':
        # AES-128 requires a 16-byte key
        return hashlib.md5(password.encode()).digest()
    else:  # aes-256 or high
        # AES-256 requires a 32-byte key
        return hashlib.sha256(password.encode()).digest()


def encrypt_file(filepath: str, password: str, security_level: str) -> tuple:
    """
    Encrypt a file using the specified security level.
    
    Args:
        filepath: Path to the file to encrypt
        password: Encryption password
        security_level: 'standard', 'aes-128', or 'aes-256'
    
    Returns:
        Tuple of (encrypted_file_path, key_hex)
    """
    try:
        key = generate_key(password, security_level)
        output_path = filepath + '.enc'
        
        with open(filepath, 'rb') as f:
            data = f.read()
        
        if security_level == 'standard':
            fernet = Fernet(key)
            encrypted_data = fernet.encrypt(data)
        else:
            cipher = AES.new(key, AES.MODE_CBC)
            encrypted_data = cipher.iv + cipher.encrypt(pad(data, AES.block_size))
        
        with open(output_path, 'wb') as f:
            f.write(encrypted_data)
        
        return output_path, key.hex()
    
    except FileNotFoundError:
        raise EncryptionError(f"File not found: {filepath}")
    except Exception as e:
        raise EncryptionError(f"Encryption failed: {str(e)}")


def decrypt_file(filepath: str, password: str, security_level: str = None) -> str:
    """
    Decrypt an encrypted file.
    
    Args:
        filepath: Path to the encrypted file
        password: Decryption password
        security_level: Optional security level hint
    
    Returns:
        Path to the decrypted file
    """
    try:
        output_path = filepath.replace('.enc', '.dec')
        
        with open(filepath, 'rb') as f:
            data = f.read()
        
        decrypted_data = None
        
        # Try Fernet first
        try:
            key = generate_key(password, 'standard')
            fernet = Fernet(key)
            decrypted_data = fernet.decrypt(data)
        except InvalidToken:
            pass
        
        # Try AES-128
        if decrypted_data is None:
            try:
                iv = data[:16]
                ciphertext = data[16:]
                key = generate_key(password, 'aes-128')
                cipher = AES.new(key, AES.MODE_CBC, iv)
                decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
            except (ValueError, KeyError):
                pass
        
        # Try AES-256
        if decrypted_data is None:
            try:
                iv = data[:16]
                ciphertext = data[16:]
                key = generate_key(password, 'aes-256')
                cipher = AES.new(key, AES.MODE_CBC, iv)
                decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
            except (ValueError, KeyError):
                raise DecryptionError("Invalid password or corrupted file")
        
        with open(output_path, 'wb') as f:
            f.write(decrypted_data)
        
        return output_path
    
    except FileNotFoundError:
        raise DecryptionError(f"File not found: {filepath}")
    except DecryptionError:
        raise
    except Exception as e:
        raise DecryptionError(f"Decryption failed: {str(e)}")


def encrypt_text(text: str, password: str, security_level: str) -> tuple:
    """
    Encrypt text using the specified security level.
    
    Args:
        text: Plain text to encrypt
        password: Encryption password
        security_level: 'standard', 'aes-128', or 'aes-256'
    
    Returns:
        Tuple of (encrypted_text_hex, key_hex)
    """
    try:
        key = generate_key(password, security_level)
        
        if security_level == 'standard':
            fernet = Fernet(key)
            encrypted_data = fernet.encrypt(text.encode())
            return encrypted_data.decode(), key.hex()
        else:
            cipher = AES.new(key, AES.MODE_CBC)
            encrypted_data = cipher.iv + cipher.encrypt(pad(text.encode(), AES.block_size))
            return encrypted_data.hex(), key.hex()
    
    except Exception as e:
        raise EncryptionError(f"Text encryption failed: {str(e)}")


def decrypt_text(encrypted_text: str, password: str, security_level: str = None) -> str:
    """
    Decrypt encrypted text.
    
    Args:
        encrypted_text: Encrypted text (hex or base64)
        password: Decryption password
        security_level: Optional security level hint
    
    Returns:
        Decrypted plain text
    """
    try:
        # Try Fernet first
        try:
            key = generate_key(password, 'standard')
            fernet = Fernet(key)
            return fernet.decrypt(encrypted_text.encode()).decode()
        except (InvalidToken, Exception):
            pass
        
        # Try AES decryption
        try:
            data = bytes.fromhex(encrypted_text)
            iv = data[:16]
            ciphertext = data[16:]
            
            # Try AES-128
            try:
                key = generate_key(password, 'aes-128')
                cipher = AES.new(key, AES.MODE_CBC, iv)
                return unpad(cipher.decrypt(ciphertext), AES.block_size).decode()
            except (ValueError, KeyError):
                pass
            
            # Try AES-256
            key = generate_key(password, 'aes-256')
            cipher = AES.new(key, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ciphertext), AES.block_size).decode()
        
        except (ValueError, KeyError):
            raise DecryptionError("Invalid password or corrupted data")
    
    except DecryptionError:
        raise
    except Exception as e:
        raise DecryptionError(f"Text decryption failed: {str(e)}")


def encrypt_image(image_data: bytes, password: str, security_level: str) -> tuple:
    """
    Encrypt image data.
    
    Args:
        image_data: Raw image bytes
        password: Encryption password
        security_level: 'standard', 'aes-128', or 'aes-256'
    
    Returns:
        Tuple of (encrypted_data, key_hex)
    """
    try:
        key = generate_key(password, security_level)
        
        if security_level == 'standard':
            fernet = Fernet(key)
            encrypted_data = fernet.encrypt(image_data)
        else:
            cipher = AES.new(key, AES.MODE_CBC)
            encrypted_data = cipher.iv + cipher.encrypt(pad(image_data, AES.block_size))
        
        return encrypted_data, key.hex()
    
    except Exception as e:
        raise EncryptionError(f"Image encryption failed: {str(e)}")


def decrypt_image(encrypted_data: bytes, password: str, security_level: str = None) -> bytes:
    """
    Decrypt encrypted image data.
    
    Args:
        encrypted_data: Encrypted image bytes
        password: Decryption password
        security_level: Optional security level hint
    
    Returns:
        Decrypted image bytes
    """
    try:
        # Try Fernet first
        try:
            key = generate_key(password, 'standard')
            fernet = Fernet(key)
            return fernet.decrypt(encrypted_data)
        except InvalidToken:
            pass
        
        # Try AES decryption
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        
        # Try AES-128
        try:
            key = generate_key(password, 'aes-128')
            cipher = AES.new(key, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ciphertext), AES.block_size)
        except (ValueError, KeyError):
            pass
        
        # Try AES-256
        try:
            key = generate_key(password, 'aes-256')
            cipher = AES.new(key, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ciphertext), AES.block_size)
        except (ValueError, KeyError):
            raise DecryptionError("Invalid password or corrupted image")
    
    except DecryptionError:
        raise
    except Exception as e:
        raise DecryptionError(f"Image decryption failed: {str(e)}")
