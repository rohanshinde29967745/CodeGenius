"""
Email Service for sending OTP and notifications.
Uses SMTP for email delivery.
Configure with environment variables for production.
"""
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import Config


class EmailService:
    """Email service for sending OTP codes and notifications."""
    
    def __init__(self):
        self.smtp_host = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
        self.smtp_port = int(os.environ.get('SMTP_PORT', 587))
        self.smtp_user = os.environ.get('SMTP_USER', '')
        self.smtp_password = os.environ.get('SMTP_PASSWORD', '')
        self.sender_email = os.environ.get('SENDER_EMAIL', 'noreply@cryptovault.com')
        self.sender_name = os.environ.get('SENDER_NAME', 'CryptoVault')
    
    def is_configured(self) -> bool:
        """Check if email service is properly configured."""
        return bool(self.smtp_user and self.smtp_password)
    
    def send_email(self, to_email: str, subject: str, html_content: str) -> dict:
        """
        Send an email using SMTP.
        Returns dict with success status and message.
        """
        if not self.is_configured():
            return {
                'success': False,
                'error': 'Email service not configured. Set SMTP_USER and SMTP_PASSWORD environment variables.'
            }
        
        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = f"{self.sender_name} <{self.sender_email}>"
            msg['To'] = to_email
            
            # Attach HTML content
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            # Send email
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.sendmail(self.sender_email, to_email, msg.as_string())
            
            return {'success': True, 'message': 'Email sent successfully'}
        
        except smtplib.SMTPAuthenticationError:
            return {'success': False, 'error': 'SMTP authentication failed. Check credentials.'}
        except smtplib.SMTPException as e:
            return {'success': False, 'error': f'SMTP error: {str(e)}'}
        except Exception as e:
            return {'success': False, 'error': f'Failed to send email: {str(e)}'}
    
    def send_otp_email(self, to_email: str, otp_code: str, username: str = 'User') -> dict:
        """Send OTP code to user's email."""
        subject = f"🔐 Your CryptoVault OTP: {otp_code}"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #0f0f23; margin: 0; padding: 20px; }}
                .container {{ max-width: 500px; margin: 0 auto; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 16px; padding: 40px; }}
                .logo {{ text-align: center; margin-bottom: 30px; }}
                .logo-text {{ font-size: 28px; font-weight: bold; color: #667eea; }}
                h1 {{ color: #ffffff; font-size: 24px; margin-bottom: 10px; text-align: center; }}
                p {{ color: rgba(255,255,255,0.7); line-height: 1.6; text-align: center; }}
                .otp-box {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; padding: 25px; text-align: center; margin: 30px 0; }}
                .otp-code {{ font-size: 36px; font-weight: bold; color: #ffffff; letter-spacing: 8px; font-family: monospace; }}
                .warning {{ background: rgba(255,193,7,0.1); border: 1px solid rgba(255,193,7,0.3); border-radius: 10px; padding: 15px; margin-top: 20px; }}
                .warning p {{ color: #ffc107; font-size: 14px; margin: 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: rgba(255,255,255,0.4); font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="logo">
                    <span class="logo-text">🔐 CryptoVault</span>
                </div>
                <h1>Secure Vault Access</h1>
                <p>Hello {username},</p>
                <p>Use the following OTP code to unlock your Secure Vault:</p>
                <div class="otp-box">
                    <span class="otp-code">{otp_code}</span>
                </div>
                <p>This code expires in <strong>5 minutes</strong>.</p>
                <div class="warning">
                    <p>⚠️ Never share this code with anyone. CryptoVault will never ask for your OTP via phone or email.</p>
                </div>
                <div class="footer">
                    <p>This is an automated message from CryptoVault. Please do not reply.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return self.send_email(to_email, subject, html_content)
    
    def send_premium_welcome_email(self, to_email: str, username: str) -> dict:
        """Send welcome email to new premium subscriber."""
        subject = "🌟 Welcome to CryptoVault Premium!"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #0f0f23; margin: 0; padding: 20px; }}
                .container {{ max-width: 500px; margin: 0 auto; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 16px; padding: 40px; }}
                .header {{ text-align: center; margin-bottom: 30px; }}
                .premium-badge {{ display: inline-block; background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); color: #1a1a2e; padding: 10px 25px; border-radius: 50px; font-weight: bold; font-size: 18px; }}
                h1 {{ color: #ffffff; font-size: 28px; margin: 20px 0; text-align: center; }}
                p {{ color: rgba(255,255,255,0.7); line-height: 1.8; }}
                .features {{ background: rgba(255,255,255,0.05); border-radius: 12px; padding: 25px; margin: 25px 0; }}
                .feature {{ display: flex; align-items: center; margin: 15px 0; color: #ffffff; }}
                .check {{ color: #38ef7d; margin-right: 12px; font-size: 20px; }}
                .footer {{ text-align: center; margin-top: 30px; color: rgba(255,255,255,0.4); font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <span class="premium-badge">⭐ PREMIUM</span>
                    <h1>Welcome to Premium, {username}!</h1>
                </div>
                <p>Thank you for upgrading to CryptoVault Premium! You now have access to exclusive features:</p>
                <div class="features">
                    <div class="feature"><span class="check">✓</span> Unlimited file storage</div>
                    <div class="feature"><span class="check">✓</span> Unlimited vault session time</div>
                    <div class="feature"><span class="check">✓</span> No 24-hour lockout</div>
                    <div class="feature"><span class="check">✓</span> Priority support</div>
                </div>
                <p>Start using your premium benefits by visiting your Secure Vault!</p>
                <div class="footer">
                    <p>Questions? Contact us at support@cryptovault.com</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return self.send_email(to_email, subject, html_content)


# Singleton instance
email_service = EmailService()
