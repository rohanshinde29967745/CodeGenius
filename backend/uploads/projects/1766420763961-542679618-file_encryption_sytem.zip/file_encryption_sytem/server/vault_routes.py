"""
Secure Vault API Routes
Handles vault access, file management, and premium features.
"""
from flask import Blueprint, request, jsonify, send_file
from functools import wraps
from werkzeug.utils import secure_filename
from bcrypt import hashpw, gensalt, checkpw
import os
import uuid

from config import Config
from database import get_db_connection
from vault_utils import (
    create_vault_otp, verify_vault_otp,
    verify_vault_session, invalidate_vault_session,
    get_user_storage_info, check_storage_limit,
    toggle_premium, check_vault_lockout, is_user_premium
)
from encryption_utils import encrypt_file, decrypt_file, EncryptionError, DecryptionError
from email_service import email_service
from payment_service import (
    create_order, verify_payment, activate_premium, deactivate_premium,
    check_premium_status, get_subscription_plans, is_razorpay_configured
)

# Create Blueprint
vault_bp = Blueprint('vault', __name__, url_prefix='/api/vault')

# Secure vault folder
VAULT_FOLDER = os.path.join(Config.BASE_DIR, 'secure_vault')
os.makedirs(VAULT_FOLDER, exist_ok=True)


# ==================== DECORATORS ====================

def get_current_user_from_token():
    """Extract current user from JWT token in request."""
    import jwt
    token = None
    
    if 'Authorization' in request.headers:
        auth_header = request.headers['Authorization']
        if auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
    
    if not token:
        return None
    
    try:
        data = jwt.decode(token, Config.JWT_SECRET_KEY, algorithms=['HS256'])
        if data.get('type') != 'access':
            return None
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE id = ?', (data['user_id'],)).fetchone()
        conn.close()
        
        if user:
            return dict(user)
        return None
    except:
        return None


def token_required(f):
    """Decorator to protect routes with JWT authentication."""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        kwargs['current_user'] = user
        return f(*args, **kwargs)
    return decorated


def vault_session_required(f):
    """Decorator to ensure vault is unlocked."""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Get vault session token from header
        vault_token = request.headers.get('X-Vault-Token')
        if not vault_token:
            return jsonify({'error': 'Vault session token required', 'vault_locked': True}), 403
        
        # Verify session
        session_status = verify_vault_session(user['id'], vault_token)
        if not session_status['valid']:
            return jsonify({
                'error': session_status.get('error', 'Invalid vault session'),
                'vault_locked': True,
                'locked_out': session_status.get('locked_out', False)
            }), 403
        
        kwargs['current_user'] = user
        kwargs['vault_session'] = session_status
        return f(*args, **kwargs)
    return decorated


# ==================== OTP ROUTES ====================

@vault_bp.route('/request-otp', methods=['POST'])
@token_required
def request_otp(current_user):
    """Request an OTP code to unlock the vault."""
    try:
        # Check if user is locked out (premium users bypass lockout)
        if not is_user_premium(current_user['id']):
            lockout = check_vault_lockout(current_user['id'])
            if lockout['locked_out']:
                return jsonify({
                    'error': f"Vault is locked. Try again in {lockout['remaining_time']}",
                    'locked_out': True,
                    'unlocks_at': lockout['unlocks_at']
                }), 403
        
        # Generate OTP
        otp_result = create_vault_otp(current_user['id'])
        otp_code = otp_result['otp_code']
        
        # Try to send OTP via email
        if email_service.is_configured():
            email_result = email_service.send_otp_email(
                to_email=current_user['email'],
                otp_code=otp_code,
                username=current_user['username']
            )
            
            if email_result['success']:
                return jsonify({
                    'message': 'OTP sent to your email',
                    'email': current_user['email'],
                    'expires_in': '5 minutes',
                    'email_sent': True
                })
            else:
                # Email failed, return demo OTP as fallback
                return jsonify({
                    'message': 'Email service unavailable. Use demo OTP.',
                    'email': current_user['email'],
                    'expires_in': '5 minutes',
                    'demo_otp': otp_code,
                    'email_error': email_result.get('error')
                })
        else:
            # Email not configured, return demo OTP
            return jsonify({
                'message': 'Email not configured. Use demo OTP below.',
                'email': current_user['email'],
                'expires_in': '5 minutes',
                'demo_otp': otp_code,
                'email_configured': False
            })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/verify-otp', methods=['POST'])
@token_required
def verify_otp(current_user):
    """Verify OTP and unlock the vault."""
    try:
        data = request.get_json()
        otp_code = data.get('otp_code', '').strip()
        
        if not otp_code or len(otp_code) != 6:
            return jsonify({'error': 'Please enter a valid 6-digit OTP'}), 400
        
        result = verify_vault_otp(current_user['id'], otp_code)
        
        if not result['success']:
            return jsonify({'error': result['error']}), 400
        
        return jsonify({
            'message': 'Vault unlocked successfully!',
            'session_token': result['session_token'],
            'expires_at': result['expires_at'],
            'session_duration': '10 minutes'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/lock', methods=['POST'])
@token_required
def lock_vault(current_user):
    """Manually lock the vault."""
    try:
        invalidate_vault_session(current_user['id'])
        return jsonify({'message': 'Vault locked successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/status', methods=['GET'])
@token_required
def vault_status(current_user):
    """Check vault status - locked, unlocked, or in lockout."""
    try:
        # Check lockout first
        lockout = check_vault_lockout(current_user['id'])
        if lockout['locked_out']:
            return jsonify({
                'status': 'locked_out',
                'unlocks_at': lockout['unlocks_at'],
                'remaining_time': lockout['remaining_time']
            })
        
        # Check for active session
        vault_token = request.headers.get('X-Vault-Token')
        if vault_token:
            session_status = verify_vault_session(current_user['id'], vault_token)
            if session_status['valid']:
                return jsonify({
                    'status': 'unlocked',
                    'remaining_time': session_status['remaining_time'],
                    'remaining_seconds': session_status['remaining_seconds']
                })
        
        return jsonify({'status': 'locked'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== STORAGE INFO ROUTES ====================

@vault_bp.route('/storage', methods=['GET'])
@token_required
def get_storage(current_user):
    """Get user's storage usage and limits."""
    try:
        info = get_user_storage_info(current_user['id'])
        return jsonify(info)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== FILE MANAGEMENT ROUTES ====================

@vault_bp.route('/files', methods=['GET'])
@vault_session_required
def list_files(current_user, vault_session):
    """List all files in user's vault."""
    try:
        conn = get_db_connection()
        files = conn.execute('''
            SELECT id, original_filename, file_size, security_level, uploaded_at, last_accessed
            FROM vault_files 
            WHERE user_id = ?
            ORDER BY uploaded_at DESC
        ''', (current_user['id'],)).fetchall()
        conn.close()
        
        return jsonify({
            'files': [dict(f) for f in files],
            'session_remaining': vault_session['remaining_time']
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/upload', methods=['POST'])
@vault_session_required
def upload_file(current_user, vault_session):
    """Upload and encrypt a file to the vault."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        password = request.form.get('password')
        security_level = request.form.get('security_level', 'aes-256').lower()
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not password or len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters'}), 400
        
        # Get file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Seek back to start
        
        # Check storage limits
        limit_check = check_storage_limit(current_user['id'], file_size)
        if not limit_check['allowed']:
            return jsonify({'error': limit_check['error']}), 403
        
        # Create user's vault folder
        user_vault = os.path.join(VAULT_FOLDER, str(current_user['id']))
        os.makedirs(user_vault, exist_ok=True)
        
        # Save file temporarily
        original_filename = secure_filename(file.filename)
        temp_filename = f"{uuid.uuid4()}_{original_filename}"
        temp_path = os.path.join(Config.UPLOADS_FOLDER, temp_filename)
        file.save(temp_path)
        
        try:
            # Encrypt the file
            encrypted_path, key_hex = encrypt_file(temp_path, password, security_level)
            
            # Move encrypted file to vault
            encrypted_filename = f"{uuid.uuid4()}.enc"
            vault_path = os.path.join(user_vault, encrypted_filename)
            os.rename(encrypted_path, vault_path)
            
            # Hash the password for verification during decryption
            password_hash = hashpw(password.encode(), gensalt())
            
            # Save to database
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO vault_files 
                (user_id, original_filename, encrypted_filename, file_size, encryption_password_hash, security_level)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (current_user['id'], original_filename, encrypted_filename, file_size, password_hash, security_level))
            
            # Update user's storage used
            conn.execute('''
                UPDATE users SET storage_used = storage_used + ? WHERE id = ?
            ''', (file_size, current_user['id']))
            
            conn.commit()
            conn.close()
            
        finally:
            # Clean up temp file
            if os.path.exists(temp_path):
                os.remove(temp_path)
        
        return jsonify({
            'message': 'File uploaded and encrypted successfully!',
            'filename': original_filename,
            'size': file_size,
            'security_level': security_level
        })
    
    except EncryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/decrypt/<int:file_id>', methods=['POST'])
@vault_session_required
def decrypt_vault_file(current_user, vault_session, file_id):
    """Decrypt a file from the vault."""
    try:
        data = request.get_json()
        password = data.get('password', '')
        
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        conn = get_db_connection()
        
        # Get file info
        file_info = conn.execute('''
            SELECT * FROM vault_files WHERE id = ? AND user_id = ?
        ''', (file_id, current_user['id'])).fetchone()
        
        if not file_info:
            conn.close()
            return jsonify({'error': 'File not found'}), 404
        
        # Verify password
        if not checkpw(password.encode(), file_info['encryption_password_hash']):
            conn.close()
            return jsonify({'error': 'Invalid password'}), 401
        
        # Get encrypted file path
        user_vault = os.path.join(VAULT_FOLDER, str(current_user['id']))
        encrypted_path = os.path.join(user_vault, file_info['encrypted_filename'])
        
        if not os.path.exists(encrypted_path):
            conn.close()
            return jsonify({'error': 'Encrypted file not found on server'}), 404
        
        # Decrypt the file
        try:
            decrypted_path = decrypt_file(encrypted_path, password, file_info['security_level'])
            
            # Update last accessed
            conn.execute('''
                UPDATE vault_files SET last_accessed = CURRENT_TIMESTAMP WHERE id = ?
            ''', (file_id,))
            conn.commit()
            conn.close()
            
            # Return the decrypted file path for download
            decrypted_filename = os.path.basename(decrypted_path)
            
            return jsonify({
                'message': 'File decrypted successfully!',
                'download_path': decrypted_filename,
                'original_filename': file_info['original_filename']
            })
        
        except DecryptionError as e:
            conn.close()
            return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/download/<filename>', methods=['GET'])
@vault_session_required
def download_decrypted_file(current_user, vault_session, filename):
    """Download a decrypted file and then delete it from server."""
    try:
        filepath = os.path.join(Config.UPLOADS_FOLDER, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        # Send file and schedule deletion
        response = send_file(filepath, as_attachment=True)
        
        # Delete file after sending (in production, use a background task)
        @response.call_on_close
        def cleanup():
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
            except:
                pass
        
        return response
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/delete/<int:file_id>', methods=['DELETE'])
@vault_session_required
def delete_vault_file(current_user, vault_session, file_id):
    """Delete a file from the vault."""
    try:
        conn = get_db_connection()
        
        # Get file info
        file_info = conn.execute('''
            SELECT * FROM vault_files WHERE id = ? AND user_id = ?
        ''', (file_id, current_user['id'])).fetchone()
        
        if not file_info:
            conn.close()
            return jsonify({'error': 'File not found'}), 404
        
        # Delete physical file
        user_vault = os.path.join(VAULT_FOLDER, str(current_user['id']))
        encrypted_path = os.path.join(user_vault, file_info['encrypted_filename'])
        
        if os.path.exists(encrypted_path):
            os.remove(encrypted_path)
        
        # Update storage used
        conn.execute('''
            UPDATE users SET storage_used = storage_used - ? WHERE id = ?
        ''', (file_info['file_size'], current_user['id']))
        
        # Delete from database
        conn.execute('DELETE FROM vault_files WHERE id = ?', (file_id,))
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'File deleted successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== PREMIUM ROUTES ====================

@vault_bp.route('/premium/toggle', methods=['POST'])
@token_required
def toggle_user_premium(current_user):
    """Toggle premium status (demo mode only)."""
    try:
        result = toggle_premium(current_user['id'])
        
        # Send welcome email if premium activated
        if result.get('is_premium') and email_service.is_configured():
            email_service.send_premium_welcome_email(
                to_email=current_user['email'],
                username=current_user['username']
            )
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/status', methods=['GET'])
@token_required
def premium_status(current_user):
    """Get detailed premium status with subscription info."""
    try:
        status = check_premium_status(current_user['id'])
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/plans', methods=['GET'])
def get_plans():
    """Get available subscription plans."""
    try:
        plans = get_subscription_plans()
        return jsonify({
            'plans': plans,
            'razorpay_configured': is_razorpay_configured()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/create-order', methods=['POST'])
@token_required
def create_payment_order(current_user):
    """Create a Razorpay order for premium subscription."""
    try:
        data = request.get_json() or {}
        plan_id = data.get('plan_id', 'premium_monthly')
        
        # Get plan details
        plans = get_subscription_plans()
        plan = next((p for p in plans if p['id'] == plan_id), plans[0])
        
        result = create_order(current_user['id'], plan['price'])
        
        if result.get('success'):
            result['plan'] = plan
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/verify-payment', methods=['POST'])
@token_required
def verify_payment_route(current_user):
    """Verify Razorpay payment and activate premium."""
    try:
        data = request.get_json()
        
        order_id = data.get('order_id', '')
        payment_id = data.get('payment_id', '')
        signature = data.get('signature', '')
        
        result = verify_payment(order_id, payment_id, signature, current_user['id'])
        
        if result.get('success'):
            # Send welcome email
            if email_service.is_configured():
                email_service.send_premium_welcome_email(
                    to_email=current_user['email'],
                    username=current_user['username']
                )
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/activate-demo', methods=['POST'])
@token_required
def activate_demo_premium(current_user):
    """Activate premium in demo mode (for testing)."""
    try:
        result = activate_premium(current_user['id'], duration_days=30)
        
        # Send welcome email
        if email_service.is_configured():
            email_service.send_premium_welcome_email(
                to_email=current_user['email'],
                username=current_user['username']
            )
        
        return jsonify({
            'success': True,
            'message': 'Demo premium activated for 30 days!',
            **result
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@vault_bp.route('/premium/deactivate', methods=['POST'])
@token_required
def deactivate_premium_route(current_user):
    """Deactivate premium subscription."""
    try:
        result = deactivate_premium(current_user['id'])
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
