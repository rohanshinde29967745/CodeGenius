"""
Payment Service for Premium Subscription.
Integrates with Razorpay for payment processing.
Configure with environment variables for production.
"""
import os
import hmac
import hashlib
from datetime import datetime, timedelta
from database import get_db_connection


# Razorpay configuration
RAZORPAY_KEY_ID = os.environ.get('RAZORPAY_KEY_ID', '')
RAZORPAY_KEY_SECRET = os.environ.get('RAZORPAY_KEY_SECRET', '')
PREMIUM_PRICE = int(os.environ.get('PREMIUM_PRICE', 299))  # Price in INR
PREMIUM_DURATION_DAYS = int(os.environ.get('PREMIUM_DURATION_DAYS', 30))  # 30 days subscription


def is_razorpay_configured() -> bool:
    """Check if Razorpay is properly configured."""
    return bool(RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET)


def create_order(user_id: int, amount: int = None) -> dict:
    """
    Create a Razorpay order for premium subscription.
    Returns order details for frontend.
    """
    if not is_razorpay_configured():
        # Demo mode - return mock order
        return {
            'success': True,
            'demo_mode': True,
            'order_id': f'demo_order_{user_id}_{datetime.utcnow().timestamp()}',
            'amount': amount or PREMIUM_PRICE,
            'currency': 'INR',
            'message': 'Demo mode - Razorpay not configured'
        }
    
    try:
        import razorpay
        client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
        
        order_amount = (amount or PREMIUM_PRICE) * 100  # Razorpay uses paise
        
        order_data = {
            'amount': order_amount,
            'currency': 'INR',
            'receipt': f'premium_{user_id}_{int(datetime.utcnow().timestamp())}',
            'notes': {
                'user_id': str(user_id),
                'plan': 'premium_monthly'
            }
        }
        
        order = client.order.create(data=order_data)
        
        # Store order in database for verification later
        conn = get_db_connection()
        conn.execute('''
            INSERT INTO payment_orders (user_id, order_id, amount, status)
            VALUES (?, ?, ?, 'created')
        ''', (user_id, order['id'], order_amount))
        conn.commit()
        conn.close()
        
        return {
            'success': True,
            'order_id': order['id'],
            'amount': order_amount,
            'currency': 'INR',
            'key_id': RAZORPAY_KEY_ID
        }
    
    except ImportError:
        return {
            'success': False,
            'error': 'Razorpay SDK not installed. Run: pip install razorpay'
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Failed to create order: {str(e)}'
        }


def verify_payment(order_id: str, payment_id: str, signature: str, user_id: int) -> dict:
    """
    Verify Razorpay payment signature and activate premium.
    """
    if not is_razorpay_configured():
        # Demo mode - auto-activate premium
        result = activate_premium(user_id)
        return {
            'success': True,
            'demo_mode': True,
            'message': 'Demo mode - Premium activated',
            **result
        }
    
    try:
        # Verify signature
        msg = f'{order_id}|{payment_id}'
        expected_signature = hmac.new(
            RAZORPAY_KEY_SECRET.encode(),
            msg.encode(),
            hashlib.sha256
        ).hexdigest()
        
        if signature != expected_signature:
            return {'success': False, 'error': 'Invalid payment signature'}
        
        # Update order status
        conn = get_db_connection()
        conn.execute('''
            UPDATE payment_orders 
            SET payment_id = ?, signature = ?, status = 'paid', paid_at = CURRENT_TIMESTAMP
            WHERE order_id = ? AND user_id = ?
        ''', (payment_id, signature, order_id, user_id))
        conn.commit()
        conn.close()
        
        # Activate premium
        result = activate_premium(user_id)
        
        return {
            'success': True,
            'message': 'Payment verified and premium activated!',
            **result
        }
    
    except Exception as e:
        return {
            'success': False,
            'error': f'Payment verification failed: {str(e)}'
        }


def activate_premium(user_id: int, duration_days: int = None) -> dict:
    """
    Activate premium subscription for a user.
    """
    duration = duration_days or PREMIUM_DURATION_DAYS
    expires_at = datetime.utcnow() + timedelta(days=duration)
    
    conn = get_db_connection()
    
    # Check if user already has premium
    user = conn.execute('SELECT is_premium, premium_expires_at FROM users WHERE id = ?', (user_id,)).fetchone()
    
    if user and user['is_premium'] and user['premium_expires_at']:
        # Extend existing subscription
        current_expiry = datetime.fromisoformat(user['premium_expires_at'])
        if current_expiry > datetime.utcnow():
            expires_at = current_expiry + timedelta(days=duration)
    
    # Update user to premium
    conn.execute('''
        UPDATE users SET is_premium = 1, premium_expires_at = ? WHERE id = ?
    ''', (expires_at, user_id))
    
    conn.commit()
    conn.close()
    
    return {
        'is_premium': True,
        'expires_at': expires_at.isoformat(),
        'duration_days': duration
    }


def deactivate_premium(user_id: int) -> dict:
    """
    Deactivate premium subscription for a user.
    """
    conn = get_db_connection()
    conn.execute('''
        UPDATE users SET is_premium = 0, premium_expires_at = NULL WHERE id = ?
    ''', (user_id,))
    conn.commit()
    conn.close()
    
    return {
        'success': True,
        'is_premium': False,
        'message': 'Premium subscription deactivated'
    }


def check_premium_status(user_id: int) -> dict:
    """
    Check if user's premium subscription is active.
    Auto-deactivates if expired.
    """
    conn = get_db_connection()
    user = conn.execute('''
        SELECT is_premium, premium_expires_at FROM users WHERE id = ?
    ''', (user_id,)).fetchone()
    
    if not user:
        conn.close()
        return {'is_premium': False, 'error': 'User not found'}
    
    if not user['is_premium']:
        conn.close()
        return {'is_premium': False}
    
    # Check if premium has expired
    if user['premium_expires_at']:
        expires_at = datetime.fromisoformat(user['premium_expires_at'])
        if datetime.utcnow() > expires_at:
            # Premium expired, deactivate
            conn.execute('''
                UPDATE users SET is_premium = 0 WHERE id = ?
            ''', (user_id,))
            conn.commit()
            conn.close()
            return {
                'is_premium': False,
                'expired': True,
                'expired_at': expires_at.isoformat()
            }
        
        # Calculate remaining days
        remaining = expires_at - datetime.utcnow()
        remaining_days = remaining.days
        
        conn.close()
        return {
            'is_premium': True,
            'expires_at': expires_at.isoformat(),
            'remaining_days': remaining_days
        }
    
    # Premium without expiry (lifetime/demo)
    conn.close()
    return {
        'is_premium': True,
        'expires_at': None,
        'lifetime': True
    }


def get_subscription_plans() -> list:
    """Get available subscription plans."""
    return [
        {
            'id': 'premium_monthly',
            'name': 'Premium Monthly',
            'price': PREMIUM_PRICE,
            'currency': 'INR',
            'duration_days': 30,
            'features': [
                'Unlimited file storage',
                'Unlimited vault session time',
                'No 24-hour lockout',
                'Priority support'
            ]
        },
        {
            'id': 'premium_yearly',
            'name': 'Premium Yearly',
            'price': PREMIUM_PRICE * 10,  # 2 months free
            'currency': 'INR',
            'duration_days': 365,
            'features': [
                'Everything in Monthly',
                '2 months free',
                'Early access to new features'
            ]
        }
    ]
