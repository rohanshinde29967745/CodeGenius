"""
Vault utilities for OTP generation, session management, and storage limits.
"""
import random
import string
import hashlib
import uuid
from datetime import datetime, timedelta
from database import get_db_connection


# ==================== OTP UTILITIES ====================

def generate_otp(length: int = 6) -> str:
    """Generate a random numeric OTP code."""
    return ''.join(random.choices(string.digits, k=length))


def create_vault_otp(user_id: int) -> dict:
    """
    Create a new OTP for vault access.
    OTP expires in 5 minutes.
    Returns the OTP code (to be sent to user's email).
    """
    otp_code = generate_otp()
    expires_at = datetime.utcnow() + timedelta(minutes=5)
    
    conn = get_db_connection()
    
    # Delete any existing OTP for this user
    conn.execute('DELETE FROM vault_otp WHERE user_id = ?', (user_id,))
    
    # Insert new OTP
    conn.execute('''
        INSERT INTO vault_otp (user_id, otp_code, expires_at, attempts)
        VALUES (?, ?, ?, 0)
    ''', (user_id, otp_code, expires_at))
    
    conn.commit()
    conn.close()
    
    return {
        'otp_code': otp_code,
        'expires_at': expires_at.isoformat()
    }


def verify_vault_otp(user_id: int, otp_code: str) -> dict:
    """
    Verify the OTP code for vault access.
    Returns success status and vault session token if valid.
    Max 3 attempts allowed.
    """
    conn = get_db_connection()
    
    otp_record = conn.execute('''
        SELECT * FROM vault_otp WHERE user_id = ?
    ''', (user_id,)).fetchone()
    
    if not otp_record:
        conn.close()
        return {'success': False, 'error': 'No OTP found. Please request a new one.'}
    
    # Check if expired
    expires_at = datetime.fromisoformat(otp_record['expires_at'])
    if datetime.utcnow() > expires_at:
        conn.execute('DELETE FROM vault_otp WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()
        return {'success': False, 'error': 'OTP has expired. Please request a new one.'}
    
    # Check attempts
    if otp_record['attempts'] >= 3:
        conn.execute('DELETE FROM vault_otp WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()
        return {'success': False, 'error': 'Too many attempts. Please request a new OTP.'}
    
    # Verify OTP
    if otp_record['otp_code'] != otp_code:
        conn.execute('''
            UPDATE vault_otp SET attempts = attempts + 1 WHERE user_id = ?
        ''', (user_id,))
        conn.commit()
        remaining = 3 - (otp_record['attempts'] + 1)
        conn.close()
        return {'success': False, 'error': f'Invalid OTP. {remaining} attempts remaining.'}
    
    # OTP is valid - delete it and create session
    conn.execute('DELETE FROM vault_otp WHERE user_id = ?', (user_id,))
    conn.commit()
    conn.close()
    
    # Create vault session
    session = create_vault_session(user_id)
    
    return {
        'success': True,
        'session_token': session['session_token'],
        'expires_at': session['expires_at']
    }


# ==================== SESSION MANAGEMENT ====================

def is_user_premium(user_id: int) -> bool:
    """Check if user has active premium subscription."""
    conn = get_db_connection()
    user = conn.execute('''
        SELECT is_premium, premium_expires_at FROM users WHERE id = ?
    ''', (user_id,)).fetchone()
    conn.close()
    
    if not user or not user['is_premium']:
        return False
    
    # Check if premium has expired
    if user['premium_expires_at']:
        expires_at = datetime.fromisoformat(user['premium_expires_at'])
        if datetime.utcnow() > expires_at:
            # Premium expired - but don't update here, let payment_service handle it
            return False
    
    return True


def create_vault_session(user_id: int) -> dict:
    """
    Create a new vault session.
    - Free users: 10 minutes session
    - Premium users: Unlimited session (365 days)
    """
    session_token = str(uuid.uuid4())
    
    # Check if user is premium for unlimited session
    premium = is_user_premium(user_id)
    if premium:
        # Premium users get 365 days (effectively unlimited)
        expires_at = datetime.utcnow() + timedelta(days=365)
        session_type = 'unlimited'
    else:
        # Free users get 10 minutes
        expires_at = datetime.utcnow() + timedelta(minutes=10)
        session_type = 'limited'
    
    conn = get_db_connection()
    
    # Deactivate any existing sessions for this user
    conn.execute('''
        UPDATE vault_sessions SET is_active = 0 WHERE user_id = ?
    ''', (user_id,))
    
    # Remove any existing lockout (user is unlocking fresh)
    conn.execute('DELETE FROM vault_lockouts WHERE user_id = ?', (user_id,))
    
    # Create new session
    conn.execute('''
        INSERT INTO vault_sessions (user_id, session_token, expires_at, is_active)
        VALUES (?, ?, ?, 1)
    ''', (user_id, session_token, expires_at))
    
    conn.commit()
    conn.close()
    
    return {
        'session_token': session_token,
        'expires_at': expires_at.isoformat(),
        'session_type': session_type,
        'is_premium': premium
    }


def verify_vault_session(user_id: int, session_token: str) -> dict:
    """
    Verify if a vault session is valid.
    - Free users: If session expires, 24-hour lockout
    - Premium users: No lockout, session lasts 365 days
    """
    conn = get_db_connection()
    
    # Check if user is premium (premium users skip lockout check)
    premium = is_user_premium(user_id)
    
    # Only check lockout for non-premium users
    if not premium:
        lockout = conn.execute('''
            SELECT * FROM vault_lockouts WHERE user_id = ?
        ''', (user_id,)).fetchone()
        
        if lockout:
            unlocks_at = datetime.fromisoformat(lockout['unlocks_at'])
            if datetime.utcnow() < unlocks_at:
                remaining = unlocks_at - datetime.utcnow()
                hours = int(remaining.total_seconds() // 3600)
                minutes = int((remaining.total_seconds() % 3600) // 60)
                conn.close()
                return {
                    'valid': False,
                    'locked_out': True,
                    'error': f'Vault is locked. Try again in {hours}h {minutes}m.'
                }
            else:
                # Lockout expired, remove it
                conn.execute('DELETE FROM vault_lockouts WHERE user_id = ?', (user_id,))
                conn.commit()
    
    # Check session
    session = conn.execute('''
        SELECT * FROM vault_sessions 
        WHERE user_id = ? AND session_token = ? AND is_active = 1
    ''', (user_id, session_token)).fetchone()
    
    if not session:
        conn.close()
        return {'valid': False, 'error': 'Invalid or expired session. Please unlock vault again.'}
    
    # Check if session expired
    expires_at = datetime.fromisoformat(session['expires_at'])
    if datetime.utcnow() > expires_at:
        # Session expired
        conn.execute('''
            UPDATE vault_sessions SET is_active = 0 WHERE id = ?
        ''', (session['id'],))
        
        # Only lockout non-premium users
        if not premium:
            lockout_until = datetime.utcnow() + timedelta(hours=24)
            conn.execute('''
                INSERT OR REPLACE INTO vault_lockouts (user_id, unlocks_at)
                VALUES (?, ?)
            ''', (user_id, lockout_until))
            
            conn.commit()
            conn.close()
            
            return {
                'valid': False,
                'locked_out': True,
                'error': 'Session expired. Vault is now locked for 24 hours.'
            }
        else:
            # Premium user - just ask to re-authenticate, no lockout
            conn.commit()
            conn.close()
            return {
                'valid': False,
                'locked_out': False,
                'error': 'Session expired. Please unlock vault again.'
            }
    
    # Session is valid - calculate remaining time
    remaining = expires_at - datetime.utcnow()
    
    if premium:
        # Premium users see "Unlimited" instead of countdown
        conn.close()
        return {
            'valid': True,
            'is_premium': True,
            'remaining_time': 'Unlimited',
            'remaining_seconds': -1  # -1 indicates unlimited
        }
    else:
        minutes = int(remaining.total_seconds() // 60)
        seconds = int(remaining.total_seconds() % 60)
        
        conn.close()
        
        return {
            'valid': True,
            'is_premium': False,
            'remaining_time': f'{minutes}:{seconds:02d}',
            'remaining_seconds': int(remaining.total_seconds())
        }


def invalidate_vault_session(user_id: int) -> bool:
    """Manually invalidate a user's vault session (lock the vault)."""
    conn = get_db_connection()
    conn.execute('''
        UPDATE vault_sessions SET is_active = 0 WHERE user_id = ?
    ''', (user_id,))
    conn.commit()
    conn.close()
    return True


# ==================== STORAGE UTILITIES ====================

def get_user_storage_info(user_id: int) -> dict:
    """Get storage usage and limits for a user."""
    conn = get_db_connection()
    
    # Get user info
    user = conn.execute('SELECT is_premium, storage_used FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        conn.close()
        return {'error': 'User not found'}
    
    is_premium = bool(user['is_premium'])
    user_type = 'premium' if is_premium else 'normal'
    
    # Get limits
    limits = conn.execute('SELECT * FROM storage_limits WHERE user_type = ?', (user_type,)).fetchone()
    
    # Get file count
    file_count = conn.execute('''
        SELECT COUNT(*) as count FROM vault_files WHERE user_id = ?
    ''', (user_id,)).fetchone()['count']
    
    # Get total storage used
    storage_used = conn.execute('''
        SELECT COALESCE(SUM(file_size), 0) as total FROM vault_files WHERE user_id = ?
    ''', (user_id,)).fetchone()['total']
    
    conn.close()
    
    max_files = limits['max_files'] if limits else 7
    max_storage = limits['max_storage_bytes'] if limits else 52428800
    
    return {
        'is_premium': is_premium,
        'file_count': file_count,
        'max_files': max_files,  # -1 means unlimited
        'storage_used': storage_used,
        'max_storage': max_storage,  # -1 means unlimited
        'storage_used_mb': round(storage_used / (1024 * 1024), 2),
        'max_storage_mb': round(max_storage / (1024 * 1024), 2) if max_storage > 0 else -1
    }


def check_storage_limit(user_id: int, file_size: int) -> dict:
    """Check if user has enough storage space for a new file."""
    info = get_user_storage_info(user_id)
    
    if 'error' in info:
        return {'allowed': False, 'error': info['error']}
    
    # Check file count limit
    if info['max_files'] > 0 and info['file_count'] >= info['max_files']:
        return {
            'allowed': False,
            'error': f'File limit reached ({info["file_count"]}/{info["max_files"]}). Upgrade to Premium for unlimited storage.'
        }
    
    # Check storage limit
    if info['max_storage'] > 0 and (info['storage_used'] + file_size) > info['max_storage']:
        return {
            'allowed': False,
            'error': f'Storage limit reached ({info["storage_used_mb"]:.1f}MB/{info["max_storage_mb"]:.1f}MB). Upgrade to Premium for unlimited storage.'
        }
    
    return {'allowed': True}


def toggle_premium(user_id: int) -> dict:
    """Toggle premium status for a user."""
    conn = get_db_connection()
    
    user = conn.execute('SELECT is_premium FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        conn.close()
        return {'error': 'User not found'}
    
    new_status = 0 if user['is_premium'] else 1
    
    conn.execute('UPDATE users SET is_premium = ? WHERE id = ?', (new_status, user_id))
    conn.commit()
    conn.close()
    
    return {
        'success': True,
        'is_premium': bool(new_status),
        'message': 'Premium activated!' if new_status else 'Premium deactivated.'
    }


# ==================== VAULT LOCKOUT CHECK ====================

def check_vault_lockout(user_id: int) -> dict:
    """Check if user is currently locked out of vault."""
    conn = get_db_connection()
    
    lockout = conn.execute('''
        SELECT * FROM vault_lockouts WHERE user_id = ?
    ''', (user_id,)).fetchone()
    
    if not lockout:
        conn.close()
        return {'locked_out': False}
    
    unlocks_at = datetime.fromisoformat(lockout['unlocks_at'])
    if datetime.utcnow() >= unlocks_at:
        # Lockout expired, remove it
        conn.execute('DELETE FROM vault_lockouts WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()
        return {'locked_out': False}
    
    remaining = unlocks_at - datetime.utcnow()
    hours = int(remaining.total_seconds() // 3600)
    minutes = int((remaining.total_seconds() % 3600) // 60)
    
    conn.close()
    
    return {
        'locked_out': True,
        'unlocks_at': unlocks_at.isoformat(),
        'remaining_time': f'{hours}h {minutes}m'
    }
