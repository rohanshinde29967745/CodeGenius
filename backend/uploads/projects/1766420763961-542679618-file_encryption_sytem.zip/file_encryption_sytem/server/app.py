"""
Flask REST API Server for File Encryption System.
Provides endpoints for authentication, file encryption/decryption, and user management.
"""
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from functools import wraps
import jwt
import os
import uuid
from datetime import datetime, timedelta
from bcrypt import hashpw, gensalt, checkpw
from werkzeug.utils import secure_filename

from config import Config
from database import get_db_connection, init_database
from encryption_utils import (
    encrypt_file, decrypt_file,
    encrypt_text, decrypt_text,
    encrypt_image, decrypt_image,
    EncryptionError, DecryptionError
)

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Enable CORS for frontend - Allow all origins in development
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)

# Ensure uploads folder exists
os.makedirs(Config.UPLOADS_FOLDER, exist_ok=True)

# Register Vault Blueprint
from vault_routes import vault_bp
app.register_blueprint(vault_bp)


# ==================== JWT Authentication ====================

def generate_tokens(user_id: int) -> dict:
    """Generate access and refresh tokens for a user."""
    access_token = jwt.encode({
        'user_id': user_id,
        'exp': datetime.utcnow() + Config.JWT_ACCESS_TOKEN_EXPIRES,
        'type': 'access'
    }, Config.JWT_SECRET_KEY, algorithm='HS256')
    
    refresh_token = jwt.encode({
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(days=30),
        'type': 'refresh',
        'jti': str(uuid.uuid4())
    }, Config.JWT_SECRET_KEY, algorithm='HS256')
    
    return {
        'access_token': access_token,
        'refresh_token': refresh_token
    }


def token_required(f):
    """Decorator to protect routes with JWT authentication."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        try:
            data = jwt.decode(token, Config.JWT_SECRET_KEY, algorithms=['HS256'])
            if data.get('type') != 'access':
                return jsonify({'error': 'Invalid token type'}), 401
            
            conn = get_db_connection()
            user = conn.execute('SELECT * FROM users WHERE id = ?', (data['user_id'],)).fetchone()
            conn.close()
            
            if not user:
                return jsonify({'error': 'User not found'}), 401
            
            kwargs['current_user'] = dict(user)
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token'}), 401
        
        return f(*args, **kwargs)
    return decorated


def allowed_file(filename: str) -> bool:
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS


# ==================== API Routes ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({'status': 'healthy', 'message': 'File Encryption API is running'})


# ==================== Authentication Routes ====================

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Register a new user."""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        # Validation
        if not username or len(username) < 3:
            return jsonify({'error': 'Username must be at least 3 characters'}), 400
        if not email or '@' not in email:
            return jsonify({'error': 'Valid email is required'}), 400
        if not password or len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters'}), 400
        
        # Hash password
        hashed_pw = hashpw(password.encode(), gensalt())
        
        conn = get_db_connection()
        
        # Check if user exists
        existing = conn.execute(
            'SELECT id FROM users WHERE username = ? OR email = ?', 
            (username, email)
        ).fetchone()
        
        if existing:
            conn.close()
            return jsonify({'error': 'Username or email already exists'}), 409
        
        # Insert user
        cursor = conn.execute(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            (username, email, hashed_pw)
        )
        user_id = cursor.lastrowid
        
        # Create default settings
        conn.execute(
            'INSERT INTO user_settings (user_id) VALUES (?)',
            (user_id,)
        )
        
        conn.commit()
        conn.close()
        
        # Generate tokens
        tokens = generate_tokens(user_id)
        
        return jsonify({
            'message': 'Registration successful',
            'user': {'id': user_id, 'username': username, 'email': email},
            **tokens
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/login', methods=['POST'])
def login():
    """Authenticate user and return tokens."""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400
        
        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ?', 
            (username,)
        ).fetchone()
        conn.close()
        
        if not user or not checkpw(password.encode(), user['password']):
            return jsonify({'error': 'Invalid username or password'}), 401
        
        # Generate tokens
        tokens = generate_tokens(user['id'])
        
        return jsonify({
            'message': 'Login successful',
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email']
            },
            **tokens
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/refresh', methods=['POST'])
def refresh_token():
    """Refresh access token using refresh token."""
    try:
        data = request.get_json()
        refresh_token = data.get('refresh_token')
        
        if not refresh_token:
            return jsonify({'error': 'Refresh token is required'}), 400
        
        payload = jwt.decode(refresh_token, Config.JWT_SECRET_KEY, algorithms=['HS256'])
        
        if payload.get('type') != 'refresh':
            return jsonify({'error': 'Invalid token type'}), 401
        
        tokens = generate_tokens(payload['user_id'])
        return jsonify(tokens)
    
    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Refresh token has expired'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Invalid refresh token'}), 401


@app.route('/api/auth/me', methods=['GET'])
@token_required
def get_current_user(current_user):
    """Get current user information."""
    return jsonify({
        'id': current_user['id'],
        'username': current_user['username'],
        'email': current_user['email']
    })


# ==================== File Encryption Routes ====================

@app.route('/api/encrypt/file', methods=['POST'])
@token_required
def encrypt_file_route(current_user):
    """Encrypt an uploaded file."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        password = request.form.get('password')
        security_level = request.form.get('security_level', 'aes-256').lower()
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        # Map algorithm names
        level_map = {
            'aes-128': 'aes-128',
            'aes-256': 'aes-256',
            'standard': 'standard',
            'fernet': 'standard'
        }
        security_level = level_map.get(security_level, 'aes-256')
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        filepath = os.path.join(Config.UPLOADS_FOLDER, unique_filename)
        file.save(filepath)
        
        # Encrypt file
        encrypted_path, key_hex = encrypt_file(filepath, password, security_level)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, file_name, file_path, security_level, status) 
               VALUES (?, ?, ?, ?, ?, ?)''',
            (current_user['id'], 'encrypt', filename, encrypted_path, security_level, 'success')
        )
        conn.commit()
        conn.close()
        
        # Clean up original file
        if os.path.exists(filepath):
            os.remove(filepath)
        
        return jsonify({
            'message': 'File encrypted successfully',
            'encrypted_file': os.path.basename(encrypted_path),
            'key': key_hex,
            'security_level': security_level
        })
    
    except EncryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/decrypt/file', methods=['POST'])
@token_required
def decrypt_file_route(current_user):
    """Decrypt an uploaded encrypted file."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        password = request.form.get('password')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        filepath = os.path.join(Config.UPLOADS_FOLDER, unique_filename)
        file.save(filepath)
        
        # Decrypt file
        decrypted_path = decrypt_file(filepath, password)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, file_name, file_path, status) 
               VALUES (?, ?, ?, ?, ?)''',
            (current_user['id'], 'decrypt', filename, decrypted_path, 'success')
        )
        conn.commit()
        conn.close()
        
        # Clean up encrypted file
        if os.path.exists(filepath):
            os.remove(filepath)
        
        return jsonify({
            'message': 'File decrypted successfully',
            'decrypted_file': os.path.basename(decrypted_path)
        })
    
    except DecryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/download/<filename>', methods=['GET'])
@token_required
def download_file(current_user, filename):
    """Download an encrypted or decrypted file."""
    try:
        filepath = os.path.join(Config.UPLOADS_FOLDER, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        return send_file(filepath, as_attachment=True)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== Text Encryption Routes ====================

@app.route('/api/encrypt/text', methods=['POST'])
@token_required
def encrypt_text_route(current_user):
    """Encrypt text."""
    try:
        data = request.get_json()
        
        text = data.get('text', '')
        password = data.get('password', '')
        security_level = data.get('security_level', 'aes-256').lower()
        
        if not text:
            return jsonify({'error': 'Text is required'}), 400
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        # Map algorithm names
        level_map = {
            'aes-128': 'aes-128',
            'aes-256': 'aes-256',
            'standard': 'standard',
            'fernet': 'standard'
        }
        security_level = level_map.get(security_level, 'aes-256')
        
        encrypted_text, key_hex = encrypt_text(text, password, security_level)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, text_content, security_level, status) 
               VALUES (?, ?, ?, ?, ?)''',
            (current_user['id'], 'encrypt_text', text[:50] + '...' if len(text) > 50 else text, 
             security_level, 'success')
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Text encrypted successfully',
            'encrypted_text': encrypted_text,
            'key': key_hex,
            'security_level': security_level
        })
    
    except EncryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/decrypt/text', methods=['POST'])
@token_required
def decrypt_text_route(current_user):
    """Decrypt encrypted text."""
    try:
        data = request.get_json()
        
        encrypted_text = data.get('encrypted_text', '')
        password = data.get('password', '')
        
        if not encrypted_text:
            return jsonify({'error': 'Encrypted text is required'}), 400
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        decrypted_text = decrypt_text(encrypted_text, password)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, status) 
               VALUES (?, ?, ?)''',
            (current_user['id'], 'decrypt_text', 'success')
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Text decrypted successfully',
            'decrypted_text': decrypted_text
        })
    
    except DecryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== Image Encryption Routes ====================

@app.route('/api/encrypt/image', methods=['POST'])
@token_required
def encrypt_image_route(current_user):
    """Encrypt an uploaded image."""
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
        
        image = request.files['image']
        password = request.form.get('password')
        security_level = request.form.get('security_level', 'aes-256').lower()
        
        if image.filename == '':
            return jsonify({'error': 'No image selected'}), 400
        
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        # Map algorithm names
        level_map = {
            'aes-128': 'aes-128',
            'aes-256': 'aes-256',
            'standard': 'standard'
        }
        security_level = level_map.get(security_level, 'aes-256')
        
        # Read image data
        image_data = image.read()
        
        # Encrypt image
        encrypted_data, key_hex = encrypt_image(image_data, password, security_level)
        
        # Save encrypted image
        filename = secure_filename(image.filename)
        encrypted_filename = f"{uuid.uuid4()}_{filename}.enc"
        encrypted_path = os.path.join(Config.UPLOADS_FOLDER, encrypted_filename)
        
        with open(encrypted_path, 'wb') as f:
            f.write(encrypted_data)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, image_path, security_level, status) 
               VALUES (?, ?, ?, ?, ?)''',
            (current_user['id'], 'encrypt_image', encrypted_path, security_level, 'success')
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Image encrypted successfully',
            'encrypted_file': encrypted_filename,
            'key': key_hex,
            'security_level': security_level
        })
    
    except EncryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/decrypt/image', methods=['POST'])
@token_required
def decrypt_image_route(current_user):
    """Decrypt an encrypted image."""
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
        
        image = request.files['image']
        password = request.form.get('password')
        
        if image.filename == '':
            return jsonify({'error': 'No image selected'}), 400
        
        if not password:
            return jsonify({'error': 'Password is required'}), 400
        
        # Read encrypted data
        encrypted_data = image.read()
        
        # Decrypt image
        decrypted_data = decrypt_image(encrypted_data, password)
        
        # Save decrypted image
        filename = secure_filename(image.filename).replace('.enc', '')
        decrypted_filename = f"{uuid.uuid4()}_{filename}"
        decrypted_path = os.path.join(Config.UPLOADS_FOLDER, decrypted_filename)
        
        with open(decrypted_path, 'wb') as f:
            f.write(decrypted_data)
        
        # Log to history
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO encryption_history 
               (user_id, action, image_path, status) 
               VALUES (?, ?, ?, ?)''',
            (current_user['id'], 'decrypt_image', decrypted_path, 'success')
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Image decrypted successfully',
            'decrypted_file': decrypted_filename
        })
    
    except DecryptionError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== History Routes ====================

@app.route('/api/history', methods=['GET'])
@token_required
def get_history(current_user):
    """Get user's encryption/decryption history."""
    try:
        conn = get_db_connection()
        history = conn.execute(
            '''SELECT * FROM encryption_history 
               WHERE user_id = ? 
               ORDER BY timestamp DESC 
               LIMIT 50''',
            (current_user['id'],)
        ).fetchall()
        conn.close()
        
        return jsonify({
            'history': [dict(row) for row in history]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history', methods=['DELETE'])
@token_required
def clear_history(current_user):
    """Clear user's encryption history."""
    try:
        conn = get_db_connection()
        conn.execute(
            'DELETE FROM encryption_history WHERE user_id = ?',
            (current_user['id'],)
        )
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'History cleared successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== Settings Routes ====================

@app.route('/api/settings', methods=['GET'])
@token_required
def get_settings(current_user):
    """Get user settings."""
    try:
        conn = get_db_connection()
        settings = conn.execute(
            'SELECT * FROM user_settings WHERE user_id = ?',
            (current_user['id'],)
        ).fetchone()
        conn.close()
        
        if settings:
            return jsonify(dict(settings))
        else:
            return jsonify({
                'dark_mode': False,
                'sound_enabled': True,
                'language': 'English',
                'auto_save': True,
                'show_history': True
            })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/settings', methods=['PUT'])
@token_required
def update_settings(current_user):
    """Update user settings."""
    try:
        data = request.get_json()
        
        dark_mode = 1 if data.get('dark_mode') else 0
        sound_enabled = 1 if data.get('sound_enabled') else 0
        language = data.get('language', 'English')
        auto_save = 1 if data.get('auto_save') else 0
        show_history = 1 if data.get('show_history') else 0
        
        conn = get_db_connection()
        conn.execute('''
            INSERT INTO user_settings (user_id, dark_mode, sound_enabled, language, auto_save, show_history)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                dark_mode = excluded.dark_mode,
                sound_enabled = excluded.sound_enabled,
                language = excluded.language,
                auto_save = excluded.auto_save,
                show_history = excluded.show_history
        ''', (current_user['id'], dark_mode, sound_enabled, language, auto_save, show_history))
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Settings updated successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/settings/password', methods=['PUT'])
@token_required
def change_password(current_user):
    """Change user password."""
    try:
        data = request.get_json()
        
        old_password = data.get('old_password', '')
        new_password = data.get('new_password', '')
        
        if not old_password or not new_password:
            return jsonify({'error': 'Old and new passwords are required'}), 400
        
        if len(new_password) < 6:
            return jsonify({'error': 'New password must be at least 6 characters'}), 400
        
        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE id = ?',
            (current_user['id'],)
        ).fetchone()
        
        if not checkpw(old_password.encode(), user['password']):
            conn.close()
            return jsonify({'error': 'Invalid old password'}), 401
        
        new_hash = hashpw(new_password.encode(), gensalt())
        conn.execute(
            'UPDATE users SET password = ? WHERE id = ?',
            (new_hash, current_user['id'])
        )
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Password changed successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== Security Score Routes ====================

@app.route('/api/security-score', methods=['GET'])
@token_required
def get_security_score(current_user):
    """Calculate and return the user's security score."""
    try:
        conn = get_db_connection()
        
        # Get user's encryption history
        history = conn.execute(
            '''SELECT * FROM encryption_history 
               WHERE user_id = ? 
               ORDER BY timestamp DESC''',
            (current_user['id'],)
        ).fetchall()
        
        # Get user info
        user = conn.execute(
            'SELECT * FROM users WHERE id = ?',
            (current_user['id'],)
        ).fetchone()
        
        # Get user settings
        settings = conn.execute(
            'SELECT * FROM user_settings WHERE user_id = ?',
            (current_user['id'],)
        ).fetchone()
        
        conn.close()
        
        # Calculate score components
        score = 0
        breakdown = []
        tips = []
        
        # 1. Encryption Activity Score (0-25 points)
        total_encryptions = len([h for h in history if h['action'] == 'encrypt' and h['status'] == 'success'])
        if total_encryptions >= 20:
            activity_score = 25
        elif total_encryptions >= 10:
            activity_score = 20
        elif total_encryptions >= 5:
            activity_score = 15
        elif total_encryptions >= 1:
            activity_score = 10
        else:
            activity_score = 0
            tips.append("Start encrypting files to improve your security score")
        
        score += activity_score
        breakdown.append({
            'label': 'Encryption Activity',
            'score': activity_score,
            'maxScore': 25,
            'description': f'{total_encryptions} files encrypted'
        })
        
        # 2. Security Level Usage (0-25 points)
        high_security_count = len([h for h in history if h['security_level'] == 'aes-256' and h['action'] == 'encrypt'])
        if total_encryptions > 0:
            high_security_ratio = high_security_count / total_encryptions
            security_level_score = int(high_security_ratio * 25)
        else:
            security_level_score = 0
            
        if security_level_score < 15 and total_encryptions > 0:
            tips.append("Use AES-256 encryption for maximum security")
        
        score += security_level_score
        breakdown.append({
            'label': 'Security Level',
            'score': security_level_score,
            'maxScore': 25,
            'description': f'{high_security_count} files with AES-256'
        })
        
        # 3. Recent Activity Score (0-25 points)
        from datetime import datetime, timedelta
        recent_count = 0
        for h in history:
            try:
                # Use 'timestamp' column from the database
                ts = h['timestamp']
                if ts:
                    created_at = datetime.strptime(str(ts), '%Y-%m-%d %H:%M:%S')
                    if created_at > datetime.now() - timedelta(days=30):
                        recent_count += 1
            except Exception as e:
                # If timestamp parsing fails, still count it as recent
                recent_count += 1
        
        if recent_count >= 10:
            recent_score = 25
        elif recent_count >= 5:
            recent_score = 20
        elif recent_count >= 2:
            recent_score = 15
        elif recent_count >= 1:
            recent_score = 10
        else:
            recent_score = 0
            if total_encryptions > 0:
                tips.append("Stay active! Encrypt files regularly")
        
        score += recent_score
        breakdown.append({
            'label': 'Recent Activity',
            'score': recent_score,
            'maxScore': 25,
            'description': f'{recent_count} actions in last 30 days'
        })
        
        # 4. Account Security Score (0-25 points)
        account_score = 15  # Base score for having an account
        
        # Check if dark mode is enabled (shows security awareness)
        if settings and settings['dark_mode']:
            account_score += 5
            
        # Check if they've done both encrypt and decrypt (full usage)
        has_encrypt = any(h['action'] == 'encrypt' for h in history)
        has_decrypt = any(h['action'] == 'decrypt' for h in history)
        if has_encrypt and has_decrypt:
            account_score += 5
        
        if account_score < 20:
            tips.append("Use all features of the platform for better security")
        
        score += account_score
        breakdown.append({
            'label': 'Account Security',
            'score': account_score,
            'maxScore': 25,
            'description': 'Account health and usage'
        })
        
        # Determine grade
        if score >= 90:
            grade = 'A+'
            grade_text = 'Excellent Security'
        elif score >= 80:
            grade = 'A'
            grade_text = 'Great Security'
        elif score >= 70:
            grade = 'B'
            grade_text = 'Good Security'
        elif score >= 60:
            grade = 'C'
            grade_text = 'Average Security'
        elif score >= 40:
            grade = 'D'
            grade_text = 'Needs Improvement'
        else:
            grade = 'F'
            grade_text = 'Poor Security'
            tips.append("Your security needs immediate attention!")
        
        return jsonify({
            'score': min(score, 100),
            'grade': grade,
            'gradeText': grade_text,
            'breakdown': breakdown,
            'tips': tips[:3],  # Return top 3 tips
            'stats': {
                'totalEncryptions': total_encryptions,
                'totalDecryptions': len([h for h in history if h['action'] == 'decrypt']),
                'highSecurityFiles': high_security_count,
                'recentActivity': recent_count
            }
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================== Main ====================

if __name__ == '__main__':
    # Initialize database
    init_database()
    
    print("=" * 50)
    print("🔐 File Encryption API Server")
    print("=" * 50)
    print("Server running at: http://localhost:5000")
    print("API Documentation: http://localhost:5000/api/health")
    print("=" * 50)
    
    app.run(host='0.0.0.0', port=5000, debug=True)

