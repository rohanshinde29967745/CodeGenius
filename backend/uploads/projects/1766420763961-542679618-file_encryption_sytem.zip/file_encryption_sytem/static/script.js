
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');
    let isCollapsed = window.innerWidth <= 768;

    // Smooth active link handling with animation
    document.querySelectorAll('.sidebar a').forEach(link => {
        link.addEventListener('click', (e) => {
            document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
            link.classList.add('active');
            if (window.innerWidth <= 768) {
                e.preventDefault();
                sidebar.style.transition = 'width 0.5s ease-in-out';
                content.style.transition = 'margin-left 0.5s ease-in-out';
                setTimeout(() => {
                    sidebar.style.width = isCollapsed ? '250px' : '60px';
                    content.style.marginLeft = isCollapsed ? '250px' : '60px';
                    isCollapsed = !isCollapsed;
                    setTimeout(() => window.location.href = link.href, 500); // Smooth navigation delay
                }, 100);
            }
        });
    });

    // Smooth sidebar toggle on click
    sidebar.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && e.target.tagName === 'A' && !isCollapsed) {
            e.preventDefault();
            sidebar.style.transition = 'width 0.5s ease-in-out';
            content.style.transition = 'margin-left 0.5s ease-in-out';
            sidebar.style.width = '60px';
            content.style.marginLeft = '60px';
            isCollapsed = true;
            setTimeout(() => window.location.href = e.target.href, 500);
        }
    });

    // Smooth scroll behavior
    content.addEventListener('wheel', (e) => {
        e.preventDefault();
        content.style.scrollBehavior = 'smooth';
        content.scrollTop += e.deltaY * 0.5; // Smoother scroll
    });

    // Initial check for mobile with smooth transition
    if (window.innerWidth <= 768) {
        sidebar.style.width = '60px';
        content.style.marginLeft = '60px';
        isCollapsed = true;
    }

    // Resize handler with smooth transition
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768 && isCollapsed) {
            sidebar.style.transition = 'width 0.5s ease-in-out';
            content.style.transition = 'margin-left 0.5s ease-in-out';
            sidebar.style.width = '250px';
            content.style.marginLeft = '250px';
            isCollapsed = false;
        } else if (window.innerWidth <= 768 && !isCollapsed) {
            sidebar.style.transition = 'width 0.5s ease-in-out';
            content.style.transition = 'margin-left 0.5s ease-in-out';
            sidebar.style.width = '60px';
            content.style.marginLeft = '60px';
            isCollapsed = true;
        }
    });
});