from flask import Flask, render_template, request, redirect, url_for, session, flash
from encryption_utils import (
    encrypt_file, decrypt_file,
    encrypt_text, decrypt_text,
    encrypt_image, decrypt_image
)
import sqlite3
import os
from bcrypt import hashpw, gensalt, checkpw
from datetime import datetime
from PIL import Image
import io

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Define uploads folder
app.config['UPLOADS_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
os.makedirs(app.config['UPLOADS_FOLDER'], exist_ok=True)


def get_db_connection():
    conn = sqlite3.connect(r'E:\file_encryption_sytem\database.db')
    conn.row_factory = sqlite3.Row
    return conn


@app.route('/')
def root():
    return redirect(url_for('login'))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"].encode()

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()

        if user and checkpw(password, user["password"]):
            session["user_id"] = user["id"]
            return redirect(url_for("home"))
        else:
            flash("Invalid username or password")
            return redirect(url_for("login"))
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"].encode()
        hashed_pw = hashpw(password, gensalt())

        conn = get_db_connection()
        conn.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                     (username, email, hashed_pw))
        conn.commit()
        conn.close()

        flash("Registration successful! Please login.")
        return redirect(url_for("login"))
    return render_template("login.html")


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))


@app.route('/home')
def home():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    return render_template('home.html', active='home')


@app.route('/info')
def info():
    return render_template('info.html', active='info')


# ---------------- File Encrypt -----------------
@app.route('/file_encrypt', methods=['GET', 'POST'])
def file_encrypt():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        file = request.files.get('file')
        security_level = request.form.get('algorithm')
        password = request.form.get('password')

        if not file or file.filename == '':
            return "❌ No file selected", 400
        if not security_level or not password:
            return "❌ Missing algorithm or password", 400

        # Save file
        filename = os.path.join(app.config['UPLOADS_FOLDER'], file.filename)
        file.save(filename)

        # Map algorithm to level
        level = {'AES-128': 'standard', 'AES-256': 'average'}.get(security_level, 'high')

        # Encrypt
        encrypted_path, key = encrypt_file(filename, password, level)

        # Log in database
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO encryption_history (user_id, action, file_path, security_level, timestamp) VALUES (?, ?, ?, ?, ?)',
            (session['user_id'], 'encrypt', filename, security_level, datetime.now())
        )
        conn.commit()
        conn.close()

        return f"✅ File encrypted with {security_level} level. Key: {key.hex()}"

    return render_template('file_encrypt.html', active='file_encrypt')


# ---------------- File Decrypt -----------------
@app.route('/file_decrypt', methods=['GET', 'POST'])
def file_decrypt():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        file = request.files.get('file')
        password = request.form.get('password')

        if not file or file.filename == '':
            return "❌ No file selected", 400
        if not password:
            return "❌ Password is required", 400

        # Save uploaded file
        uploaded_path = os.path.join(app.config['UPLOADS_FOLDER'], file.filename)
        file.save(uploaded_path)

        # Decrypt
        decrypted_path = decrypt_file(uploaded_path, password)

        # Log in database
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO encryption_history (user_id, action, file_path, security_level, timestamp) VALUES (?, ?, ?, ?, ?)',
            (session['user_id'], 'decrypt', decrypted_path, 'Unknown', datetime.now())
        )
        conn.commit()
        conn.close()

        return f"✅ File decrypted successfully. Saved as: {decrypted_path}"

    return render_template('file_decrypt.html', active='file_decrypt')


# ---------------- Text/Image Encryption -----------------
@app.route('/text_image', methods=['GET', 'POST'])
def text_image():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        conn = get_db_connection()

        # Text encryption
        if 'text' in request.form:
            text = request.form['text']
            security_level = request.form.get('security_level', '1')
            encrypted_data, key = encrypt_text(text)
            conn.execute(
                'INSERT INTO encryption_history (user_id, action, text_content, security_level, timestamp) VALUES (?, ?, ?, ?, ?)',
                (session['user_id'], 'encrypt', text, security_level, datetime.now())
            )
            conn.commit()
            conn.close()
            return f"Encrypted Text: {encrypted_data.decode()} Key: {key.hex()}"

        # Image encryption
        if 'image' in request.files:
            image = request.files['image']
            if not image or image.filename == '':
                return "❌ No image selected", 400

            img = Image.open(image)
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format=img.format)
            data = img_byte_arr.getvalue()
            security_level = request.form.get('security_level', '1')
            encrypted_data, key = encrypt_image(data)

            output_filename = os.path.join(app.config['UPLOADS_FOLDER'], image.filename + '.enc')
            with open(output_filename, 'wb') as f:
                f.write(encrypted_data)

            conn.execute(
                'INSERT INTO encryption_history (user_id, action, image_path, security_level, timestamp) VALUES (?, ?, ?, ?, ?)',
                (session['user_id'], 'encrypt', output_filename, security_level, datetime.now())
            )
            conn.commit()
            conn.close()

            return f"✅ Image encrypted with {security_level} level. Key: {key.hex()}"

    return render_template('text_image.html', active='text_image')


# ---------------- History -----------------
@app.route('/history')
def history():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    conn = get_db_connection()
    history = conn.execute(
        'SELECT * FROM encryption_history WHERE user_id = ? ORDER BY timestamp DESC',
        (session['user_id'],)
    ).fetchall()
    conn.close()
    return render_template('history.html', history=history, active='history')


# ---------------- Settings -----------------
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if not session.get('user_id'):
        return redirect(url_for('login'))

    conn = get_db_connection()
    user_id = session['user_id']
    msg = None

    # Create settings table if not exists
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_settings (
            user_id INTEGER PRIMARY KEY,
            dark_mode BOOLEAN DEFAULT 0,
            sound_enabled BOOLEAN DEFAULT 1,
            language TEXT DEFAULT 'English',
            auto_save BOOLEAN DEFAULT 1,
            show_history BOOLEAN DEFAULT 1,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    if request.method == 'POST':
        form = request.form

        if 'change_password' in form:
            old_pw = form['old_password'].encode()
            new_pw = form['new_password'].encode()
            user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
            if user and checkpw(old_pw, user['password']):
                new_hash = hashpw(new_pw, gensalt())
                conn.execute('UPDATE users SET password = ? WHERE id = ?', (new_hash, user_id))
                conn.commit()
                msg = "✅ Password changed successfully!"
            else:
                msg = "❌ Invalid old password."

        elif 'forgot_password' in form:
            new_hash = hashpw("newpassword".encode(), gensalt())
            conn.execute('UPDATE users SET password = ? WHERE id = ?', (new_hash, user_id))
            conn.commit()
            msg = "🔑 Password reset to 'newpassword'. Please log in again."

        elif 'clear_history' in form:
            conn.execute('DELETE FROM encryption_history WHERE user_id = ?', (user_id,))
            conn.commit()
            msg = "🗑 History cleared successfully!"

        elif 'save_settings' in form:
            dark_mode = 1 if form.get('dark_mode') == 'on' else 0
            sound_enabled = 1 if form.get('sound_enabled') == 'on' else 0
            language = form.get('language', 'English')
            auto_save = 1 if form.get('auto_save') == 'on' else 0
            show_history = 1 if form.get('show_history') == 'on' else 0

            conn.execute('''
                INSERT INTO user_settings (user_id, dark_mode, sound_enabled, language, auto_save, show_history)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    dark_mode=excluded.dark_mode,
                    sound_enabled=excluded.sound_enabled,
                    language=excluded.language,
                    auto_save=excluded.auto_save,
                    show_history=excluded.show_history;
            ''', (user_id, dark_mode, sound_enabled, language, auto_save, show_history))
            conn.commit()
            msg = "⚙️ Settings updated successfully!"

        elif 'logout' in form:
            session.clear()
            conn.close()
            return redirect(url_for('login'))

    settings_data = conn.execute('SELECT * FROM user_settings WHERE user_id = ?', (user_id,)).fetchone()
    records = conn.execute('SELECT * FROM encryption_history WHERE user_id = ? ORDER BY timestamp DESC', (user_id,)).fetchall()
    conn.close()

    return render_template('settings.html', settings=settings_data, records=records, msg=msg, active='settings')
if __name__ == "__main__":
    print("Starting the application...")
    app.run(debug=True)
