
import sqlite3

# Path to your database
DB_PATH = r"E:\file_encryption_sytem\database.db"  # change as needed

conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

# Create users table
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL,
    password BLOB NOT NULL
)
''')

# Create encryption history table
c.execute('''
CREATE TABLE IF NOT EXISTS encryption_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    file_path TEXT,
    text_content TEXT,
    image_path TEXT,
    security_level TEXT,
    timestamp TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
)
''')

conn.commit()
conn.close()

print("Database created successfully!")

import sqlite3
from bcrypt import hashpw, gensalt

# Admin credentials
username = "rohan shinde"
password = "Rohan@2007".encode()  # plaintext password
hashed_pw = hashpw(password, gensalt())

# Connect to database
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Insert admin user
cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
               (username, "admin@example.com", hashed_pw))
print("User added successfully!")
conn.commit()
conn.close()


