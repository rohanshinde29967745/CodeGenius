# 🔐 CryptoVault - File Encryption System

A modern, secure file encryption and decryption system with a separated client-server architecture.

## 🏗️ Architecture

```
file_encryption_system/
├── server/                    # Flask REST API Backend
│   ├── app.py                 # Main API application
│   ├── config.py              # Configuration settings
│   ├── database.py            # Database utilities
│   ├── encryption_utils.py    # Encryption logic
│   └── requirements.txt       # Python dependencies
│
└── client/                    # React + Vite Frontend
    ├── src/
    │   ├── components/        # Reusable UI components
    │   ├── context/           # React context (Auth)
    │   ├── pages/             # Page components
    │   └── services/          # API service layer
    └── package.json
```

## ✨ Features

- **User Authentication**: JWT-based secure login/register
- **File Encryption**: Encrypt files with AES-128, AES-256, or Fernet
- **File Decryption**: Decrypt encrypted files with password
- **Text Encryption**: Encrypt/decrypt text messages
- **Image Encryption**: Encrypt/decrypt images
- **Encryption History**: Track all encryption/decryption activity
- **User Settings**: Dark mode, language, preferences
- **Modern UI**: Beautiful, responsive React frontend

## 🚀 Getting Started

### Prerequisites

- Python 3.8+
- Node.js 18+
- npm or yarn

### Backend Setup

1. Navigate to the server directory:
   ```bash
   cd server
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   venv\Scripts\activate  # Windows
   source venv/bin/activate  # Linux/Mac
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the server:
   ```bash
   python app.py
   ```

   The API will be available at `http://localhost:5000`

### Frontend Setup

1. Navigate to the client directory:
   ```bash
   cd client
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

   The frontend will be available at `http://localhost:5173`

## 📡 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/refresh` | Refresh access token |
| GET | `/api/auth/me` | Get current user |

### Encryption
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/encrypt/file` | Encrypt a file |
| POST | `/api/decrypt/file` | Decrypt a file |
| POST | `/api/encrypt/text` | Encrypt text |
| POST | `/api/decrypt/text` | Decrypt text |
| POST | `/api/encrypt/image` | Encrypt an image |
| POST | `/api/decrypt/image` | Decrypt an image |
| GET | `/api/download/:filename` | Download encrypted/decrypted file |

### History & Settings
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/history` | Get encryption history |
| DELETE | `/api/history` | Clear history |
| GET | `/api/settings` | Get user settings |
| PUT | `/api/settings` | Update settings |
| PUT | `/api/settings/password` | Change password |

## 🔒 Security Features

- **Password Hashing**: bcrypt with salt
- **JWT Authentication**: Secure token-based auth
- **AES Encryption**: Military-grade file encryption
- **Secure Key Derivation**: SHA-256 based key generation
- **CORS Protection**: Configured for frontend origin

## 🛠️ Technology Stack

### Backend
- Flask (Python)
- SQLite3
- cryptography (Fernet)
- pycryptodome (AES)
- bcrypt
- PyJWT

### Frontend
- React 18
- Vite
- React Router DOM
- Axios
- React Icons
- React Hot Toast

## 📝 License

MIT License - feel free to use this project for learning or personal use.
